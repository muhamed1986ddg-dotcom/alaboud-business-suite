const express = require("express");
const helmet = require("helmet");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const { hashPassword, verifyPassword, isScryptHash, passwordPolicy, encryptJson, decryptJson, sha256 } = require("./security");
const path = require("path");
const fs = require("fs");
const { readStore, mutate, id, now, runWithTenant, initStore } = require("./store");

const PORT = Number(process.env.PORT || 5000);
const IS_PROD = process.env.NODE_ENV === "production";
const JWT_SECRET = process.env.JWT_SECRET || "LOCAL_TRIAL_CHANGE_ME_6_0";
if (IS_PROD && JWT_SECRET === "LOCAL_TRIAL_CHANGE_ME_6_0") { throw new Error("JWT_SECRET قوي ومخصص مطلوب في الإنتاج"); }
const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use((req,res,next)=>{ req.requestId=crypto.randomUUID(); res.setHeader("X-Request-ID",req.requestId); next(); });
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc:["'self'"], scriptSrc:["'self'"], styleSrc:["'self'","'unsafe-inline'"], imgSrc:["'self'","data:","blob:"], connectSrc:["'self'","https:"], objectSrc:["'none'"], baseUri:["'self'"], frameAncestors:["'none'"] } }, crossOriginEmbedderPolicy:false, hsts: IS_PROD ? {maxAge:31536000,includeSubDomains:true,preload:true}:false }));
app.use(express.json({ limit: "2mb", strict:true }));
app.use(express.urlencoded({extended:false,limit:"256kb"}));
const requestBuckets=new Map();
function rateLimit(name,limit,windowMs){return (req,res,next)=>{const key=`${name}:${req.ip}`;const t=Date.now();let b=requestBuckets.get(key);if(!b||t>b.reset){b={count:0,reset:t+windowMs};requestBuckets.set(key,b)}b.count++;res.setHeader("RateLimit-Limit",limit);res.setHeader("RateLimit-Remaining",Math.max(0,limit-b.count));if(b.count>limit)return res.status(429).json({message:"طلبات كثيرة جدًا، حاول لاحقًا"});next()}}
app.use("/api",rateLimit("api",600,15*60*1000));

app.use("/api",(_req,res,next)=>{
  res.setHeader("Cache-Control","no-store, no-cache, must-revalidate, proxy-revalidate");
  res.setHeader("Pragma","no-cache");
  res.setHeader("Expires","0");
  res.setHeader("Surrogate-Control","no-store");
  next();
});

function seedAdmin(){
  mutate((store)=>{
    let company=store.companies.find(item=>item.slug==="alaboud-primary");
    if(!company){
      company={id:id(),name:"شركة العبود التجارية",slug:"alaboud-primary",phone:"",active:true,createdAt:now()};
      store.companies.push(company);
    }

    let admin=store.users.find(user=>user.email==="admin@alaboud.local");
    if(!admin){
      admin={id:id(),companyId:company.id,name:"System Administrator",email:"admin@alaboud.local",passwordHash:hashPassword("Admin123!ChangeMe"),role:"ADMIN",active:true,mustChangePassword:true,createdAt:now()};
      store.users.push(admin);
    }else if(!admin.companyId){
      admin.companyId=company.id;
    }

    const tenantArrays=["customers","transactions","payments","expenses","capitalMovements","exchangeRates","generalDebts","generalDebtPayments","partners","partnerTransactions","partnerPayments","notificationActions","auditLogs","devices"];
    for(const key of tenantArrays){
      for(const item of store[key]||[]){
        if(item&&!item.companyId)item.companyId=company.id;
      }
    }
    if(!store.companySettings[company.id]){
      store.companySettings[company.id]={...(store.notificationSettings||{}),overdueDays:store.notificationSettings?.overdueDays||7,lowCashLimit:store.notificationSettings?.lowCashLimit||5000,whatsappTemplate:store.notificationSettings?.whatsappTemplate||""};
    }
  });
}

function auth(req,res,next){
  const h=req.headers.authorization||"";
  const token=h.startsWith("Bearer ")?h.slice(7):"";
  try{
    req.user=jwt.verify(token,JWT_SECRET,{issuer:"alaboud-business-suite",audience:"alaboud-client",algorithms:["HS256"]});
    if(!req.user.companyId)return res.status(401).json({message:"Company account required"});
    runWithTenant(req.user.companyId,()=>next());
  }catch{
    res.status(401).json({message:"Authentication required"});
  }
}

function audit(store, userId, action, entityType, entityId, details = {}) {
  const logs=store.auditLogs||[]; const previous=logs.length?logs[logs.length-1].integrityHash||"":"GENESIS";
  const entry={ id:id(), userId, action, entityType, entityId, details, createdAt:now(), previousHash:previous };
  entry.integrityHash=sha256(JSON.stringify(entry)); logs.push(entry);
}


function base32Encode(buffer){
  const alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"; let bits="",out="";
  for(const byte of buffer) bits+=byte.toString(2).padStart(8,"0");
  for(let i=0;i<bits.length;i+=5){const chunk=bits.slice(i,i+5).padEnd(5,"0");out+=alphabet[parseInt(chunk,2)];}
  return out;
}
function base32Decode(value){
  const alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"; let bits="";
  for(const ch of String(value||"").replace(/=+$/g,"").toUpperCase()){const i=alphabet.indexOf(ch);if(i>=0)bits+=i.toString(2).padStart(5,"0");}
  const bytes=[]; for(let i=0;i+8<=bits.length;i+=8)bytes.push(parseInt(bits.slice(i,i+8),2)); return Buffer.from(bytes);
}
function totp(secret,time=Date.now(),step=30){
  const counter=Math.floor(time/1000/step); const msg=Buffer.alloc(8); msg.writeBigUInt64BE(BigInt(counter));
  const digest=crypto.createHmac("sha1",base32Decode(secret)).update(msg).digest(); const off=digest[digest.length-1]&15;
  const code=((digest.readUInt32BE(off)&0x7fffffff)%1000000).toString().padStart(6,"0"); return code;
}
function verifyTotp(secret,code){const clean=String(code||"").replace(/\D/g,""); if(clean.length!==6)return false; for(let w=-1;w<=1;w++)if(totp(secret,Date.now()+w*30000)===clean)return true; return false;}
function issueSession(user,company){
  const token=jwt.sign({id:user.id,name:user.name,role:user.role,companyId:user.companyId,jti:crypto.randomUUID()},JWT_SECRET,{expiresIn:"12h",issuer:"alaboud-business-suite",audience:"alaboud-client"});
  return {token,user:{id:user.id,name:user.name,email:user.email,role:user.role,companyId:user.companyId,companyName:company.name,mustChangePassword:Boolean(user.mustChangePassword),twoFactorEnabled:Boolean(user.twoFactorEnabled)}};
}

function safeNumber(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function recordTime(value, fallback = "") {
  const text = String(value || fallback || "").trim();
  if (!text) return 0;
  const normalized = /^\d{4}-\d{2}-\d{2}$/.test(text) ? `${text}T00:00:00` : text;
  const parsed = new Date(normalized).getTime();
  return Number.isFinite(parsed) ? parsed : 0;
}

function isAfterCustomerReset(record, customer, preferredDateKey = "") {
  const resetTime = recordTime(customer?.accountResetAt);
  if (!resetTime) return true;
  const preferredTime = preferredDateKey ? recordTime(record?.[preferredDateKey]) : 0;
  const createdTime = recordTime(record?.createdAt || record?.updatedAt);
  const activityTime = Math.max(preferredTime, createdTime);
  return activityTime >= resetTime;
}

function customerSummary(store, c) {
  const overdueThreshold = Math.max(1, safeNumber(store.notificationSettings?.overdueDays, 7));
  const transactions = (Array.isArray(store.transactions) ? store.transactions : [])
    .filter((item) => item && !item.isDeleted);
  const payments = (Array.isArray(store.payments) ? store.payments : [])
    .filter((item) => item && !item.isDeleted);

  const txs = transactions.filter(
    (transaction) =>
      transaction.customerId === c.id &&
      transaction.status !== "CANCELLED" &&
      isAfterCustomerReset(transaction, c, "transferDate")
  );

  const paymentByTransaction = new Map();
  for (const payment of payments) {
    paymentByTransaction.set(
      payment.transactionId,
      safeNumber(paymentByTransaction.get(payment.transactionId)) + safeNumber(payment.amount)
    );
  }

  const accountWasReset = Boolean(c.accountResetAt);
  const oldBalance = accountWasReset ? 0 : Math.max(safeNumber(c.oldBalance), 0);
  const oldBalancePaid = accountWasReset ? 0 : Math.min(Math.max(safeNumber(c.oldBalancePaid), 0), oldBalance);

  let total = oldBalance;
  let paid = oldBalancePaid;
  let oldestUnpaidDate = "";
  let overdueTransactions = 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  for (const transaction of txs) {
    const due = safeNumber(transaction.totalCustomerDue, safeNumber(transaction.amount));
    const transactionPaid = safeNumber(paymentByTransaction.get(transaction.id));
    const remaining = Math.max(due - transactionPaid, 0);
    total += due;
    paid += transactionPaid;

    if (remaining > 0) {
      const dateText = String(transaction.transferDate || transaction.createdAt || "").slice(0, 10);
      const transactionDate = new Date(`${dateText}T00:00:00`);
      if (!Number.isNaN(transactionDate.getTime())) {
        const ageDays = Math.floor((today - transactionDate) / 86400000);
        if (ageDays > overdueThreshold) overdueTransactions += 1;
        if (!oldestUnpaidDate || dateText < oldestUnpaidDate) oldestUnpaidDate = dateText;
      }
    }
  }

  const outstanding = Math.max(total - paid, 0);
  let overdueDays = 0;
  if (oldestUnpaidDate) {
    const oldestDate = new Date(`${oldestUnpaidDate}T00:00:00`);
    overdueDays = Math.max(0, Math.floor((today - oldestDate) / 86400000));
  }

  return {
    ...c,
    name: String(c?.name || "عميل بدون اسم"),
    oldBalance:+oldBalance.toFixed(2),
    oldBalancePaid:+oldBalancePaid.toFixed(2),
    oldBalanceRemaining:+Math.max(oldBalance-oldBalancePaid,0).toFixed(2),
    totalTransactions: +total.toFixed(2),
    totalPaid: +paid.toFixed(2),
    finalBalance: +outstanding.toFixed(2),
    overdue: outstanding > 0 && overdueDays > overdueThreshold,
    overdueThreshold,
    overdueDays,
    overdueTransactions,
    oldestUnpaidDate: oldestUnpaidDate || null,
  };
}

app.get("/api/health", (_req,res)=>res.json({status:"ok",version:"18.6.21",channel:"jad-simple-balance-sync",cloud:true}));
app.post("/api/auth/login", rateLimit("login",10,15*60*1000),(req,res)=>{
  const email=String(req.body?.email||"").trim().toLowerCase(); const password=String(req.body?.password||"");
  const store=readStore(); const user=store.users.find(u=>String(u.email||"").toLowerCase()===email&&u.active); const current=Date.now();
  if(user?.lockedUntil&&new Date(user.lockedUntil).getTime()>current) return res.status(423).json({message:"الحساب مقفل مؤقتًا بسبب محاولات فاشلة متكررة"});
  const valid=user&&(isScryptHash(user.passwordHash)?verifyPassword(password,user.passwordHash):bcrypt.compareSync(password,user.passwordHash));
  if(!valid){ mutate(root=>{const u=root.users.find(x=>String(x.email||"").toLowerCase()===email); if(u){u.failedLoginAttempts=(u.failedLoginAttempts||0)+1; if(u.failedLoginAttempts>=5){u.lockedUntil=new Date(Date.now()+15*60*1000).toISOString();u.failedLoginAttempts=0;} audit(root,u.id,"LOGIN_FAILED","AUTH",u.id,{ip:req.ip,requestId:req.requestId});}}); return res.status(401).json({message:"بيانات الدخول غير صحيحة"}); }
  const company=store.companies.find(item=>item.id===user.companyId&&item.active); if(!company)return res.status(403).json({message:"Company account is inactive"});
  if(user.twoFactorEnabled){
    const challenge=jwt.sign({id:user.id,companyId:user.companyId,purpose:"2fa"},JWT_SECRET,{expiresIn:"5m",issuer:"alaboud-business-suite",audience:"alaboud-2fa"});
    return res.json({twoFactorRequired:true,challenge});
  }
  mutate(root=>{const u=root.users.find(x=>x.id===user.id);u.failedLoginAttempts=0;u.lockedUntil=null;if(!isScryptHash(u.passwordHash))u.passwordHash=hashPassword(password);u.lastLoginAt=now();audit(root,u.id,"LOGIN_SUCCESS","AUTH",u.id,{ip:req.ip,requestId:req.requestId});});
  res.json(issueSession(user,company));
});

app.post("/api/auth/2fa/verify",rateLimit("2fa",10,10*60*1000),(req,res)=>{
  try{
    const payload=jwt.verify(String(req.body?.challenge||""),JWT_SECRET,{issuer:"alaboud-business-suite",audience:"alaboud-2fa",algorithms:["HS256"]});
    if(payload.purpose!=="2fa")throw new Error("invalid");
    const store=readStore(); const user=store.users.find(u=>u.id===payload.id&&u.active); const company=store.companies.find(c=>c.id===payload.companyId&&c.active);
    if(!user||!company||!user.twoFactorSecret||!verifyTotp(user.twoFactorSecret,req.body?.code))return res.status(401).json({message:"رمز التحقق غير صحيح"});
    mutate(root=>{const u=root.users.find(x=>x.id===user.id);u.lastLoginAt=now();audit(root,u.id,"LOGIN_2FA_SUCCESS","AUTH",u.id,{ip:req.ip,requestId:req.requestId});});
    res.json(issueSession(user,company));
  }catch{return res.status(401).json({message:"انتهت صلاحية التحقق، أعد تسجيل الدخول"});}
});

app.post("/api/auth/2fa/setup",auth,(req,res)=>{
  const secret=base32Encode(crypto.randomBytes(20));
  mutate(store=>{const u=store.users.find(x=>x.id===req.user.id);u.twoFactorPendingSecret=secret;audit(store,u.id,"2FA_SETUP_STARTED","AUTH",u.id);});
  const label=encodeURIComponent(`ALABOUD:${req.user.name||req.user.id}`);
  res.json({secret,otpauth:`otpauth://totp/${label}?secret=${secret}&issuer=ALABOUD%20Business%20Suite&digits=6&period=30`});
});
app.post("/api/auth/2fa/enable",auth,(req,res)=>{
  let ok=false; mutate(store=>{const u=store.users.find(x=>x.id===req.user.id);if(u?.twoFactorPendingSecret&&verifyTotp(u.twoFactorPendingSecret,req.body?.code)){u.twoFactorSecret=u.twoFactorPendingSecret;delete u.twoFactorPendingSecret;u.twoFactorEnabled=true;ok=true;audit(store,u.id,"2FA_ENABLED","AUTH",u.id);}});
  if(!ok)return res.status(400).json({message:"رمز التحقق غير صحيح"});res.json({message:"تم تفعيل التحقق بخطوتين"});
});
app.post("/api/auth/2fa/disable",auth,(req,res)=>{mutate(store=>{const u=store.users.find(x=>x.id===req.user.id);u.twoFactorEnabled=false;delete u.twoFactorSecret;delete u.twoFactorPendingSecret;audit(store,u.id,"2FA_DISABLED","AUTH",u.id);});res.json({message:"تم تعطيل التحقق بخطوتين"});});

app.post("/api/auth/biometric-token",auth,(req,res)=>{
  const token=jwt.sign({id:req.user.id,companyId:req.user.companyId,purpose:"biometric"},JWT_SECRET,{expiresIn:"30d",issuer:"alaboud-business-suite",audience:"alaboud-biometric"});res.json({token});
});
app.post("/api/auth/biometric-login",rateLimit("biometric",20,15*60*1000),(req,res)=>{
  try{const p=jwt.verify(String(req.body?.token||""),JWT_SECRET,{issuer:"alaboud-business-suite",audience:"alaboud-biometric",algorithms:["HS256"]});if(p.purpose!=="biometric")throw new Error();const store=readStore();const user=store.users.find(u=>u.id===p.id&&u.active);const company=store.companies.find(c=>c.id===p.companyId&&c.active);if(!user||!company)throw new Error();res.json(issueSession(user,company));}catch{return res.status(401).json({message:"انتهت صلاحية الدخول بالبصمة"});}
});

app.get("/api/auth/session",auth,(req,res)=>{
  const store=readStore();
  const user=store.users.find(item=>item.id===req.user.id&&item.active);
  const company=store.companies.find(item=>item.id===req.user.companyId&&item.active);

  if(!user||!company){
    return res.status(401).json({message:"الجلسة غير صالحة، يرجى تسجيل الدخول مجددًا"});
  }

  res.json({
    version:"17.1.0",
    user:{
      id:user.id,
      name:user.name,
      email:user.email,
      role:user.role,
      companyId:company.id,
      companyName:company.name
    },
    liveData:{
      customers:(store.customers||[]).filter(item=>!item.isDeleted).length,
      transactions:(store.transactions||[]).filter(item=>!item.isDeleted).length,
      payments:(store.payments||[]).filter(item=>!item.isDeleted).length
    }
  });
});

app.post("/api/auth/register-company",(req,res)=>{
  const ownerName=String(req.body?.ownerName||"").trim();
  const companyName=String(req.body?.companyName||"").trim();
  const email=String(req.body?.email||"").trim().toLowerCase();
  const phone=String(req.body?.phone||"").trim();
  const password=String(req.body?.password||"");
  if(!ownerName||!companyName||!email.includes("@")){
    return res.status(400).json({message:"الاسم واسم الشركة والبريد الإلكتروني مطلوبة"});
  }
  { const policy=passwordPolicy(password); if(!policy.ok)return res.status(400).json({message:policy.message}); }

  try{
    const result=mutate(store=>{
      if(store.users.some(user=>String(user.email||"").toLowerCase()===email))throw new Error("البريد الإلكتروني مستخدم مسبقًا");
      const company={id:id(),name:companyName,phone,active:true,createdAt:now()};
      const user={id:id(),companyId:company.id,name:ownerName,email,passwordHash:hashPassword(password),role:"ADMIN",active:true,createdAt:now()};
      store.companies.push(company);
      store.users.push(user);
      store.companySettings[company.id]={overdueDays:7,lowCashLimit:5000,whatsappTemplate:""};
      return {company,user};
    });
    const token=jwt.sign({id:result.user.id,name:result.user.name,role:result.user.role,companyId:result.company.id},JWT_SECRET,{expiresIn:"30d"});
    res.status(201).json({token,user:{id:result.user.id,name:result.user.name,email:result.user.email,role:result.user.role,companyId:result.company.id,companyName:result.company.name}});
  }catch(error){
    res.status(400).json({message:error.message||"تعذر إنشاء حساب الشركة"});
  }
});

app.post("/api/auth/change-password", auth, (req,res)=>{
  const currentPassword=String(req.body?.currentPassword||"");
  const newPassword=String(req.body?.newPassword||"");
  const policy=passwordPolicy(newPassword);
  if(!policy.ok){ return res.status(400).json({message:policy.message}); }

  try{
    mutate((store)=>{
      const user=store.users.find(item=>item.id===req.user.id&&item.active);
      if(!user)throw new Error("الحساب غير موجود");
      if(!bcrypt.compareSync(currentPassword,user.passwordHash)){
        throw new Error("كلمة المرور الحالية غير صحيحة");
      }
      user.passwordHash=hashPassword(newPassword);
      user.mustChangePassword=false;
      user.updatedAt=now();
      audit(store,req.user.id,"UPDATE","USER_PASSWORD",user.id,{});
    });
    res.json({message:"تم تغيير كلمة المرور بنجاح"});
  }catch(error){
    res.status(400).json({message:error.message||"تعذر تغيير كلمة المرور"});
  }
});

app.get("/api/company-profile", auth, (req,res)=>{
  const store=readStore();
  const company=store.companies.find(item=>item.id===req.user.companyId);
  if(!company)return res.status(404).json({message:"الشركة غير موجودة"});
  res.json({id:company.id,name:company.name,phone:company.phone||"",logoDataUrl:company.logoDataUrl||""});
});

app.patch("/api/company-profile", auth, (req,res)=>{
  if(req.user.role!=="ADMIN")return res.status(403).json({message:"تعديل هوية الشركة متاح للمسؤول الكامل فقط"});
  const name=String(req.body?.name||"").trim();
  const phone=String(req.body?.phone||"").trim();
  const logoDataUrl=String(req.body?.logoDataUrl||"");
  if(!name)return res.status(400).json({message:"اسم الشركة مطلوب"});
  if(logoDataUrl && !/^data:image\/(png|jpeg|jpg|webp);base64,/i.test(logoDataUrl)){
    return res.status(400).json({message:"صيغة الشعار غير مدعومة"});
  }
  if(logoDataUrl.length>1500000)return res.status(400).json({message:"حجم الشعار كبير جدًا"});
  const company=mutate(store=>{
    const item=store.companies.find(company=>company.id===req.user.companyId);
    if(!item)throw new Error("الشركة غير موجودة");
    item.name=name; item.phone=phone; item.logoDataUrl=logoDataUrl; item.updatedAt=now();
    return {id:item.id,name:item.name,phone:item.phone||"",logoDataUrl:item.logoDataUrl||""};
  });
  res.json(company);
});

app.post("/api/users", auth, (req,res)=>{
  if(req.user.role!=="ADMIN"){
    return res.status(403).json({message:"إنشاء الحسابات متاح للمدير فقط"});
  }

  const name=String(req.body?.name||"").trim();
  const email=String(req.body?.email||"").trim().toLowerCase();
  const password=String(req.body?.password||"");
  const role=["ADMIN","MANAGER","USER"].includes(String(req.body?.role||"").toUpperCase())
    ? String(req.body.role).toUpperCase()
    : "USER";

  if(!name||!email||!email.includes("@")){
    return res.status(400).json({message:"الاسم والبريد الإلكتروني مطلوبان"});
  }
  { const policy=passwordPolicy(password); if(!policy.ok)return res.status(400).json({message:policy.message}); }

  try{
    const created=mutate((store)=>{
      if(store.users.some(item=>String(item.email||"").toLowerCase()===email)){
        throw new Error("البريد الإلكتروني مستخدم مسبقًا");
      }
      const user={
        id:id(),
        companyId:req.user.companyId,
        name,
        email,
        passwordHash:hashPassword(password),
        role,
        active:true,
        createdAt:now()
      };
      store.users.push(user);
      audit(store,req.user.id,"CREATE","USER",user.id,{name,email,role});
      return {id:user.id,name:user.name,email:user.email,role:user.role,active:user.active};
    });
    res.status(201).json(created);
  }catch(error){
    res.status(400).json({message:error.message||"تعذر إنشاء الحساب"});
  }
});

app.get("/api/users", auth, (req,res)=>{
  if(req.user.role!=="ADMIN")return res.status(403).json({message:"إدارة المستخدمين متاحة للمدير فقط"});
  const users=readStore().users.map(user=>({id:user.id,name:user.name,email:user.email,role:user.role,active:user.active!==false,createdAt:user.createdAt,lastLoginAt:user.lastLoginAt||null}));
  res.json(users);
});

app.patch("/api/users/:id", auth, (req,res)=>{
  if(req.user.role!=="ADMIN")return res.status(403).json({message:"إدارة المستخدمين متاحة للمدير فقط"});
  try{
    const updated=mutate(store=>{
      const user=store.users.find(item=>item.id===req.params.id);
      if(!user)throw new Error("المستخدم غير موجود");
      if(user.id===req.user.id&&req.body?.active===false)throw new Error("لا يمكنك تعطيل حسابك الحالي");
      if(req.body?.name!==undefined)user.name=String(req.body.name||"").trim()||user.name;
      if(req.body?.role!==undefined&&["ADMIN","MANAGER","USER","VIEWER"].includes(String(req.body.role).toUpperCase()))user.role=String(req.body.role).toUpperCase();
      if(req.body?.active!==undefined)user.active=Boolean(req.body.active);
      if(req.body?.password!==undefined){const policy=passwordPolicy(String(req.body.password));if(!policy.ok)throw new Error(policy.message);user.passwordHash=hashPassword(String(req.body.password));user.mustChangePassword=true;}
      user.updatedAt=now();
      audit(store,req.user.id,"UPDATE","USER",user.id,{role:user.role,active:user.active});
      return {id:user.id,name:user.name,email:user.email,role:user.role,active:user.active!==false,lastLoginAt:user.lastLoginAt||null};
    });
    res.json(updated);
  }catch(error){res.status(400).json({message:error.message||"تعذر تحديث المستخدم"})}
});

app.get("/api/devices", auth, (req,res)=>{
  if(req.user.role!=="ADMIN")return res.status(403).json({message:"إدارة الأجهزة متاحة للمدير فقط"});
  res.json((readStore().devices||[]).slice().sort((a,b)=>String(b.lastSeenAt||"").localeCompare(String(a.lastSeenAt||""))));
});

app.patch("/api/devices/:id", auth, (req,res)=>{
  if(req.user.role!=="ADMIN")return res.status(403).json({message:"إدارة الأجهزة متاحة للمدير فقط"});
  try{
    const device=mutate(store=>{
      const item=(store.devices||[]).find(row=>row.id===req.params.id);
      if(!item)throw new Error("الجهاز غير موجود");
      if(req.body?.active!==undefined)item.active=Boolean(req.body.active);
      if(req.body?.deviceName!==undefined)item.deviceName=String(req.body.deviceName||"").slice(0,120);
      item.updatedAt=now();
      audit(store,req.user.id,"UPDATE","DEVICE",item.id,{active:item.active});
      return item;
    });
    res.json(device);
  }catch(error){res.status(400).json({message:error.message||"تعذر تحديث الجهاز"})}
});

app.get("/api/legal/privacy", (_req,res)=>res.json({version:"1.0",updatedAt:"2026-07-18",title:"سياسة الخصوصية",content:"يجمع النظام معلومات الحساب ومعرّف التثبيت ونوع الجهاز وإصدار التطبيق وتاريخ أول وآخر استخدام لأغراض الأمان وإدارة التراخيص فقط. لا تُباع البيانات ولا تُشارك مع جهات خارجية، ولا يتم جمع كلمات المرور بصورتها الأصلية. يتحمل مدير الشركة مسؤولية بيانات العملاء المسجلة داخل النظام."}));
app.get("/api/legal/terms", (_req,res)=>res.json({version:"1.0",updatedAt:"2026-07-18",title:"شروط الاستخدام",content:"استخدام البرنامج مخصص للحسابات والأجهزة المصرح بها. يمنع نسخ البرنامج أو إعادة بيعه أو محاولة تجاوز الحماية دون إذن. المستخدم مسؤول عن صحة البيانات والنسخ الاحتياطية والالتزام بالقوانين المحلية."}));


app.get("/api/dashboard", auth, (_req,res)=>{
  const s = readStore();
  const today = new Date().toISOString().slice(0,10);
  const todayTx = s.transactions.filter((t)=>t.createdAt.slice(0,10)===today && t.status!=="CANCELLED");
  const todayExpenses = s.expenses.filter((e)=>e.date===today).reduce((a,e)=>a+Number(e.cadAmount??e.amount),0);
  const totalProfit = todayTx.reduce((a,t)=>a+Number(t.totalProfit||0),0)-todayExpenses;
  const receivables = s.customers.reduce((a,c)=>a+customerSummary(s,c).finalBalance,0);
  const capital = s.capitalMovements.reduce((a,m)=>a+(m.type==="IN"?Number(m.amount):-Number(m.amount)),0);
  res.json({customers:s.customers.length,todayTransactions:todayTx.length,todayProfit:+totalProfit.toFixed(2),receivables:+receivables.toFixed(2),capital:+capital.toFixed(2),recent:todayTx.slice(-8).reverse()});
});



app.get("/api/notification-settings", auth, (_req,res)=>{
  const store=readStore();
  res.json({
    overdueDays:Math.max(1,safeNumber(store.notificationSettings?.overdueDays,7)),
    lowCashLimit:Math.max(0,safeNumber(store.notificationSettings?.lowCashLimit,5000)),
    whatsappTemplate:String(store.notificationSettings?.whatsappTemplate||"")
  });
});

app.patch("/api/notification-settings", auth, (req,res)=>{
  const updated=mutate((store)=>{
    store.notificationSettings ||= {};
    if(req.body?.overdueDays!==undefined){
      const value=Number(req.body.overdueDays);
      if(!Number.isFinite(value)||value<1||value>365)throw new Error("مدة التأخير يجب أن تكون بين 1 و365 يومًا");
      store.notificationSettings.overdueDays=Math.round(value);
    }
    if(req.body?.lowCashLimit!==undefined){
      const value=Number(req.body.lowCashLimit);
      if(!Number.isFinite(value)||value<0)throw new Error("حد السيولة غير صحيح");
      store.notificationSettings.lowCashLimit=value;
    }
    if(req.body?.whatsappTemplate!==undefined){
      store.notificationSettings.whatsappTemplate=String(req.body.whatsappTemplate||"");
    }
    audit(store,req.user.id,"UPDATE","NOTIFICATION_SETTINGS","global",store.notificationSettings);
    return store.notificationSettings;
  });
  res.json(updated);
});

app.get("/api/notifications", auth, (_req,res)=>{
  const store=readStore();
  const customers=(Array.isArray(store.customers)?store.customers:[])
    .map(customer=>customerSummary(store,customer));
  const overdue=customers
    .filter(customer=>customer.overdue)
    .sort((a,b)=>b.overdueDays-a.overdueDays);

  const capital=(Array.isArray(store.capitalMovements)?store.capitalMovements:[])
    .reduce((sum,item)=>sum+(item.type==="IN"?safeNumber(item.amount):-safeNumber(item.amount)),0);
  const lowCashLimit=Math.max(0,safeNumber(store.notificationSettings?.lowCashLimit,5000));

  const notifications=[];
  for(const customer of overdue){
    const severity=customer.overdueDays>=60?"critical":customer.overdueDays>=30?"danger":customer.overdueDays>=15?"warning":"notice";
    notifications.push({
      id:`overdue-${customer.id}`,
      type:"OVERDUE_CUSTOMER",
      severity,
      title:`تأخر دفع: ${customer.name}`,
      message:`متأخر ${customer.overdueDays} يوم — الرصيد ${customer.finalBalance.toFixed(2)} CAD`,
      customerId:customer.id,
      phone:customer.phone||"",
      amount:customer.finalBalance,
      days:customer.overdueDays
    });
  }

  if(capital<lowCashLimit){
    notifications.push({
      id:"low-capital",
      type:"LOW_CAPITAL",
      severity:"danger",
      title:"تنبيه انخفاض السيولة",
      message:`صافي حركة رأس المال ${capital.toFixed(2)} CAD أقل من الحد ${lowCashLimit.toFixed(2)} CAD`
    });
  }

  const incomplete=(Array.isArray(store.transactions)?store.transactions:[])
    .filter(item=>item&&!item.isDeleted&&item.status&&item.status!=="COMPLETED"&&item.status!=="CANCELLED");
  if(incomplete.length){
    notifications.push({
      id:"incomplete-transfers",
      type:"INCOMPLETE_TRANSFERS",
      severity:"warning",
      title:"حوالات تحتاج مراجعة",
      message:`يوجد ${incomplete.length} حوالة غير مكتملة`
    });
  }

  res.json({
    count:notifications.length,
    overdueCount:overdue.length,
    overdueTotal:+overdue.reduce((sum,item)=>sum+safeNumber(item.finalBalance),0).toFixed(2),
    notifications
  });
});

app.post("/api/notification-actions", auth, (req,res)=>{
  const {customerId,action="CONTACTED",notes="",promiseDate=null,expectedAmount=null}=req.body||{};
  const saved=mutate((store)=>{
    store.notificationActions ||= [];
    const item={
      id:id(),
      customerId:customerId||null,
      action,
      notes:String(notes||""),
      promiseDate:promiseDate?String(promiseDate).slice(0,10):null,
      expectedAmount:expectedAmount===null||expectedAmount===""?null:+safeNumber(expectedAmount).toFixed(2),
      createdAt:now(),
      createdBy:req.user.id
    };
    store.notificationActions.push(item);
    audit(store,req.user.id,"CREATE","NOTIFICATION_ACTION",item.id,item);
    return item;
  });
  res.status(201).json(saved);
});

app.get("/api/notification-actions/:customerId", auth, (req,res)=>{
  const store=readStore();
  const rows=(Array.isArray(store.notificationActions)?store.notificationActions:[])
    .filter(item=>item?.customerId===req.params.customerId)
    .sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
  res.json(rows);
});

app.get("/api/customer-alerts", auth, (_req,res)=>{
  const store = readStore();
  const payments=Array.isArray(store.payments)?store.payments:[];
  const actions=Array.isArray(store.notificationActions)?store.notificationActions:[];
  const today=new Date().toISOString().slice(0,10);

  const latestActionByCustomer=new Map();
  for(const action of actions){
    if(!action?.customerId)continue;
    const current=latestActionByCustomer.get(action.customerId);
    if(!current||String(action.createdAt)>String(current.createdAt)){
      latestActionByCustomer.set(action.customerId,action);
    }
  }

  const rows = (Array.isArray(store.customers) ? store.customers : [])
    .map((customer)=>{
      const summary=customerSummary(store,customer);
      const customerPayments=payments
        .filter(payment=>payment&&!payment.isDeleted)
        .filter(payment=>{
          const transaction=(Array.isArray(store.transactions)?store.transactions:[])
            .find(item=>item?.id===payment.transactionId);
          return transaction?.customerId===customer.id;
        })
        .sort((a,b)=>String(b.paymentDate||b.createdAt).localeCompare(String(a.paymentDate||a.createdAt)));
      const latestAction=latestActionByCustomer.get(customer.id)||null;
      return {
        ...summary,
        lastPaymentDate:customerPayments[0]
          ? String(customerPayments[0].paymentDate||customerPayments[0].createdAt).slice(0,10)
          : null,
        latestAction,
        promiseDate:latestAction?.promiseDate||null,
        expectedAmount:latestAction?.expectedAmount??null,
        contacted:latestAction?.action==="CONTACTED"||latestAction?.action==="PROMISE_TO_PAY"
      };
    })
    .filter((customer)=>customer.overdue)
    .sort((a,b)=>b.overdueDays-a.overdueDays);

  const expectedToday=rows.reduce((sum,item)=>{
    if(item.promiseDate!==today)return sum;
    return sum+safeNumber(item.expectedAmount,item.finalBalance);
  },0);

  const largestBalance=rows.reduce((max,item)=>safeNumber(item.finalBalance)>safeNumber(max?.finalBalance)?item:max,null);
  const oldest=rows[0]||null;

  res.json({
    count:rows.length,
    totalOverdue:+rows.reduce((sum,item)=>sum+safeNumber(item.finalBalance),0).toFixed(2),
    largestOverdueBalance:largestBalance?+safeNumber(largestBalance.finalBalance).toFixed(2):0,
    largestOverdueCustomer:largestBalance?.name||null,
    oldestCustomer:oldest?.name||null,
    oldestDays:oldest?.overdueDays||0,
    expectedToday:+expectedToday.toFixed(2),
    rows
  });
});

app.get("/api/capital-overview", auth, (req,res)=>{
  const store=readStore();
  const requestedMonth=String(req.query.month||new Date().toISOString().slice(0,7));
  const transactions=(Array.isArray(store.transactions)?store.transactions:[])
    .filter(item=>item&&!item.isDeleted&&item.status!=="CANCELLED");
  const capitalMovements=Array.isArray(store.capitalMovements)?store.capitalMovements:[];
  const expenses=Array.isArray(store.expenses)?store.expenses:[];
  const customers=Array.isArray(store.customers)?store.customers:[];
  const debts=Array.isArray(store.generalDebts)?store.generalDebts:[];
  const debtPayments=Array.isArray(store.generalDebtPayments)?store.generalDebtPayments:[];

  const capitalBalance=capitalMovements.reduce(
    (sum,item)=>sum+(item.type==="IN"?safeNumber(item.amount):-safeNumber(item.amount)),0
  );

  const monthTransactions=transactions.filter(item=>
    String(item.transferDate||item.createdAt||"").slice(0,7)===requestedMonth
  );

  const monthlyTransferValue=monthTransactions.reduce(
    (sum,item)=>sum+safeNumber(item.amount),0
  );
  const monthlyProfit=monthTransactions.reduce(
    (sum,item)=>sum+safeNumber(item.totalProfit),0
  );
  const monthlyExpenses=expenses
    .filter(item=>String(item.date||item.createdAt||"").slice(0,7)===requestedMonth)
    .reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);

  const receivables=customers.reduce(
    (sum,customer)=>sum+safeNumber(customerSummary(store,customer).finalBalance),0
  );

  const debtPaidById=new Map();
  for(const payment of debtPayments){
    debtPaidById.set(payment.debtId,safeNumber(debtPaidById.get(payment.debtId))+safeNumber(payment.amount));
  }
  let generalReceivable=0;
  let generalPayable=0;
  for(const debt of debts){
    const remaining=Math.max(safeNumber(debt.amount)-safeNumber(debtPaidById.get(debt.id)),0);
    if(debt.type==="RECEIVABLE")generalReceivable+=remaining;
    if(debt.type==="PAYABLE")generalPayable+=remaining;
  }

  const totalCapital=capitalBalance+monthlyProfit-monthlyExpenses+receivables+generalReceivable-generalPayable;
  const turnoverBase=Math.abs(capitalBalance)>0?Math.abs(capitalBalance):Math.abs(totalCapital);
  const turnoverRate=turnoverBase>0?monthlyTransferValue/turnoverBase:0;
  const averageTransfer=monthTransactions.length?monthlyTransferValue/monthTransactions.length:0;

  res.json({
    month:requestedMonth,
    capitalBalance:+capitalBalance.toFixed(2),
    totalCapital:+totalCapital.toFixed(2),
    monthlyTransferValue:+monthlyTransferValue.toFixed(2),
    monthlyTransferCount:monthTransactions.length,
    averageTransfer:+averageTransfer.toFixed(2),
    monthlyProfit:+monthlyProfit.toFixed(2),
    monthlyExpenses:+monthlyExpenses.toFixed(2),
    receivables:+receivables.toFixed(2),
    generalReceivable:+generalReceivable.toFixed(2),
    generalPayable:+generalPayable.toFixed(2),
    turnoverRate:+turnoverRate.toFixed(3)
  });
});

app.get("/api/monthly-report", auth, (req,res)=>{
  const store=readStore();
  const month=String(req.query.month||new Date().toISOString().slice(0,7));

  const transactions=(Array.isArray(store.transactions)?store.transactions:[])
    .filter(item=>item&&!item.isDeleted&&item.status!=="CANCELLED")
    .filter(item=>String(item.transferDate||item.createdAt||"").slice(0,7)===month);

  const expenses=(Array.isArray(store.expenses)?store.expenses:[])
    .filter(item=>String(item.date||item.createdAt||"").slice(0,7)===month);

  const capitalMovements=(Array.isArray(store.capitalMovements)?store.capitalMovements:[])
    .filter(item=>String(item.date||item.createdAt||"").slice(0,7)===month);

  const payments=(Array.isArray(store.payments)?store.payments:[])
    .filter(item=>item&&!item.isDeleted)
    .filter(item=>String(item.paymentDate||item.date||item.createdAt||"").slice(0,7)===month);

  const transferTotal=transactions.reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);
  const feesTotal=transactions.reduce((sum,item)=>sum+safeNumber(item.transferFee),0);
  const exchangeProfit=transactions.reduce((sum,item)=>sum+safeNumber(item.exchangeProfit),0);
  const grossProfit=transactions.reduce((sum,item)=>sum+safeNumber(item.totalProfit),0);
  const expenseTotal=expenses.reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);
  const netProfit=grossProfit-expenseTotal;
  const paidTotal=payments.reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);

  const capitalIn=capitalMovements
    .filter(item=>item.type==="IN")
    .reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);
  const capitalOut=capitalMovements
    .filter(item=>item.type!=="IN")
    .reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);

  const customerMap=new Map();
  for(const transaction of transactions){
    customerMap.set(
      transaction.customerId,
      safeNumber(customerMap.get(transaction.customerId))+safeNumber(transaction.amount)
    );
  }

  const topCustomers=Array.from(customerMap.entries())
    .map(([customerId,total])=>({
      customerId,
      customerName:(Array.isArray(store.customers)?store.customers:[]).find(c=>c.id===customerId)?.name||"-",
      total:+total.toFixed(2)
    }))
    .sort((a,b)=>b.total-a.total)
    .slice(0,10);

  const dailyMap={};
  for(const transaction of transactions){
    const date=String(transaction.transferDate||transaction.createdAt||"").slice(0,10);
    dailyMap[date] ||= {date,count:0,total:0,profit:0};
    dailyMap[date].count+=1;
    dailyMap[date].total+=safeNumber(transaction.amount);
    dailyMap[date].profit+=safeNumber(transaction.totalProfit);
  }

  const daily=Object.values(dailyMap)
    .map(item=>({
      ...item,
      total:+item.total.toFixed(2),
      profit:+item.profit.toFixed(2)
    }))
    .sort((a,b)=>a.date.localeCompare(b.date));

  res.json({
    month,
    generatedAt:now(),
    summary:{
      transferCount:transactions.length,
      transferTotal:+transferTotal.toFixed(2),
      averageTransfer:+(transactions.length?transferTotal/transactions.length:0).toFixed(2),
      largestTransfer:+(transactions.length?Math.max(...transactions.map(item=>safeNumber(item.amount))):0).toFixed(2),
      smallestTransfer:+(transactions.length?Math.min(...transactions.map(item=>safeNumber(item.amount))):0).toFixed(2),
      feesTotal:+feesTotal.toFixed(2),
      exchangeProfit:+exchangeProfit.toFixed(2),
      grossProfit:+grossProfit.toFixed(2),
      expenses:+expenseTotal.toFixed(2),
      netProfit:+netProfit.toFixed(2),
      paymentsReceived:+paidTotal.toFixed(2),
      capitalIn:+capitalIn.toFixed(2),
      capitalOut:+capitalOut.toFixed(2),
      netCapitalMovement:+(capitalIn-capitalOut).toFixed(2)
    },
    daily,
    topCustomers,
    transactions:transactions
      .slice()
      .sort((a,b)=>String(a.transferDate||a.createdAt).localeCompare(String(b.transferDate||b.createdAt)))
  });
});


app.get("/api/customers", auth, (_req,res)=>{ const s=readStore(); res.json(s.customers.filter(c=>!c?.isDeleted).map(c=>customerSummary(s,c)).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))); });
app.post("/api/customers", auth, (req,res)=>{
  const {name,phone="",email="",identityNumber="",notes="",oldBalance=0}=req.body||{};
  if(!String(name).trim()) return res.status(400).json({message:"Customer name is required"});
  const customer=mutate((s)=>{const c={id:id(),name:String(name).trim(),phone,email,identityNumber,notes,oldBalance:+Math.max(safeNumber(oldBalance),0).toFixed(2),oldBalancePaid:0,createdAt:now()};s.customers.push(c);audit(s,req.user.id,"CREATE","CUSTOMER",c.id);return c;});
  res.status(201).json(customer);
});

app.patch("/api/customers/:id", auth, (req,res)=>{
  try{
    const updated=mutate((store)=>{
      const customer=(Array.isArray(store.customers)?store.customers:[])
        .find(item=>item?.id===req.params.id);
      if(!customer)return null;

      const oldData={...customer};
      const allowed=["name","phone","email","address","notes","oldBalance"];
      for(const key of allowed){
        if(req.body[key]!==undefined)customer[key]=req.body[key];
      }
      if(!String(customer.name||"").trim()){
        throw new Error("اسم العميل مطلوب");
      }
      customer.oldBalance=+Math.max(safeNumber(customer.oldBalance),0).toFixed(2);
      customer.oldBalancePaid=+Math.min(Math.max(safeNumber(customer.oldBalancePaid),0),customer.oldBalance).toFixed(2);
      customer.updatedAt=now();
      customer.updatedBy=req.user.id;
      audit(store,req.user.id,"UPDATE","CUSTOMER",customer.id,{oldData,newData:{...customer}});
      return customer;
    });

    if(!updated)return res.status(404).json({message:"العميل غير موجود"});
    res.json(updated);
  }catch(error){
    res.status(400).json({message:error.message||"تعذر تعديل العميل"});
  }
});

app.post("/api/customers/:id/reset-account", auth, (req,res)=>{
  try{
    const result=mutate((store)=>{
      const customer=(Array.isArray(store.customers)?store.customers:[])
        .find(item=>item?.id===req.params.id && !item?.isDeleted);
      if(!customer)return null;

      const before=customerSummary(store,customer);
      const resetAt=now();
      const resetEntry={
        id:id(),
        resetAt,
        resetBy:req.user.id,
        note:String(req.body?.note||"تصفير الحساب وبدء حساب جديد").trim(),
        snapshot:{
          totalTransactions:before.totalTransactions,
          totalPaid:before.totalPaid,
          finalBalance:before.finalBalance,
          oldBalance:before.oldBalance,
          oldBalancePaid:before.oldBalancePaid
        }
      };

      if(!Array.isArray(customer.accountResets))customer.accountResets=[];
      customer.accountResets.push(resetEntry);
      customer.accountResetAt=resetAt;
      customer.updatedAt=resetAt;
      customer.updatedBy=req.user.id;
      audit(store,req.user.id,"RESET_ACCOUNT","CUSTOMER",customer.id,resetEntry);
      return {customer:customerSummary(store,customer),reset:resetEntry};
    });

    if(!result)return res.status(404).json({message:"العميل غير موجود"});
    res.json({message:"تم تصفير حساب العميل وبدء حساب جديد مع حفظ الحساب السابق في الأرشيف",...result});
  }catch(error){
    res.status(400).json({message:error.message||"تعذر تصفير حساب العميل"});
  }
});

app.delete("/api/customers/:id", auth, (req,res)=>{
  try{
    const deleted=mutate((store)=>{
      const customer=(Array.isArray(store.customers)?store.customers:[])
        .find(item=>item?.id===req.params.id && !item?.isDeleted);
      if(!customer)return null;
      customer.isDeleted=true;
      customer.deletedAt=now();
      customer.deletedBy=req.user.id;
      audit(store,req.user.id,"DELETE","CUSTOMER",customer.id,{softDelete:true,name:customer.name});
      return {id:customer.id,name:customer.name};
    });
    if(!deleted)return res.status(404).json({message:"العميل غير موجود أو محذوف مسبقًا"});
    res.json({message:"تم حذف العميل مع الحفاظ على السجلات المالية",customer:deleted});
  }catch(error){
    res.status(400).json({message:error.message||"تعذر حذف العميل"});
  }
});

app.get("/api/customers/:id", auth, (req,res)=>{
  try {
    const store = readStore();
    const customers = Array.isArray(store.customers) ? store.customers : [];
    const allTransactions = (Array.isArray(store.transactions) ? store.transactions : []).filter(item=>!item?.isDeleted);
    const allPayments = (Array.isArray(store.payments) ? store.payments : []).filter(item=>!item?.isDeleted);

    const customer = customers.find((item) => item && item.id === req.params.id && !item.isDeleted);
    if (!customer) return res.status(404).json({message:"العميل غير موجود"});

    const transactions = allTransactions
      .filter((transaction) => transaction && transaction.customerId === customer.id)
      .map((transaction) => {
        const paid = allPayments
          .filter((payment) => payment && payment.transactionId === transaction.id)
          .reduce((sum, payment) => sum + safeNumber(payment.amount), 0);

        const due = safeNumber(
          transaction.totalCustomerDue,
          safeNumber(transaction.amount) + safeNumber(transaction.transferFee)
        );

        return {
          ...transaction,
          number: String(transaction.number || transaction.id || "-"),
          totalCustomerDue: +due.toFixed(2),
          paid: +paid.toFixed(2),
          remaining: +Math.max(due - paid, 0).toFixed(2),
        };
      });

    const transactionIds = new Set(transactions.map((transaction) => transaction.id));
    const payments = allPayments.filter(
      (payment) => payment && transactionIds.has(payment.transactionId)
    );

    res.json({
      customer: customerSummary(store, customer),
      transactions,
      payments,
    });
  } catch (error) {
    console.error("Customer profile error:", error);
    res.status(500).json({message:"تعذر تحميل ملف العميل"});
  }
});

app.get("/api/transactions", auth, (_req,res)=>{
  const s=readStore();
  res.json(
    s.transactions
      .filter(t=>!t.isDeleted)
      .map(t=>{
        const paidAmount=s.payments
          .filter(payment=>payment.transactionId===t.id&&!payment.isDeleted)
          .reduce((sum,payment)=>sum+safeNumber(payment.amount),0);
        const remaining=Math.max(safeNumber(t.totalCustomerDue)-paidAmount,0);
        return {
          ...t,
          customerName:s.customers.find(c=>c.id===t.customerId)?.name||"-",
          paidAmount:+paidAmount.toFixed(2),
          remaining:+remaining.toFixed(2),
          paymentStatus:remaining<=0.001?"PAID":"UNPAID"
        };
      })
      .reverse()
  );
});
app.post("/api/transactions", auth, (req,res)=>{
  const {
    customerId,
    currency="USD",
    amount,
    costRate,
    finalRate,
    transferFee=0,
    feeMethod="ADD",
    rateSource="manual",
    rateUpdatedAt=null,
    status="COMPLETED",
    paymentStatus="UNPAID",
    transferDate=""
  }=req.body||{};

  const nums=[amount,costRate,finalRate,transferFee].map(Number);
  if(nums.some(n=>!Number.isFinite(n))||nums[0]<=0||nums[1]<=0||nums[2]<=0||nums[3]<0){
    return res.status(400).json({message:"قيم الحوالة غير صحيحة"});
  }

  const [a,cost,clientRate,fee]=nums;
  const normalizedCurrency=String(currency||"USD").toUpperCase();
  const baseCustomerDue=a*clientRate;
  const totalCustomerDue=feeMethod==="ADD"?baseCustomerDue+fee:baseCustomerDue;
  const beneficiaryReceives=feeMethod==="DEDUCT"?Math.max(a-fee,0):a;
  const exchangeProfit=a*(clientRate-cost);
  const totalProfit=exchangeProfit+fee;

  const tx=mutate((s)=>{
    if(!s.customers.some(c=>c.id===customerId))throw new Error("Customer not found");
    const n=s.transactions.length+1;
    const t={
      id:id(),
      number:`TRX-${new Date().getFullYear()}-${String(n).padStart(6,"0")}`,
      customerId,
      currency:normalizedCurrency,
      direction:`${normalizedCurrency}_TO_CAD`,
      amount:+a.toFixed(2),
      costRate:cost,
      finalRate:clientRate,
      rateSource,
      rateUpdatedAt,
      transferFee:+fee.toFixed(2),
      feeMethod,
      destinationAmount:+a.toFixed(2),
      beneficiaryReceives:+beneficiaryReceives.toFixed(2),
      exchangeProfit:+exchangeProfit.toFixed(2),
      totalProfit:+totalProfit.toFixed(2),
      totalCustomerDue:+totalCustomerDue.toFixed(2),
      status,
      transferDate:transferDate||new Date().toISOString().slice(0,10),
      createdAt:now(),
      createdBy:req.user.id
    };
    s.transactions.push(t);

    const normalizedPaymentStatus=String(paymentStatus||"UNPAID").toUpperCase();
    if(normalizedPaymentStatus==="PAID"){
      s.payments.push({
        id:id(),
        transactionId:t.id,
        customerId:t.customerId,
        amount:t.totalCustomerDue,
        method:"CASH",
        notes:"تم تسجيل الحوالة كمدفوعة عند الإنشاء",
        reference:"",
        paymentDate:t.transferDate,
        date:now(),
        receivedBy:req.user.id,
        isDeleted:false,
        allocationMode:"TRANSFER_INITIAL_FULL"
      });
    }

    audit(s,req.user.id,"CREATE","TRANSACTION",t.id,{
      currency:t.currency,
      costRate:t.costRate,
      finalRate:t.finalRate,
      rateSource:t.rateSource,
      totalCustomerDue:t.totalCustomerDue,
      totalProfit:t.totalProfit,
      paymentStatus:normalizedPaymentStatus
    });

    return {
      ...t,
      paidAmount:normalizedPaymentStatus==="PAID"?t.totalCustomerDue:0,
      remaining:normalizedPaymentStatus==="PAID"?0:t.totalCustomerDue,
      paymentStatus:normalizedPaymentStatus==="PAID"?"PAID":"UNPAID"
    };
  });

  res.status(201).json(tx);
});

app.post("/api/customers/:id/payments", auth, (req,res)=>{
  try{
    const {amount,method="CASH",notes="",paymentDate="",reference=""}=req.body||{};
    const requested=Number(amount);
    if(!Number.isFinite(requested)||requested<=0){
      return res.status(400).json({message:"مبلغ الدفعة غير صحيح"});
    }

    const result=mutate((store)=>{
      const customer=store.customers.find(item=>item.id===req.params.id);
      if(!customer)throw new Error("العميل غير موجود");

      const rows=store.transactions
        .filter(item=>item.customerId===customer.id&&!item.isDeleted&&item.status!=="CANCELLED")
        .sort((a,b)=>String(a.transferDate||a.createdAt||"").localeCompare(String(b.transferDate||b.createdAt||"")))
        .map(transaction=>{
          const paid=store.payments
            .filter(payment=>payment.transactionId===transaction.id&&!payment.isDeleted)
            .reduce((sum,payment)=>sum+Number(payment.amount||0),0);
          return {transaction,remaining:Math.max(Number(transaction.totalCustomerDue||0)-paid,0)};
        })
        .filter(row=>row.remaining>0.0001);

      const totalRemaining=rows.reduce((sum,row)=>sum+row.remaining,0);
      const oldBalance=Math.max(safeNumber(customer.oldBalance),0);
      const oldBalancePaid=Math.min(Math.max(safeNumber(customer.oldBalancePaid),0),oldBalance);
      const oldBalanceRemaining=Math.max(oldBalance-oldBalancePaid,0);
      const grandRemaining=totalRemaining+oldBalanceRemaining;

      if(grandRemaining<=0)throw new Error("لا يوجد رصيد مستحق على العميل");
      if(requested>grandRemaining+0.001){
        throw new Error(`الدفعة أكبر من الرصيد المتبقي (${grandRemaining.toFixed(2)} CAD)`);
      }

      let left=requested;
      const allocations=[];
      let oldBalanceAllocation=0;
      if(oldBalanceRemaining>0&&left>0.0001){
        oldBalanceAllocation=Math.min(left,oldBalanceRemaining);
        customer.oldBalancePaid=+(oldBalancePaid+oldBalanceAllocation).toFixed(2);
        left-=oldBalanceAllocation;
      }
      for(const row of rows){
        if(left<=0.0001)break;
        const allocated=Math.min(left,row.remaining);
        const payment={
          id:id(),
          transactionId:row.transaction.id,
          customerId:customer.id,
          amount:+allocated.toFixed(2),
          method,
          notes,
          reference,
          paymentDate:paymentDate||new Date().toISOString().slice(0,10),
          date:now(),
          receivedBy:req.user.id,
          isDeleted:false,
          allocationMode:"CUSTOMER_AUTO"
        };
        store.payments.push(payment);
        allocations.push(payment);
        left-=allocated;
      }

      audit(store,req.user.id,"PAYMENT","CUSTOMER",customer.id,{
        amount:+requested.toFixed(2),
        oldBalanceAllocation:+oldBalanceAllocation.toFixed(2),
        allocations:allocations.map(item=>({transactionId:item.transactionId,amount:item.amount}))
      });

      return {customerId:customer.id,amount:+requested.toFixed(2),oldBalanceAllocation:+oldBalanceAllocation.toFixed(2),allocations};
    });

    res.status(201).json(result);
  }catch(error){
    res.status(400).json({message:error.message||"تعذر إضافة الدفعة"});
  }
});

app.post("/api/transactions/:id/payments", auth, (req,res)=>{
  const {amount,method="CASH",notes="",paymentDate="",reference=""}=req.body||{}; const n=Number(amount); if(!Number.isFinite(n)||n<=0)return res.status(400).json({message:"Invalid amount"});
  const payment=mutate((s)=>{const t=s.transactions.find(x=>x.id===req.params.id);if(!t)throw new Error("Transaction not found");const already=s.payments.filter(p=>p.transactionId===t.id).reduce((a,p)=>a+Number(p.amount),0);if(already+n>Number(t.totalCustomerDue)+0.001)throw new Error("Payment exceeds remaining balance");const p={
      id:id(),
      transactionId:t.id,
      amount:+n.toFixed(2),
      method,
      notes,
      reference,
      paymentDate:paymentDate||new Date().toISOString().slice(0,10),
      date:now(),
      receivedBy:req.user.id,
      isDeleted:false
    };s.payments.push(p);audit(s,req.user.id,"PAYMENT","TRANSACTION",t.id,{amount:n});return p;});

  res.status(201).json(payment);
});

app.patch("/api/transactions/:id", auth, (req,res)=>{
  try{
    const updated=mutate((s)=>{
      const transaction=s.transactions.find(item=>item.id===req.params.id&&!item.isDeleted);
      if(!transaction)return null;

      const allowed=["currency","amount","costRate","finalRate","transferFee","feeMethod","transferDate","status","rateSource","rateUpdatedAt"];
      const oldData={...transaction};

      for(const key of allowed){
        if(req.body[key]!==undefined)transaction[key]=req.body[key];
      }

      const amount=Number(transaction.amount);
      const cost=Number(transaction.costRate);
      const finalRate=Number(transaction.finalRate);
      const fee=Number(transaction.transferFee||0);

      if(![amount,cost,finalRate,fee].every(Number.isFinite)||amount<=0||cost<=0||finalRate<=0||fee<0){
        throw new Error("قيم الحوالة غير صحيحة");
      }

      const baseCustomerDue=amount*finalRate;
      const exchangeProfit=amount*(finalRate-cost);

      transaction.currency=String(transaction.currency||"USD").toUpperCase();
      transaction.direction=`${transaction.currency}_TO_CAD`;
      transaction.destinationAmount=+amount.toFixed(2);
      transaction.beneficiaryReceives=+(transaction.feeMethod==="DEDUCT"?Math.max(amount-fee,0):amount).toFixed(2);
      transaction.exchangeProfit=+exchangeProfit.toFixed(2);
      transaction.totalProfit=+(exchangeProfit+fee).toFixed(2);
      transaction.totalCustomerDue=+(transaction.feeMethod==="ADD"?baseCustomerDue+fee:baseCustomerDue).toFixed(2);
      transaction.updatedAt=now();
      transaction.updatedBy=req.user.id;

      const paid=s.payments
        .filter(p=>p.transactionId===transaction.id&&!p.isDeleted)
        .reduce((sum,p)=>sum+Number(p.amount||0),0);
      if(paid>transaction.totalCustomerDue+0.001){
        throw new Error("لا يمكن جعل إجمالي الحوالة أقل من الدفعات المسجلة");
      }

      audit(s,req.user.id,"UPDATE","TRANSACTION",transaction.id,{oldData,newData:{...transaction}});
      return transaction;
    });

    if(!updated)return res.status(404).json({message:"الحوالة غير موجودة"});
    res.json(updated);
  }catch(error){
    res.status(400).json({message:error.message||"تعذر تعديل الحوالة"});
  }
});

app.delete("/api/transactions/:id", auth, (req,res)=>{
  const deleted=mutate((s)=>{
    const transaction=s.transactions.find(item=>item.id===req.params.id&&!item.isDeleted);
    if(!transaction)return null;
    transaction.isDeleted=true;
    transaction.deletedAt=now();
    transaction.deletedBy=req.user.id;

    for(const payment of s.payments){
      if(payment.transactionId===transaction.id&&!payment.isDeleted){
        payment.isDeleted=true;
        payment.deletedAt=now();
        payment.deletedBy=req.user.id;
      }
    }

    audit(s,req.user.id,"DELETE","TRANSACTION",transaction.id,{softDelete:true});
    return transaction;
  });

  if(!deleted)return res.status(404).json({message:"الحوالة غير موجودة"});
  res.json({message:"تم حذف الحوالة ونقلها إلى المحذوفات"});
});

app.patch("/api/payments/:id", auth, (req,res)=>{
  try{
    const updated=mutate((s)=>{
      const payment=s.payments.find(item=>item.id===req.params.id&&!item.isDeleted);
      if(!payment)return null;
      const transaction=s.transactions.find(item=>item.id===payment.transactionId&&!item.isDeleted);
      if(!transaction)throw new Error("الحوالة غير موجودة");

      const oldData={...payment};
      if(req.body.amount!==undefined)payment.amount=Number(req.body.amount);
      if(req.body.method!==undefined)payment.method=req.body.method;
      if(req.body.notes!==undefined)payment.notes=req.body.notes;
      if(req.body.reference!==undefined)payment.reference=req.body.reference;
      if(req.body.paymentDate!==undefined)payment.paymentDate=req.body.paymentDate;

      if(!Number.isFinite(payment.amount)||payment.amount<=0)throw new Error("مبلغ الدفعة غير صحيح");

      const totalPaid=s.payments
        .filter(item=>item.transactionId===transaction.id&&!item.isDeleted)
        .reduce((sum,item)=>sum+Number(item.amount||0),0);

      if(totalPaid>Number(transaction.totalCustomerDue)+0.001){
        throw new Error("إجمالي الدفعات أكبر من رصيد الحوالة");
      }

      payment.updatedAt=now();
      payment.updatedBy=req.user.id;
      audit(s,req.user.id,"UPDATE","PAYMENT",payment.id,{oldData,newData:{...payment}});
      return payment;
    });

    if(!updated)return res.status(404).json({message:"الدفعة غير موجودة"});
    res.json(updated);
  }catch(error){
    res.status(400).json({message:error.message||"تعذر تعديل الدفعة"});
  }
});

app.delete("/api/payments/:id", auth, (req,res)=>{
  const deleted=mutate((s)=>{
    const payment=s.payments.find(item=>item.id===req.params.id&&!item.isDeleted);
    if(!payment)return null;
    payment.isDeleted=true;
    payment.deletedAt=now();
    payment.deletedBy=req.user.id;
    audit(s,req.user.id,"DELETE","PAYMENT",payment.id,{softDelete:true});
    return payment;
  });

  if(!deleted)return res.status(404).json({message:"الدفعة غير موجودة"});
  res.json({message:"تم حذف الدفعة"});
});



const AUTO_RATE_PAIRS = [
  ["CAD","USD"], ["USD","CAD"], ["USD","AED"], ["AED","USD"],
  ["EUR","USD"], ["USD","EUR"], ["GBP","USD"], ["USD","GBP"]
];

const TROY_OUNCE_GRAMS = 31.1034768;
const GOLD_KARATS = [
  ["XAU24", 24/24],
  ["XAU22", 22/24],
  ["XAU21", 21/24],
  ["XAU18", 18/24]
];

async function fetchOfficialRate(baseCurrency, quoteCurrency) {
  const url = `https://api.frankfurter.dev/v2/rate/${encodeURIComponent(baseCurrency)}/${encodeURIComponent(quoteCurrency)}`;
  const response = await fetch(url, {
    headers: { "Accept": "application/json", "User-Agent": "AlAboud-Cloud/16.0.7" }
  });
  if (!response.ok) throw new Error(`Rate provider returned ${response.status}`);
  const data = await response.json();
  const rate = Number(data.rate);
  if (!Number.isFinite(rate) || rate <= 0) throw new Error("Invalid rate received");
  return { rate, date: data.date || new Date().toISOString().slice(0,10) };
}

async function fetchSyrianPoundRate() {
  const response = await fetch("https://open.er-api.com/v6/latest/USD", {
    headers: { "Accept": "application/json", "User-Agent": "AlAboud-Cloud/16.0.7" }
  });
  if (!response.ok) throw new Error(`SYP provider returned ${response.status}`);
  const data = await response.json();
  if (data.result !== "success") throw new Error(data["error-type"] || "SYP provider failed");
  const rate = Number(data.rates?.SYP);
  if (!Number.isFinite(rate) || rate <= 0) throw new Error("SYP rate is unavailable");
  return {
    rate,
    updatedAt:data.time_last_update_utc || new Date().toISOString(),
    nextUpdate:data.time_next_update_utc || null
  };
}

async function fetchGoldPriceCad() {
  const response = await fetch("https://api.gold-api.com/price/XAU/CAD", {
    headers: { "Accept": "application/json", "User-Agent": "AlAboud-Cloud/16.0.7" }
  });
  if (!response.ok) throw new Error(`Gold provider returned ${response.status}`);
  const data = await response.json();
  const pricePerOunceCad = Number(data.price);
  if (!Number.isFinite(pricePerOunceCad) || pricePerOunceCad <= 0) {
    throw new Error("Gold price is unavailable");
  }
  return {
    pricePerOunceCad,
    updatedAt:data.updatedAt || new Date().toISOString()
  };
}

function saveAutomaticRate({baseCurrency,quoteCurrency,rate,source,notes,sourceDate,userId}) {
  return mutate((store)=>{
    const x = {
      id:id(),
      baseCurrency,
      quoteCurrency,
      buyRate:rate,
      sellRate:rate,
      notes,
      source,
      sourceDate:sourceDate || new Date().toISOString(),
      isAutomatic:true,
      createdAt:now(),
      createdBy:userId
    };
    store.exchangeRates.push(x);
    audit(store,userId,"AUTO_REFRESH","EXCHANGE_RATE",x.id,{
      baseCurrency,quoteCurrency,rate,source
    });
    return x;
  });
}

async function refreshAutomaticRates(userId="SYSTEM") {
  const results = [];

  for (const [baseCurrency, quoteCurrency] of AUTO_RATE_PAIRS) {
    try {
      const official = await fetchOfficialRate(baseCurrency, quoteCurrency);
      const saved = saveAutomaticRate({
        baseCurrency,
        quoteCurrency,
        rate:official.rate,
        source:"FRANKFURTER",
        notes:"تحديث تلقائي من أسعار مرجعية للبنوك المركزية",
        sourceDate:official.date,
        userId
      });
      results.push({ok:true, pair:`${baseCurrency}/${quoteCurrency}`, rate:saved.buyRate, source:"FRANKFURTER"});
    } catch (error) {
      results.push({ok:false, pair:`${baseCurrency}/${quoteCurrency}`, error:error.message});
    }
  }

  try {
    const syp = await fetchSyrianPoundRate();
    const saved = saveAutomaticRate({
      baseCurrency:"USD",
      quoteCurrency:"SYP",
      rate:syp.rate,
      source:"EXCHANGE_RATE_API",
      notes:"تحديث تلقائي لسعر USD/SYP من ExchangeRate-API",
      sourceDate:syp.updatedAt,
      userId
    });
    results.push({ok:true,pair:"USD/SYP",rate:saved.buyRate,source:"EXCHANGE_RATE_API"});
  } catch (error) {
    results.push({ok:false,pair:"USD/SYP",error:error.message});
  }

  try {
    const gold = await fetchGoldPriceCad();
    const pureGramCad = gold.pricePerOunceCad / TROY_OUNCE_GRAMS;
    for (const [baseCurrency, purity] of GOLD_KARATS) {
      const gramRate = +(pureGramCad * purity).toFixed(4);
      const saved = saveAutomaticRate({
        baseCurrency,
        quoteCurrency:"CAD",
        rate:gramRate,
        source:"GOLD_API",
        notes:`سعر غرام الذهب التلقائي — ${baseCurrency.replace("XAU","")} قيراط`,
        sourceDate:gold.updatedAt,
        userId
      });
      results.push({ok:true,pair:`${baseCurrency}/CAD`,rate:saved.buyRate,source:"GOLD_API"});
    }
  } catch (error) {
    for (const [baseCurrency] of GOLD_KARATS) {
      results.push({ok:false,pair:`${baseCurrency}/CAD`,error:error.message});
    }
  }

  return results;
}

app.get("/api/profits", auth, (req,res)=>{
  const s = readStore();
  const from = String(req.query.from || "");
  const to = String(req.query.to || "");
  const inRange = (iso) => {
    const d = String(iso || "").slice(0,10);
    return (!from || d >= from) && (!to || d <= to);
  };

  const transactions = s.transactions.filter((t)=>t.status!=="CANCELLED" && inRange(t.createdAt));
  const expenses = s.expenses.filter((e)=>inRange(e.date || e.createdAt));

  const exchangeProfit = transactions.reduce((a,t)=>a+Number(t.exchangeProfit||0),0);
  const transferFees = transactions.reduce((a,t)=>a+Number(t.transferFee||0),0);
  const grossProfit = transactions.reduce((a,t)=>a+Number(t.totalProfit||0),0);
  const totalExpenses = expenses.reduce((a,e)=>a+Number(e.cadAmount??e.amount??0),0);
  const netProfit = grossProfit-totalExpenses;

  const byMonthMap = {};
  for (const t of transactions) {
    const month = String(t.createdAt).slice(0,7);
    byMonthMap[month] ||= {month,exchangeProfit:0,transferFees:0,grossProfit:0,expenses:0,netProfit:0};
    byMonthMap[month].exchangeProfit += Number(t.exchangeProfit||0);
    byMonthMap[month].transferFees += Number(t.transferFee||0);
    byMonthMap[month].grossProfit += Number(t.totalProfit||0);
  }
  for (const e of expenses) {
    const month = String(e.date || e.createdAt).slice(0,7);
    byMonthMap[month] ||= {month,exchangeProfit:0,transferFees:0,grossProfit:0,expenses:0,netProfit:0};
    byMonthMap[month].expenses += Number(e.cadAmount??e.amount??0);
  }
  const monthly = Object.values(byMonthMap)
    .map((x)=>({...x,
      exchangeProfit:+x.exchangeProfit.toFixed(2),
      transferFees:+x.transferFees.toFixed(2),
      grossProfit:+x.grossProfit.toFixed(2),
      expenses:+x.expenses.toFixed(2),
      netProfit:+(x.grossProfit-x.expenses).toFixed(2)
    }))
    .sort((a,b)=>b.month.localeCompare(a.month));

  res.json({
    from: from || null,
    to: to || null,
    transactionCount: transactions.length,
    exchangeProfit:+exchangeProfit.toFixed(2),
    transferFees:+transferFees.toFixed(2),
    grossProfit:+grossProfit.toFixed(2),
    expenses:+totalExpenses.toFixed(2),
    netProfit:+netProfit.toFixed(2),
    monthly,
    transactions: transactions.slice().reverse()
  });
});


app.post("/api/exchange-rates/refresh", auth, async (req,res)=>{
  try {
    const results = await refreshAutomaticRates(req.user.id);
    const successCount = results.filter(x=>x.ok).length;
    res.json({
      message:`تم تحديث ${successCount} من ${results.length} أسعار تلقائية، بما فيها الليرة السورية والذهب عند توفر المصدر.`,
      successCount,
      total:results.length,
      updatedAt:now(),
      results
    });
  } catch (error) {
    res.status(502).json({message:"تعذر تحديث أسعار الصرف",error:error.message});
  }
});

app.get("/api/exchange-rates", auth, (_req,res)=>{
  const s = readStore();
  const latest = new Map();
  for (const rate of s.exchangeRates.slice().sort((a,b)=>b.createdAt.localeCompare(a.createdAt))) {
    const key = `${rate.baseCurrency}_${rate.quoteCurrency}`;
    if (!latest.has(key)) latest.set(key, rate);
  }
  res.json(Array.from(latest.values()).sort((a,b)=>a.baseCurrency.localeCompare(b.baseCurrency)));
});

app.get("/api/exchange-rates/history", auth, (req,res)=>{
  const s = readStore();
  const base = String(req.query.base || "");
  const quote = String(req.query.quote || "");
  const list = s.exchangeRates.filter((r)=>
    (!base || r.baseCurrency===base) &&
    (!quote || r.quoteCurrency===quote)
  ).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
  res.json(list);
});

app.post("/api/exchange-rates", auth, (req,res)=>{
  const {baseCurrency,quoteCurrency,buyRate,sellRate,notes=""}=req.body||{};
  const buy=Number(buyRate), sell=Number(sellRate);
  if(!baseCurrency||!quoteCurrency||baseCurrency===quoteCurrency||!Number.isFinite(buy)||!Number.isFinite(sell)||buy<=0||sell<=0){
    return res.status(400).json({message:"Invalid exchange rate"});
  }
  const rate=mutate((s)=>{
    const x={
      id:id(),
      baseCurrency:String(baseCurrency).toUpperCase(),
      quoteCurrency:String(quoteCurrency).toUpperCase(),
      buyRate:buy,
      sellRate:sell,
      notes,
      createdAt:now(),
      createdBy:req.user.id
    };
    s.exchangeRates.push(x);
    audit(s,req.user.id,"CREATE","EXCHANGE_RATE",x.id,{baseCurrency:x.baseCurrency,quoteCurrency:x.quoteCurrency});
    return x;
  });
  res.status(201).json(rate);
});


app.get("/api/general-debts", auth, (req,res)=>{
  const store = readStore();
  const debts = Array.isArray(store.generalDebts) ? store.generalDebts : [];
  const debtPayments = Array.isArray(store.generalDebtPayments) ? store.generalDebtPayments : [];
  const transactions = (Array.isArray(store.transactions) ? store.transactions : [])
    .filter((item)=>item && !item.isDeleted && item.status!=="CANCELLED");
  const payments = (Array.isArray(store.payments) ? store.payments : [])
    .filter((item)=>item && !item.isDeleted);
  const customers = Array.isArray(store.customers) ? store.customers : [];
  const type = String(req.query.type || "");

  const manualRows = debts.map((debt)=>{
    const paid = debtPayments
      .filter((payment)=>payment.debtId===debt.id)
      .reduce((sum,payment)=>sum+safeNumber(payment.amount),0);
    const amount = safeNumber(debt.amount);
    const remaining = Math.max(amount-paid,0);
    let status = debt.status || "OPEN";
    if (remaining <= 0) status = "PAID";
    else if (paid > 0) status = "PARTIAL";
    else if (debt.dueDate && debt.dueDate < new Date().toISOString().slice(0,10)) status = "OVERDUE";

    return {
      ...debt,
      source:"MANUAL",
      paid:+paid.toFixed(2),
      remaining:+remaining.toFixed(2),
      status,
    };
  });

  const paidByTransaction = new Map();
  for (const payment of payments) {
    paidByTransaction.set(
      payment.transactionId,
      safeNumber(paidByTransaction.get(payment.transactionId)) + safeNumber(payment.amount)
    );
  }

  const transferRows = transactions.map((transaction)=>{
    const amount = safeNumber(transaction.totalCustomerDue, transaction.amount);
    const paid = safeNumber(paidByTransaction.get(transaction.id));
    const remaining = Math.max(amount-paid,0);
    if (remaining <= 0.001) return null;
    const customer = customers.find((item)=>item.id===transaction.customerId);
    const transferDate = String(transaction.transferDate || transaction.createdAt || "").slice(0,10);
    return {
      id:`TRANSFER:${transaction.id}`,
      type:"RECEIVABLE",
      partyName:customer?.name || "عميل بدون اسم",
      amount:+amount.toFixed(2),
      currency:"CAD",
      dueDate:transferDate,
      description:`حوالة غير مدفوعة ${transaction.number || ""}`.trim(),
      reference:transaction.number || "",
      status:paid>0?"PARTIAL":"OPEN",
      source:"TRANSFER",
      transactionId:transaction.id,
      customerId:transaction.customerId,
      createdAt:transaction.createdAt || transaction.transferDate || now(),
      paid:+paid.toFixed(2),
      remaining:+remaining.toFixed(2),
    };
  }).filter(Boolean);

  const partners = Array.isArray(store.partners) ? store.partners : [];
  const partnerTransactions = Array.isArray(store.partnerTransactions) ? store.partnerTransactions : [];
  const partnerPayments = Array.isArray(store.partnerPayments) ? store.partnerPayments : [];
  const partnerRows = [];

  for (const partner of partners) {
    const transactionsForPartner = partnerTransactions.filter((item)=>item.partnerId===partner.id);
    const paymentsForPartner = partnerPayments.filter((item)=>item.partnerId===partner.id);
    const currencies = new Set([
      ...transactionsForPartner.map((item)=>String(item.currency||"CAD").toUpperCase()),
      ...paymentsForPartner.map((item)=>String(item.currency||"CAD").toUpperCase())
    ]);

    for (const currency of currencies) {
      const receivable = transactionsForPartner
        .filter((item)=>item.type==="RECEIVABLE" && String(item.currency||"CAD").toUpperCase()===currency)
        .reduce((sum,item)=>sum+safeNumber(item.amount),0);
      const payable = transactionsForPartner
        .filter((item)=>item.type==="PAYABLE" && String(item.currency||"CAD").toUpperCase()===currency)
        .reduce((sum,item)=>sum+safeNumber(item.amount),0);
      const received = paymentsForPartner
        .filter((item)=>item.direction==="RECEIVED" && String(item.currency||"CAD").toUpperCase()===currency)
        .reduce((sum,item)=>sum+safeNumber(item.amount),0);
      const paid = paymentsForPartner
        .filter((item)=>item.direction==="PAID" && String(item.currency||"CAD").toUpperCase()===currency)
        .reduce((sum,item)=>sum+safeNumber(item.amount),0);

      const receivableRemaining = Math.max(receivable-received,0);
      const payableRemaining = Math.max(payable-paid,0);
      if (receivableRemaining>0.001) partnerRows.push({
        id:`PARTNER:RECEIVABLE:${partner.id}:${currency}`,
        type:"RECEIVABLE", partyName:partner.name, amount:+receivable.toFixed(2),
        paid:+received.toFixed(2), remaining:+receivableRemaining.toFixed(2), currency,
        dueDate:"", description:"رصيد شركة مرتبط", reference:partner.integrationName||partner.name,
        status:received>0?"PARTIAL":"OPEN", source:"PARTNER", partnerId:partner.id,
        createdAt:partner.updatedAt||partner.createdAt||now()
      });
      if (payableRemaining>0.001) partnerRows.push({
        id:`PARTNER:PAYABLE:${partner.id}:${currency}`,
        type:"PAYABLE", partyName:partner.name, amount:+payable.toFixed(2),
        paid:+paid.toFixed(2), remaining:+payableRemaining.toFixed(2), currency,
        dueDate:"", description:"رصيد شركة مرتبط", reference:partner.integrationName||partner.name,
        status:paid>0?"PARTIAL":"OPEN", source:"PARTNER", partnerId:partner.id,
        createdAt:partner.updatedAt||partner.createdAt||now()
      });
    }

    // أرصدة الشركات الخارجية متعددة العملات تظهر في الدين العام حسب العملة الأصلية لكل رصيد.
    // externalBalances مثال: { USD:{receivable,payable,balance}, EUR:{...} }
    const externalCreatedAt = partner.lastSyncAt || partner.updatedAt || partner.createdAt || now();
    const multiCurrencyBalances = partner.externalBalances && typeof partner.externalBalances === "object"
      ? partner.externalBalances
      : null;
    const multiEntries = multiCurrencyBalances
      ? Object.entries(multiCurrencyBalances).filter(([currency,value])=>currency && value && typeof value === "object")
      : [];

    if (multiEntries.length) {
      for (const [rawCurrency, value] of multiEntries) {
        const currency = String(rawCurrency || "USD").toUpperCase();
        const receivable = Math.max(safeNumber(value.receivable), 0);
        const payable = Math.max(safeNumber(value.payable), 0);
        if (receivable > 0.001) partnerRows.push({
          id:`PARTNER:EXTERNAL:RECEIVABLE:${partner.id}:${currency}`,
          type:"RECEIVABLE", partyName:partner.name, amount:+receivable.toFixed(2), paid:0,
          remaining:+receivable.toFixed(2), currency, dueDate:"",
          description:`دين لنا من الرصيد الخارجي لشركة ${partner.name}`,
          reference:partner.integrationName || partner.name, status:"OPEN", source:"PARTNER_EXTERNAL",
          partnerId:partner.id, createdAt:externalCreatedAt, lastSyncAt:partner.lastSyncAt || null
        });
        if (payable > 0.001) partnerRows.push({
          id:`PARTNER:EXTERNAL:PAYABLE:${partner.id}:${currency}`,
          type:"PAYABLE", partyName:partner.name, amount:+payable.toFixed(2), paid:0,
          remaining:+payable.toFixed(2), currency, dueDate:"",
          description:`دين علينا من الرصيد الخارجي لشركة ${partner.name}`,
          reference:partner.integrationName || partner.name, status:"OPEN", source:"PARTNER_EXTERNAL",
          partnerId:partner.id, createdAt:externalCreatedAt, lastSyncAt:partner.lastSyncAt || null
        });
      }
    } else {
      // توافق مع السجلات القديمة ذات العملة الواحدة.
      const externalCurrency = String(partner.accountCurrency || "USD").toUpperCase();
      const externalReceivable = Math.max(safeNumber(partner.externalReceivable), 0);
      const externalPayable = Math.max(safeNumber(partner.externalPayable), 0);
      const hasDetailedExternalDebt = externalReceivable > 0.001 || externalPayable > 0.001;
      if (externalReceivable > 0.001) partnerRows.push({
        id:`PARTNER:EXTERNAL:RECEIVABLE:${partner.id}:${externalCurrency}`, type:"RECEIVABLE",
        partyName:partner.name, amount:+externalReceivable.toFixed(2), paid:0, remaining:+externalReceivable.toFixed(2),
        currency:externalCurrency, dueDate:"", description:`دين لنا من الرصيد الخارجي لشركة ${partner.name}`,
        reference:partner.integrationName || partner.name, status:"OPEN", source:"PARTNER_EXTERNAL",
        partnerId:partner.id, createdAt:externalCreatedAt, lastSyncAt:partner.lastSyncAt || null
      });
      if (externalPayable > 0.001) partnerRows.push({
        id:`PARTNER:EXTERNAL:PAYABLE:${partner.id}:${externalCurrency}`, type:"PAYABLE",
        partyName:partner.name, amount:+externalPayable.toFixed(2), paid:0, remaining:+externalPayable.toFixed(2),
        currency:externalCurrency, dueDate:"", description:`دين علينا من الرصيد الخارجي لشركة ${partner.name}`,
        reference:partner.integrationName || partner.name, status:"OPEN", source:"PARTNER_EXTERNAL",
        partnerId:partner.id, createdAt:externalCreatedAt, lastSyncAt:partner.lastSyncAt || null
      });
      if (!hasDetailedExternalDebt) {
        const externalBalance = safeNumber(partner.externalBalance);
        if (Math.abs(externalBalance) > 0.001) {
          const externalType = externalBalance < 0 ? "PAYABLE" : "RECEIVABLE";
          const externalAmount = Math.abs(externalBalance);
          partnerRows.push({
            id:`PARTNER:EXTERNAL:BALANCE:${partner.id}:${externalCurrency}`, type:externalType,
            partyName:partner.name, amount:+externalAmount.toFixed(2), paid:0, remaining:+externalAmount.toFixed(2),
            currency:externalCurrency, dueDate:"", description:`الرصيد الخارجي لشركة ${partner.name}`,
            reference:partner.integrationName || partner.name, status:"OPEN", source:"PARTNER_EXTERNAL",
            partnerId:partner.id, createdAt:externalCreatedAt, lastSyncAt:partner.lastSyncAt || null
          });
        }
      }
    }
  }

  const rows = [...manualRows, ...transferRows, ...partnerRows]
    .filter((debt)=>!type || debt.type===type)
    .sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));

  const totalsByCurrency = {};
  for (const row of rows) {
    const currency = String(row.currency || "CAD").toUpperCase();
    if (!totalsByCurrency[currency]) totalsByCurrency[currency] = {receivable:0,payable:0,net:0};
    if (row.type==="RECEIVABLE") totalsByCurrency[currency].receivable += safeNumber(row.remaining);
    if (row.type==="PAYABLE") totalsByCurrency[currency].payable += safeNumber(row.remaining);
    totalsByCurrency[currency].net = totalsByCurrency[currency].receivable - totalsByCurrency[currency].payable;
  }
  for (const currency of Object.keys(totalsByCurrency)) {
    totalsByCurrency[currency] = {
      receivable:+totalsByCurrency[currency].receivable.toFixed(2),
      payable:+totalsByCurrency[currency].payable.toFixed(2),
      net:+totalsByCurrency[currency].net.toFixed(2),
    };
  }

  // Convert every currency total to the requested base currency for the top summary cards.
  // Latest exchange rates are treated as quote units per 1 base unit.
  const summaryCurrency = String(req.query.summaryCurrency || "CAD").toUpperCase();
  const latestRates = new Map();
  for (const rate of (Array.isArray(store.exchangeRates) ? store.exchangeRates : [])
    .slice().sort((a,b)=>String(b.createdAt||"").localeCompare(String(a.createdAt||"")))) {
    const base = String(rate.baseCurrency || "").toUpperCase();
    const quote = String(rate.quoteCurrency || "").toUpperCase();
    if (!base || !quote || base===quote) continue;
    const key = `${base}_${quote}`;
    if (!latestRates.has(key)) latestRates.set(key, rate);
  }

  const graph = new Map();
  const addEdge = (from,to,factor,sourceUpdatedAt)=>{
    if (!from || !to || !Number.isFinite(factor) || factor<=0) return;
    if (!graph.has(from)) graph.set(from,[]);
    graph.get(from).push({to,factor,sourceUpdatedAt});
  };
  for (const rate of latestRates.values()) {
    const base = String(rate.baseCurrency || "").toUpperCase();
    const quote = String(rate.quoteCurrency || "").toUpperCase();
    const direct = safeNumber(rate.sellRate, rate.buyRate);
    if (direct>0) {
      addEdge(base,quote,direct,rate.createdAt||null);
      addEdge(quote,base,1/direct,rate.createdAt||null);
    }
  }

  const findConversion = (from,to)=>{
    if (from===to) return {factor:1,path:[from],updatedAt:null};
    const queue=[{currency:from,factor:1,path:[from],updatedAt:null}];
    const seen=new Set([from]);
    while(queue.length){
      const current=queue.shift();
      for(const edge of (graph.get(current.currency)||[])){
        if(seen.has(edge.to)) continue;
        const next={
          currency:edge.to,
          factor:current.factor*edge.factor,
          path:[...current.path,edge.to],
          updatedAt:[current.updatedAt,edge.sourceUpdatedAt].filter(Boolean).sort().pop()||null
        };
        if(edge.to===to) return next;
        seen.add(edge.to);
        queue.push(next);
      }
    }
    return null;
  };

  let convertedReceivable=0;
  let convertedPayable=0;
  const conversionDetails={};
  const missingRates=[];
  let ratesUpdatedAt=null;
  for (const [currency,total] of Object.entries(totalsByCurrency)) {
    const conversion=findConversion(currency,summaryCurrency);
    if (!conversion) {
      missingRates.push(currency);
      conversionDetails[currency]={available:false,from:currency,to:summaryCurrency};
      continue;
    }
    const receivable=safeNumber(total.receivable)*conversion.factor;
    const payable=safeNumber(total.payable)*conversion.factor;
    convertedReceivable+=receivable;
    convertedPayable+=payable;
    if(conversion.updatedAt && (!ratesUpdatedAt || conversion.updatedAt>ratesUpdatedAt)) ratesUpdatedAt=conversion.updatedAt;
    conversionDetails[currency]={
      available:true,
      from:currency,
      to:summaryCurrency,
      factor:+conversion.factor.toFixed(8),
      path:conversion.path,
      receivable:+receivable.toFixed(2),
      payable:+payable.toFixed(2),
      net:+(receivable-payable).toFixed(2),
      updatedAt:conversion.updatedAt
    };
  }

  const convertedTotals={
    receivable:+convertedReceivable.toFixed(2),
    payable:+convertedPayable.toFixed(2),
    net:+(convertedReceivable-convertedPayable).toFixed(2)
  };

  res.json({
    rows,
    totals:convertedTotals,
    summaryCurrency,
    totalsByCurrency,
    conversionDetails,
    missingRates,
    ratesUpdatedAt,
    automaticTransferDebts:transferRows.length,
    automaticCompanyDebts:partnerRows.length
  });
});

app.post("/api/general-debts", auth, (req,res)=>{
  const {
    type,
    partyName,
    amount,
    currency="CAD",
    dueDate="",
    description="",
    reference=""
  } = req.body || {};

  const numericAmount = Number(amount);
  const normalizedCurrency = String(currency || "CAD").toUpperCase();
  const supportedDebtCurrencies = ["CAD","USD","EUR","SYP","TRY","SAR","AED","GBP"];

  if (!["RECEIVABLE","PAYABLE"].includes(type)) {
    return res.status(400).json({message:"نوع الدين غير صحيح"});
  }
  if (!partyName || !Number.isFinite(numericAmount) || numericAmount <= 0) {
    return res.status(400).json({message:"أدخل اسم الجهة ومبلغًا صحيحًا"});
  }
  if (!supportedDebtCurrencies.includes(normalizedCurrency)) {
    return res.status(400).json({message:"عملة الدين غير مدعومة"});
  }

  const debt = mutate((store)=>{
    const item = {
      id:id(),
      type,
      partyName:String(partyName),
      amount:numericAmount,
      currency:normalizedCurrency,
      dueDate:dueDate || "",
      description,
      reference,
      status:"OPEN",
      createdAt:now(),
      createdBy:req.user.id
    };
    store.generalDebts.push(item);
    audit(store, req.user.id, "CREATE", "GENERAL_DEBT", item.id, {
      type:item.type,
      partyName:item.partyName,
      amount:item.amount
    });
    return item;
  });

  res.status(201).json(debt);
});

app.get("/api/general-debts/:id/payments", auth, (req,res)=>{
  const store = readStore();
  const list = (Array.isArray(store.generalDebtPayments) ? store.generalDebtPayments : [])
    .filter((payment)=>payment.debtId===req.params.id)
    .sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
  res.json(list);
});

app.post("/api/general-debts/:id/payments", auth, (req,res)=>{
  const numericAmount = Number(req.body?.amount);
  const paymentDate = req.body?.paymentDate || new Date().toISOString().slice(0,10);
  const notes = req.body?.notes || "";

  if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
    return res.status(400).json({message:"مبلغ الدفعة غير صحيح"});
  }

  const store = readStore();
  const debt = (Array.isArray(store.generalDebts) ? store.generalDebts : [])
    .find((item)=>item.id===req.params.id);

  if (!debt) {
    return res.status(404).json({message:"الدين غير موجود"});
  }

  const previousPaid = (Array.isArray(store.generalDebtPayments) ? store.generalDebtPayments : [])
    .filter((payment)=>payment.debtId===debt.id)
    .reduce((sum,payment)=>sum+safeNumber(payment.amount),0);

  const remaining = Math.max(safeNumber(debt.amount)-previousPaid,0);

  if (numericAmount > remaining + 0.0001) {
    return res.status(400).json({message:"الدفعة أكبر من المبلغ المتبقي"});
  }

  const payment = mutate((currentStore)=>{
    const item = {
      id:id(),
      debtId:debt.id,
      amount:numericAmount,
      paymentDate,
      notes,
      createdAt:now(),
      createdBy:req.user.id
    };
    currentStore.generalDebtPayments.push(item);
    audit(currentStore, req.user.id, "PAYMENT", "GENERAL_DEBT", debt.id, {
      amount:numericAmount,
      paymentDate
    });
    return item;
  });

  res.status(201).json(payment);
});

app.patch("/api/general-debts/:id", auth, (req,res)=>{
  const updated = mutate((store)=>{
    const debt = store.generalDebts.find((item)=>item.id===req.params.id);
    if (!debt) return null;

    if (req.body?.partyName !== undefined) debt.partyName = String(req.body.partyName);
    if (req.body?.dueDate !== undefined) debt.dueDate = req.body.dueDate || "";
    if (req.body?.description !== undefined) debt.description = req.body.description || "";
    if (req.body?.reference !== undefined) debt.reference = req.body.reference || "";
    if (req.body?.status !== undefined) debt.status = req.body.status;

    debt.updatedAt = now();
    audit(store, req.user.id, "UPDATE", "GENERAL_DEBT", debt.id, req.body);
    return debt;
  });

  if (!updated) return res.status(404).json({message:"الدين غير موجود"});
  res.json(updated);
});


app.get("/api/customers/:id/statement", auth, (req,res)=>{
  try{
    const store=readStore();
    const customer=(Array.isArray(store.customers)?store.customers:[])
      .find(item=>item?.id===req.params.id);

    if(!customer)return res.status(404).json({message:"العميل غير موجود"});

    const from=String(req.query.from||"");
    const to=String(req.query.to||"");

    const inRange=(transaction)=>{
      const date=String(transaction.transferDate||transaction.createdAt||"").slice(0,10);
      return (!from||date>=from)&&(!to||date<=to);
    };

    const allPayments=(Array.isArray(store.payments)?store.payments:[])
      .filter(payment=>payment&&!payment.isDeleted);

    const today=new Date();
    today.setHours(0,0,0,0);

    const transactions=(Array.isArray(store.transactions)?store.transactions:[])
      .filter(transaction=>
        transaction?.customerId===customer.id &&
        !transaction?.isDeleted &&
        transaction.status!=="CANCELLED" &&
        isAfterCustomerReset(transaction, customer, "transferDate") &&
        inRange(transaction)
      )
      .map(transaction=>{
        const paid=allPayments
          .filter(payment=>payment.transactionId===transaction.id)
          .reduce((sum,payment)=>sum+safeNumber(payment.amount),0);

        const usdAmount=safeNumber(transaction.amount);
        const costRate=safeNumber(transaction.costRate);
        const finalRate=safeNumber(transaction.finalRate);

        const costCad=transaction.direction==="USD_TO_CAD"
          ? usdAmount*costRate
          : usdAmount*costRate;

        const totalCad=safeNumber(
          transaction.totalCustomerDue,
          usdAmount*finalRate + safeNumber(transaction.transferFee)
        );

        const remaining=Math.max(totalCad-paid,0);
        const date=transaction.transferDate||String(transaction.createdAt||"").slice(0,10);
        const transferDate=new Date(`${date}T00:00:00`);
        const overdueDays=!Number.isNaN(transferDate.getTime())
          ? Math.max(0,Math.floor((today-transferDate)/86400000))
          : 0;

        let paymentStatus="UNPAID";
        if(remaining<=0.001)paymentStatus="PAID";
        else if(paid>0)paymentStatus="PARTIAL";
        if(remaining>0.001&&overdueDays>7)paymentStatus="OVERDUE";

        return {
          id:transaction.id,
          number:transaction.number||transaction.id,
          transferDate:date,
          usdAmount:+usdAmount.toFixed(2),
          customerRate:+finalRate.toFixed(6),
          formulaResultCad:+(usdAmount*finalRate).toFixed(2),
          costCad:+costCad.toFixed(2),
          totalCad:+totalCad.toFixed(2),
          paid:+paid.toFixed(2),
          remaining:+remaining.toFixed(2),
          status:paymentStatus,
          overdueDays,
          transferFee:+safeNumber(transaction.transferFee).toFixed(2)
        };
      })
      .sort((a,b)=>String(a.transferDate).localeCompare(String(b.transferDate)));

    const accountWasReset=Boolean(customer.accountResetAt);
    const oldBalance=accountWasReset?0:Math.max(safeNumber(customer.oldBalance),0);
    const oldBalancePaid=accountWasReset?0:Math.min(Math.max(safeNumber(customer.oldBalancePaid),0),oldBalance);
    const oldBalanceRemaining=Math.max(oldBalance-oldBalancePaid,0);

    const totals=transactions.reduce((acc,item)=>{
      acc.usdAmount+=safeNumber(item.usdAmount);
      acc.costCad+=safeNumber(item.costCad);
      acc.totalCad+=safeNumber(item.totalCad);
      acc.formulaResultCad+=safeNumber(item.formulaResultCad);
      acc.paid+=safeNumber(item.paid);
      acc.remaining+=safeNumber(item.remaining);
      return acc;
    },{usdAmount:0,costCad:0,totalCad:0,formulaResultCad:0,paid:0,remaining:0});

    const lastActivity=transactions.length
      ? transactions[transactions.length-1].transferDate
      : null;

    res.json({
      company:(()=>{
        const company=(Array.isArray(store.companies)?store.companies:[]).find(item=>item.id===req.user.companyId);
        return {name:company?.name||"شركة العبود للتجارة",nameEn:"",logoDataUrl:company?.logoDataUrl||""};
      })(),
      customer:{
        ...customer,
        oldBalance:+oldBalance.toFixed(2),
        oldBalancePaid:+oldBalancePaid.toFixed(2),
        oldBalanceRemaining:+oldBalanceRemaining.toFixed(2),
        totalTransactions:+(totals.totalCad+oldBalance).toFixed(2),
        totalPaid:+(totals.paid+oldBalancePaid).toFixed(2),
        finalBalance:+(totals.remaining+oldBalanceRemaining).toFixed(2)
      },
      from:from||null,
      to:to||null,
      generatedAt:now(),
      lastActivity,
      transactions,
      totals:{
        usdAmount:+totals.usdAmount.toFixed(2),
        costCad:+totals.costCad.toFixed(2),
        totalCad:+totals.totalCad.toFixed(2),
        formulaResultCad:+totals.formulaResultCad.toFixed(2),
        oldBalance:+oldBalance.toFixed(2),
        oldBalancePaid:+oldBalancePaid.toFixed(2),
        oldBalanceRemaining:+oldBalanceRemaining.toFixed(2),
        paid:+(totals.paid+oldBalancePaid).toFixed(2),
        remaining:+(totals.remaining+oldBalanceRemaining).toFixed(2)
      }
    });
  }catch(error){
    console.error("Statement error:",error);
    res.status(500).json({message:"تعذر إنشاء كشف الحساب"});
  }
});

app.get("/api/transactions/:id/invoice", auth, (req,res)=>{
  try{
    const store=readStore();
    const transaction=(Array.isArray(store.transactions)?store.transactions:[])
      .find(item=>item?.id===req.params.id);

    if(!transaction)return res.status(404).json({message:"الحوالة غير موجودة"});

    const customer=(Array.isArray(store.customers)?store.customers:[])
      .find(item=>item?.id===transaction.customerId)||{name:"عميل"};

    const paid=(Array.isArray(store.payments)?store.payments:[])
      .filter(payment=>payment?.transactionId===transaction.id&&!payment?.isDeleted)
      .reduce((sum,payment)=>sum+safeNumber(payment.amount),0);

    const due=safeNumber(
      transaction.totalCustomerDue,
      safeNumber(transaction.amount)+safeNumber(transaction.transferFee)
    );

    res.json({
      company:{
        name:"شركة العبود للتجارة",
        nameEn:"AlAboud Trading Company"
      },
      invoiceNumber:transaction.number||transaction.id,
      invoiceDate:transaction.transferDate||String(transaction.createdAt||"").slice(0,10),
      customer:{
        id:customer.id,
        name:customer.name||"عميل",
        phone:customer.phone||"",
        email:customer.email||""
      },
      transaction:{
        ...transaction,
        amount:safeNumber(transaction.amount),
        costRate:safeNumber(transaction.costRate),
        finalRate:safeNumber(transaction.finalRate),
        transferFee:safeNumber(transaction.transferFee),
        totalCustomerDue:+due.toFixed(2),
        paid:+paid.toFixed(2),
        remaining:+Math.max(due-paid,0).toFixed(2)
      },
      generatedAt:now()
    });
  }catch(error){
    console.error("Invoice error:",error);
    res.status(500).json({message:"تعذر إنشاء الفاتورة"});
  }
});



const INTEGRATION_SECRET=process.env.INTEGRATION_SECRET||JWT_SECRET;
function integrationKey(){return crypto.createHash("sha256").update(String(INTEGRATION_SECRET)).digest();}
function encryptIntegrationSecret(value){
  if(!value)return "";
  const iv=crypto.randomBytes(12);const cipher=crypto.createCipheriv("aes-256-gcm",integrationKey(),iv);
  const encrypted=Buffer.concat([cipher.update(String(value),"utf8"),cipher.final()]);
  return `enc:v1:${iv.toString("base64")}:${cipher.getAuthTag().toString("base64")}:${encrypted.toString("base64")}`;
}
function decryptIntegrationSecret(value){
  const text=String(value||"");if(!text)return "";if(!text.startsWith("enc:v1:"))return text;
  const [,version,iv64,tag64,data64]=text.split(":");if(version!=="v1")throw new Error("Unsupported integration secret");
  const decipher=crypto.createDecipheriv("aes-256-gcm",integrationKey(),Buffer.from(iv64,"base64"));
  decipher.setAuthTag(Buffer.from(tag64,"base64"));
  return Buffer.concat([decipher.update(Buffer.from(data64,"base64")),decipher.final()]).toString("utf8");
}
function normalizeBaseUrl(value){
  let raw=String(value||"").trim();
  if(!raw)throw new Error("رابط شركة جاد مطلوب");
  if(!/^https?:\/\//i.test(raw))raw=`https://${raw.replace(/^\/+/,"")}`;
  const parsed=new URL(raw);
  if(!["http:","https:"].includes(parsed.protocol))throw new Error("رابط شركة جاد يجب أن يبدأ بـ http أو https");
  return `${parsed.protocol}//${parsed.host}`;
}
function resolveJadConnection(partner={}){
  let raw=String(partner.systemUrl||"").trim();
  if(!raw)throw new Error("رابط شركة جاد مطلوب");
  if(!/^https?:\/\//i.test(raw))raw=`https://${raw.replace(/^\/+/,"")}`;
  const parsed=new URL(raw);
  if(!["http:","https:"].includes(parsed.protocol))throw new Error("رابط شركة جاد غير صالح");

  const base=`${parsed.protocol}//${parsed.host}`;
  const configured=String(partner.pathPrefix||"").trim();
  let prefix=configured;
  const pathname=decodeURIComponent(parsed.pathname||"").replace(/\/+$/,"");

  // Accept the complete Jad URL pasted by the user, including /log, /pl.m,
  // /account or /accountprint.php, and derive the installation prefix from it.
  const endpointMatch=pathname.match(/^(.*?)(?:\/(?:log(?:_2)?|pl(?:\.m)?|account|accountprint\.php|statement))$/i);
  const candidate=(endpointMatch?.[1]||pathname).replace(/\/+$/,"");
  if(/\/ssljd\//i.test(candidate))prefix=candidate;
  if(!prefix)prefix="/ssljd/merkez112/1/2";
  if(!prefix.startsWith("/"))prefix=`/${prefix}`;
  prefix=prefix.replace(/\/{2,}/g,"/").replace(/\/+$/,"");

  return {base,prefix,loginUrl:`${base}${prefix}/log`,accountUrl:`${base}${prefix}/account`,landingUrl:`${base}${prefix}/pl.m`};
}
function htmlText(value){return String(value||"").replace(/<br\s*\/?\s*>/gi," ").replace(/<[^>]+>/g," ").replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&#039;/g,"'").replace(/&quot;/g,'"').replace(/\s+/g," ").trim();}
function numberFromText(value){
  const normalized=htmlText(value)
    .replace(/[٠-٩]/g,ch=>"٠١٢٣٤٥٦٧٨٩".indexOf(ch))
    .replace(/[٬,\s]/g,"")
    .replace(/٫/g,".");
  const match=normalized.match(/-?\d+(?:\.\d+)?/);
  return match?safeNumber(match[0]):0;
}
function splitSetCookieHeader(value){
  const text=String(value||"");if(!text)return [];
  return text.split(/,(?=\s*[^;,=\s]+=[^;,]+)/g).map(x=>x.trim()).filter(Boolean);
}
function extractCookies(headers){
  let raw=[];
  if(typeof headers.getSetCookie==="function")raw=headers.getSetCookie();
  if(!raw?.length)raw=splitSetCookieHeader(headers.get("set-cookie"));
  return raw.map(item=>String(item).split(";")[0]).filter(Boolean).join("; ");
}
function mergeCookies(current,next){const jar={};for(const pair of `${current||""}; ${next||""}`.split(";")){const i=pair.indexOf("=");if(i>0)jar[pair.slice(0,i).trim()]=pair.slice(i+1).trim();}return Object.entries(jar).map(([k,v])=>`${k}=${v}`).join("; ");}
function isJadLoginPage(html,url=""){
  const source=String(html||"");
  const forms=[...source.matchAll(/<form\b([^>]*)>([\s\S]*?)<\/form>/gi)];
  const hasRealLoginForm=forms.some(form=>{
    const body=form[2];
    return /<input\b[^>]*name=["']pass["'][^>]*>/i.test(body)
      && /<input\b[^>]*name=["'](?:mail|tok)["'][^>]*>/i.test(body);
  });
  const path=(()=>{try{return new URL(url).pathname.replace(/\/$/,"");}catch{return "";}})();
  return hasRealLoginForm || /\/log$/.test(path);
}
function parseSafeTransitionPostForm(html,baseUrl){
  const source=String(html||"");
  for(const form of source.matchAll(/<form\b([^>]*)>([\s\S]*?)<\/form>/gi)){
    const formAttrs=parseHtmlAttributes(form[1]);
    if(String(formAttrs.method||"GET").toUpperCase()!=="POST")continue;
    const body=new URLSearchParams();
    let hasField=false;
    let unsafe=false;
    for(const input of form[2].matchAll(/<input\b([^>]*)>/gi)){
      const attrs=parseHtmlAttributes(input[1]);
      const name=attrs.name;
      if(!name)continue;
      const type=String(attrs.type||"text").toLowerCase();
      if(["password","text","email","file"].includes(type)){unsafe=true;break;}
      if(type==="checkbox"||type==="radio"){
        if(!Object.prototype.hasOwnProperty.call(attrs,"checked"))continue;
      }
      if(["hidden","submit","button","image"].includes(type)){
        body.append(name,attrs.value||"");
        hasField=true;
        continue;
      }
      unsafe=true;break;
    }
    if(unsafe||!hasField)continue;
    const action=new URL(formAttrs.action||baseUrl,baseUrl).toString();
    if(/(?:logout|signout|logoff)/i.test(action))continue;
    return {action,body:body.toString()};
  }
  return null;
}

async function fetchWithCookies(url,options={},cookie="",settings={}){
  const maxRedirects=Number.isFinite(settings.maxRedirects)?settings.maxRedirects:8;
  let currentUrl=String(url);
  let currentCookie=String(cookie||"");
  let currentOptions={...options};
  const redirects=[];
  for(let index=0;index<=maxRedirects;index+=1){
    const headers={...(currentOptions.headers||{})};
    if(currentCookie)headers.Cookie=currentCookie;
    const response=await fetch(currentUrl,{...currentOptions,headers,redirect:"manual",signal:AbortSignal.timeout(20000)});
    currentCookie=mergeCookies(currentCookie,extractCookies(response.headers));
    const status=response.status;
    const location=response.headers.get("location");
    if(!location||![301,302,303,307,308].includes(status)){
      return {response,cookie:currentCookie,url:currentUrl,redirects};
    }
    if(index===maxRedirects)throw new Error("تجاوز موقع الشركة الحد المسموح لإعادة التوجيه");
    const nextUrl=new URL(location,currentUrl).toString();
    redirects.push({status,from:currentUrl,to:nextUrl});
    const method=String(currentOptions.method||"GET").toUpperCase();
    const shouldSwitchToGet=status===303||((status===301||status===302)&&method!=="GET"&&method!=="HEAD");
    const nextHeaders={...(currentOptions.headers||{})};
    try{
      if(new URL(nextUrl).origin===new URL(currentUrl).origin)nextHeaders.Referer=currentUrl;
    }catch{}
    if(shouldSwitchToGet){
      delete nextHeaders["Content-Type"];delete nextHeaders["content-type"];
      delete nextHeaders["Content-Length"];delete nextHeaders["content-length"];
      delete nextHeaders.Origin;delete nextHeaders.origin;
      currentOptions={...currentOptions,method:"GET",body:undefined,headers:nextHeaders};
    }else{
      currentOptions={...currentOptions,headers:nextHeaders};
    }
    currentUrl=nextUrl;
  }
  throw new Error("تعذر إكمال إعادة التوجيه");
}
function decodeHtmlAttribute(value){
  return String(value||"")
    .replace(/&amp;/gi,"&")
    .replace(/&quot;/gi,'"')
    .replace(/&#039;|&#39;/gi,"'")
    .replace(/&lt;/gi,"<")
    .replace(/&gt;/gi,">");
}
function parseHtmlAttributes(value){
  const attrs={};
  for(const match of String(value||"").matchAll(/([:\w-]+)(?:\s*=\s*(?:["']([^"']*)["']|([^\s>]+)))?/g)){
    attrs[String(match[1]||"").toLowerCase()]=decodeHtmlAttribute(match[2]??match[3]??"");
  }
  return attrs;
}
function parseJadLoginForm(html,baseUrl){
  const source=String(html||"");
  for(const form of source.matchAll(/<form\b([^>]*)>([\s\S]*?)<\/form>/gi)){
    const formAttrs=parseHtmlAttributes(form[1]);
    const fields=new URLSearchParams();
    let hasPassword=false;
    let hasIdentity=false;
    for(const input of form[2].matchAll(/<input\b([^>]*)>/gi)){
      const attrs=parseHtmlAttributes(input[1]);
      const name=attrs.name;
      if(!name)continue;
      const type=String(attrs.type||"text").toLowerCase();
      if(["submit","button","image","file","reset"].includes(type))continue;
      if(type==="checkbox"||type==="radio"){
        if(!Object.prototype.hasOwnProperty.call(attrs,"checked"))continue;
      }
      fields.append(name,attrs.value||"");
      if(name.toLowerCase()==="pass"||type==="password")hasPassword=true;
      if(["mail","email","username","user","tok"].includes(name.toLowerCase()))hasIdentity=true;
    }
    if(!hasPassword||!hasIdentity)continue;
    const action=new URL(formAttrs.action||baseUrl,baseUrl).toString();
    return {action,method:String(formAttrs.method||"POST").toUpperCase(),fields};
  }
  return null;
}
function findToken(html){
  const form=parseJadLoginForm(html,"https://localhost/");
  if(form){
    const token=form.fields.get("tok");
    if(token)return token;
  }
  const patterns=[/name=["']tok["'][^>]*value=["']([^"']+)/i,/value=["']([^"']+)["'][^>]*name=["']tok["']/i];
  for(const pattern of patterns){const match=String(html).match(pattern);if(match)return decodeHtmlAttribute(match[1]);}return "";
}
function extractClientRedirect(html,currentUrl){
  const source=String(html||"");
  const meta=source.match(/<meta\b[^>]*http-equiv=["']?refresh["']?[^>]*content=["'][^"']*url\s*=\s*([^"';>]+)["']/i)
    || source.match(/<meta\b[^>]*content=["'][^"']*url\s*=\s*([^"';>]+)["'][^>]*http-equiv=["']?refresh/i);
  const script=source.match(/(?:window\.)?location(?:\.href)?\s*=\s*["']([^"']+)["']/i)
    || source.match(/location\.replace\(\s*["']([^"']+)["']\s*\)/i);
  const target=meta?.[1]||script?.[1];
  if(!target)return "";
  try{return new URL(decodeHtmlAttribute(target.trim()),currentUrl).toString();}catch{return "";}
}
function loginFailureMessage(html){
  const text=htmlText(html);
  const snippets=[
    /(?:خطأ|تنبيه|تحذير|error|invalid)[^.!؟\n]{0,180}/i,
    /(?:اسم المستخدم|كلمة المرور|رمز الحماية)[^.!؟\n]{0,180}/i
  ];
  for(const pattern of snippets){const match=text.match(pattern);if(match)return match[0].trim();}
  return "";
}
async function followJadPostLoginFlow(step,cookie,browserHeaders,base,prefix){
  let current=step;
  let jar=cookie;
  let html=await current.response.text();
  for(let attempt=0;attempt<8;attempt+=1){
    if(isJadLoginPage(html,current.url))return {step:current,cookie:jar,html,loggedOut:true};

    const clientRedirect=extractClientRedirect(html,current.url);
    if(clientRedirect){
      current=await fetchWithCookies(clientRedirect,{headers:{...browserHeaders,Referer:current.url}},jar,{maxRedirects:10});
      jar=current.cookie;html=await current.response.text();continue;
    }

    const safeForm=parseSafeTransitionPostForm(html,current.url);
    if(safeForm){
      current=await fetchWithCookies(safeForm.action,{
        method:"POST",
        headers:{...browserHeaders,"Content-Type":"application/x-www-form-urlencoded",Origin:base,Referer:current.url},
        body:safeForm.body
      },jar,{maxRedirects:10});
      jar=current.cookie;html=await current.response.text();continue;
    }
    break;
  }
  return {step:current,cookie:jar,html,loggedOut:isJadLoginPage(html,current.url)};
}

function normalizeJadCurrencyDebt(receivableValue,payableValue,{prefer="RECEIVABLE"}={}){
  let receivable=Math.max(safeNumber(receivableValue),0);
  let payable=Math.max(safeNumber(payableValue),0);

  // بعض صفحات جاد تكرر بطاقة الرصيد نفسها قرب كلمتي «لنا» و«علينا»،
  // فيلتقط المحلل الرقم نفسه في العمودين. لا يجوز عندها إظهار دينين متساويين
  // وصافي صفر. نحتفظ بالقيمة في جهة واحدة فقط.
  if(receivable>0.001&&payable>0.001&&Math.abs(receivable-payable)<0.01){
    if(String(prefer).toUpperCase()==="PAYABLE")receivable=0;
    else payable=0;
  }

  return {
    receivable:+receivable.toFixed(2),
    payable:+payable.toFixed(2),
    balance:+(receivable-payable).toFixed(2)
  };
}

function parseJadCurrencyBalances(html){
  const raw=htmlText(String(html||""))
    .replace(/[٠-٩]/g,ch=>"٠١٢٣٤٥٦٧٨٩".indexOf(ch))
    .replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g," ")
    .replace(/[\u{1F000}-\u{1FAFF}\u2600-\u27BF]/gu," ")
    .replace(/[^\p{L}\p{N}.,+\-٫٬]+/gu," ")
    .replace(/\s+/g," ")
    .trim();
  const aliases=[
    {code:"CAD",patterns:["دولار كندي","كندي","CAD"]},
    {code:"USD",patterns:["دولار أمريكي","دولار امريكي","دولار","USD"]},
    {code:"EUR",patterns:["يورو","EUR"]},
    {code:"TRY",patterns:["ليرة تركية","تركي","TRY"]},
    {code:"SYP",patterns:["ليرة سورية","سوري","SYP"]},
    {code:"SAR",patterns:["ريال سعودي","سعودي","SAR"]},
    {code:"JOD",patterns:["دينار أردني","دينار اردني","أردني","اردني","JOD"]},
    {code:"AED",patterns:["درهم إماراتي","درهم اماراتي","إماراتي","اماراتي","AED"]},
    {code:"GBP",patterns:["جنيه إسترليني","جنيه استرليني","إسترليني","استرليني","GBP"]}
  ];
  const out={};
  const esc=value=>String(value).replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
  const amount='([+-]?[0-9][0-9,٬]*(?:[.٫][0-9]+)?)';
  const sep='(?:\\s|[^\\p{L}\\p{N}]){0,12}';
  const recv='(?:لنا|لكم|مستحق\\s*لنا|دائن\\s*(?:لنا|لكم))';
  const pay='(?:علينا|عليكم|مستحق\\s*علينا|مدين\\s*(?:علينا|عليكم))';

  for(const item of aliases){
    let receivable=0,payable=0,found=false;
    for(const alias of item.patterns){
      const a=esc(alias);
      const candidates=[
        {kind:"receivable",re:new RegExp(`${amount}${sep}${a}${sep}${recv}`,"giu")},
        {kind:"receivable",re:new RegExp(`${a}${sep}${amount}${sep}${recv}`,"giu")},
        {kind:"receivable",re:new RegExp(`${recv}${sep}${amount}${sep}${a}`,"giu")},
        {kind:"payable",re:new RegExp(`${amount}${sep}${a}${sep}${pay}`,"giu")},
        {kind:"payable",re:new RegExp(`${a}${sep}${amount}${sep}${pay}`,"giu")},
        {kind:"payable",re:new RegExp(`${pay}${sep}${amount}${sep}${a}`,"giu")}
      ];
      for(const candidate of candidates){
        for(const match of raw.matchAll(candidate.re)){
          const amountValue=Math.abs(numberFromText(match[1]));
          if(!Number.isFinite(amountValue))continue;
          found=true;
          if(candidate.kind==="receivable")receivable=Math.max(receivable,amountValue);
          else payable=Math.max(payable,amountValue);
        }
      }

      // Direct Jad card pattern: amount, optional icon/flag, currency label, direction.
      // Example: 8,857 [EU icon] يورو لكم.
      const directCardPatterns=[
        {kind:"receivable",re:new RegExp(`${amount}[^\p{L}\p{N}]{0,30}${a}\s*${recv}`,"giu")},
        {kind:"payable",re:new RegExp(`${amount}[^\p{L}\p{N}]{0,30}${a}\s*${pay}`,"giu")}
      ];
      for(const candidate of directCardPatterns){
        for(const match of raw.matchAll(candidate.re)){
          const amountValue=Math.abs(numberFromText(match[1]));
          if(!Number.isFinite(amountValue))continue;
          found=true;
          if(candidate.kind==="receivable")receivable=Math.max(receivable,amountValue);
          else payable=Math.max(payable,amountValue);
        }
      }

      // Fallback for Jad dashboard cards where the flag/icon appears between
      // the amount and the currency label. Inspect a compact window around the alias.
      const aliasRe=new RegExp(a,"giu");
      for(const aliasMatch of raw.matchAll(aliasRe)){
        const left=raw.slice(Math.max(0,aliasMatch.index-45),aliasMatch.index);
        const right=raw.slice(aliasMatch.index+aliasMatch[0].length,aliasMatch.index+aliasMatch[0].length+45);
        const leftAmounts=[...left.matchAll(new RegExp(amount,"g"))];
        const rightAmounts=[...right.matchAll(new RegExp(amount,"g"))];
        const valueMatch=leftAmounts.at(-1)||rightAmounts[0];
        if(!valueMatch)continue;
        const context=`${left} ${aliasMatch[0]} ${right}`;
        const amountValue=Math.abs(numberFromText(valueMatch[1]));
        if(!Number.isFinite(amountValue))continue;
        if(new RegExp(recv,"iu").test(context)){
          found=true;receivable=Math.max(receivable,amountValue);
        }
        if(new RegExp(pay,"iu").test(context)){
          found=true;payable=Math.max(payable,amountValue);
        }
      }
    }
    if(found)out[item.code]=normalizeJadCurrencyDebt(receivable,payable,{prefer:"RECEIVABLE"});
  }
  return out;
}

function parseJadStatement(html){
  const source=String(html||"");
  const tbodyMatches=[...source.matchAll(/<tbody[^>]*>([\s\S]*?)<\/tbody>/gi)];
  let rows=[];
  for(const body of tbodyMatches){
    const parsed=[...body[1].matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)].map(row=>[...row[1].matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)].map(cell=>htmlText(cell[1]))).filter(cells=>cells.length>=6);
    if(parsed.length>rows.length)rows=parsed;
  }
  const movements=rows.map(cells=>({
    sequence:cells[0]||"",date:cells[1]||"",movementType:cells[2]||"",movementNumber:cells[3]||"",notes:cells[4]||"",
    payable:numberFromText(cells[5]),receivable:numberFromText(cells[6]),balance:numberFromText(cells[7]??cells[cells.length-1]),raw:cells
  }));
  const last=movements[movements.length-1]||{};
  const totalPayableMatch=source.match(/(?:دائن\s*علينا|مجموع\s*الدائن\s*علينا)[\s\S]{0,180}?([\d,]+(?:\.\d+)?)/i);
  const totalReceivableMatch=source.match(/(?:مدين\s*لنا|مجموع\s*المدين\s*لنا)[\s\S]{0,180}?([\d,]+(?:\.\d+)?)/i);
  let payable=totalPayableMatch?numberFromText(totalPayableMatch[1]):0;
  let receivable=totalReceivableMatch?numberFromText(totalReceivableMatch[1]):0;
  const balance=safeNumber(last.balance);
  if(!payable&&!receivable&&balance){
    const pageText=htmlText(source);
    if(/دائن\s*علينا|دولار\s*عليكم/.test(pageText))payable=Math.abs(balance);else receivable=Math.abs(balance);
  }
  const normalized=normalizeJadCurrencyDebt(receivable,payable,{prefer:balance<0?"PAYABLE":"RECEIVABLE"});
  return {movements,balance:normalized.balance,payable:normalized.payable,receivable:normalized.receivable};
}
async function syncJadPartnerHttp(partner,{fromDate,toDate}={}){
  const {base,prefix,loginUrl,accountUrl,landingUrl}=resolveJadConnection(partner);
  const username=String(partner.username||"").trim();
  const password=decryptIntegrationSecret(partner.passwordEncrypted);
  if(!username||!password)throw new Error("اسم المستخدم وكلمة المرور مطلوبان للربط");

  const browserHeaders={
    Accept:"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language":"ar,en-US;q=0.9,en;q=0.8",
    "Cache-Control":"no-cache",
    Pragma:"no-cache",
    "Upgrade-Insecure-Requests":"1",
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
  };

  let cookie="";

  // Browser traffic reaches /log from pl.m. This preflight initializes the same PHP branch
  // and keeps any session cookies issued before the login form is opened.
  try{
    const landing=await fetchWithCookies(landingUrl,{headers:browserHeaders},cookie,{maxRedirects:6});
    cookie=landing.cookie;
    await landing.response.arrayBuffer();
  }catch(error){
    console.warn("[JAD] pl.m preflight skipped:",error?.message||error);
  }

  // Read the real login form first. Jad binds the dynamic tok value to the PHP session.
  let step=await fetchWithCookies(loginUrl,{headers:{...browserHeaders,Referer:`${base}${prefix}/pl.m`}},cookie,{maxRedirects:6});
  cookie=step.cookie;
  const loginHtml=await step.response.text();
  const loginForm=parseJadLoginForm(loginHtml,step.url||loginUrl);
  if(!loginForm)throw new Error("تعذر العثور على نموذج تسجيل دخول جاد أو استخراج رمز الحماية tok");

  const loginBody=new URLSearchParams(loginForm.fields);
  loginBody.set("mail",username);
  loginBody.set("pass",password);
  if(!loginBody.has("tok")){
    const token=findToken(loginHtml);
    if(!token)throw new Error("تعذر استخراج رمز الحماية tok من صفحة تسجيل دخول جاد");
    loginBody.set("tok",token);
  }
  if(!loginBody.has("btn-login"))loginBody.set("btn-login","");

  step=await fetchWithCookies(loginForm.action||loginUrl,{
    method:loginForm.method==="GET"?"GET":"POST",
    headers:{
      ...browserHeaders,
      "Content-Type":"application/x-www-form-urlencoded",
      Origin:base,
      Referer:step.url||loginUrl
    },
    body:loginForm.method==="GET"?undefined:loginBody.toString()
  },cookie,{maxRedirects:12});
  cookie=step.cookie;

  let postLogin=await followJadPostLoginFlow(step,cookie,browserHeaders,base,prefix);
  step=postLogin.step;cookie=postLogin.cookie;
  if(postLogin.loggedOut){
    const reason=loginFailureMessage(postLogin.html);
    throw new Error(reason?`رفض موقع جاد تسجيل الدخول: ${reason}`:"رفض موقع جاد تسجيل الدخول؛ تحقق من اسم المستخدم وكلمة المرور ورمز الحماية");
  }

  // Some Jad installations initialize the authenticated branch on log_2 before /account.
  // Visit it once when the login flow ended elsewhere; a 404/redirect is harmless and is followed manually.
  const currentPath=(()=>{try{return new URL(step.url).pathname.replace(/\/$/,"");}catch{return "";}})();
  if(!currentPath.endsWith(`${prefix}/log_2`)){
    const bootstrap=await fetchWithCookies(`${base}${prefix}/log_2`,{
      headers:{...browserHeaders,Referer:step.url||loginUrl}
    },cookie,{maxRedirects:10});
    cookie=bootstrap.cookie;
    const bootstrapFlow=await followJadPostLoginFlow(bootstrap,cookie,browserHeaders,base,prefix);
    if(!bootstrapFlow.loggedOut){step=bootstrapFlow.step;cookie=bootstrapFlow.cookie;}
  }

  step=await fetchWithCookies(`${base}${prefix}/account`,{
    headers:{...browserHeaders,Referer:step.url||`${base}${prefix}/log_2`}
  },cookie,{maxRedirects:12});
  cookie=step.cookie;
  let accountHtml=await step.response.text();

  // If /account bounced back to /log, retry once through log_2 with the same cookie jar.
  if(isJadLoginPage(accountHtml,step.url)){
    const retryBootstrap=await fetchWithCookies(`${base}${prefix}/log_2`,{
      headers:{...browserHeaders,Referer:loginUrl}
    },cookie,{maxRedirects:10});
    cookie=retryBootstrap.cookie;
    const retryFlow=await followJadPostLoginFlow(retryBootstrap,cookie,browserHeaders,base,prefix);
    cookie=retryFlow.cookie;
    if(!retryFlow.loggedOut){
      step=await fetchWithCookies(`${base}${prefix}/account`,{
        headers:{...browserHeaders,Referer:retryFlow.step.url||`${base}${prefix}/log_2`}
      },cookie,{maxRedirects:12});
      cookie=step.cookie;accountHtml=await step.response.text();
    }
  }

  if(isJadLoginPage(accountHtml,step.url)){
    console.error("[JAD AUTH] account returned login page",{
      finalUrl:step.url,
      redirects:step.redirects,
      cookieNames:String(cookie||"").split(";").map(x=>x.split("=")[0].trim()).filter(Boolean)
    });
    throw new Error("انتهت جلسة جاد بعد تسجيل الدخول؛ موقع جاد أعاد صفحة الدخول عند فتح الحساب");
  }

  const start=fromDate||partner.syncFromDate||new Date(Date.now()-365*24*3600*1000).toISOString().slice(0,10);
  const end=toDate||new Date().toISOString().slice(0,10);
  const accountId=String(partner.externalAccountId||"").trim();
  if(accountId){
    const form=new URLSearchParams();
    form.set("currency",String(partner.accountCurrency||"USD").toLowerCase());
    form.set("date1","date");
    form.set("confirm",accountId);
    form.set("date2",start);
    form.set("date3",end);
    step=await fetchWithCookies(`${base}${prefix}/account`,{
      method:"POST",
      headers:{...browserHeaders,"Content-Type":"application/x-www-form-urlencoded",Origin:base,Referer:`${base}${prefix}/account`},
      body:form.toString()
    },cookie,{maxRedirects:12});
    cookie=step.cookie;
    const selectedHtml=await step.response.text();
    if(isJadLoginPage(selectedHtml,step.url))throw new Error("رفض موقع جاد اختيار الحساب؛ أعد التحقق من رقم الحساب وبيانات الدخول");
  }

  const query=new URLSearchParams({
    currency:String(partner.accountCurrency||"USD").toLowerCase(),
    date1:"date",date2:start,date3:end
  });
  step=await fetchWithCookies(`${base}${prefix}/accountprint.php?${query}`,{
    headers:{...browserHeaders,Referer:`${base}${prefix}/account`}
  },cookie,{maxRedirects:12});
  cookie=step.cookie;
  if(step.response.status!==200)throw new Error(`تعذر جلب كشف الحساب (${step.response.status})`);
  const html=await step.response.text();
  if(isJadLoginPage(html,step.url)&&!/<tbody/i.test(html))throw new Error("رفض موقع جاد جلسة الدخول عند طلب كشف الحساب");
  if(!/<tbody/i.test(html)&&!/كشف\s*حساب|الرصيد|مدين|دائن/i.test(htmlText(html)))throw new Error("تم الاتصال بجاد لكن لم يتم العثور على جدول كشف الحساب");
  return {...parseJadStatement(html),fromDate:start,toDate:end,redirects:step.redirects||[]};
}


async function syncJadPartnerBrowser(partner,{fromDate,toDate,otp}={}){
  let chromium;
  try{({chromium}=require("playwright"));}
  catch(error){const wrapped=new Error("موصل المتصفح غير مثبت. نفّذ npm install داخل backend ثم أعد النشر");wrapped.code="JAD_BROWSER_UNAVAILABLE";wrapped.cause=error;throw wrapped;}

  const {base,prefix,loginUrl,accountUrl,landingUrl}=resolveJadConnection(partner);
  const username=String(partner.username||"").trim();
  const password=decryptIntegrationSecret(partner.passwordEncrypted);
  if(!username||!password)throw new Error("اسم المستخدم وكلمة المرور مطلوبان للربط");

  const start=fromDate||partner.syncFromDate||new Date(Date.now()-365*24*3600*1000).toISOString().slice(0,10);
  const end=toDate||new Date().toISOString().slice(0,10);
  const accountId=String(partner.externalAccountId||"").trim();
  const cleanOtp=String(otp||"").replace(/\D/g,"").slice(0,8);

  const launchOptions={headless:true,args:["--no-sandbox","--disable-setuid-sandbox","--disable-dev-shm-usage","--disable-gpu","--no-zygote"],timeout:60000};
  if(process.env.CHROME_EXECUTABLE_PATH)launchOptions.executablePath=process.env.CHROME_EXECUTABLE_PATH;

  let browser; let page; const trace=[];
  const diagnosticDir=path.join(require("os").tmpdir(),"alaboud-jad-diagnostics");
  const diagnosticBase=path.join(diagnosticDir,String(partner.id||"jad"));
  const safeText=value=>String(value||"").replace(new RegExp(username.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),"gi"),"[username]").replace(/\b\d{6,8}\b/g,"[otp]");
  const saveDiagnosticArtifacts=async(label)=>{
    if(!page)return null;
    try{
      fs.mkdirSync(diagnosticDir,{recursive:true});
      const stamp=Date.now();
      const png=`${diagnosticBase}-${stamp}.png`;
      const htmlFile=`${diagnosticBase}-${stamp}.html`;
      await page.screenshot({path:png,fullPage:true}).catch(()=>null);
      const rawHtml=await page.content().catch(()=>"");
      fs.writeFileSync(htmlFile,safeText(rawHtml),"utf8");
      return {label,png,html:htmlFile,createdAt:new Date().toISOString()};
    }catch{return null;}
  };
  const record=async(label)=>{
    if(!page)return;
    const entry={label,url:page.url(),title:await page.title().catch(()=>""),time:new Date().toISOString()};
    entry.text=safeText((await page.locator('body').innerText({timeout:2500}).catch(()=>"" )).replace(/\s+/g," ").slice(0,900));
    trace.push(entry);
  };
  const errorDetails=error=>({
    name:String(error?.name||"Error"),
    message:safeText(error?.message||error||"Unknown error"),
    code:String(error?.code||""),
    stack:safeText(error?.stack||"").split("\n").slice(0,12).join("\n"),
    cause:error?.cause?{name:String(error.cause?.name||"Error"),message:safeText(error.cause?.message||error.cause),stack:safeText(error.cause?.stack||"").split("\n").slice(0,8).join("\n")}:null
  });
  const diagnosticError=async(message,code="JAD_FLOW_ERROR",cause=null)=>{
    await record("failure");
    const artifacts=await saveDiagnosticArtifacts(code);
    const error=new Error(message); error.code=code; error.cause=cause||undefined; error.jadTrace=trace.slice(-16); error.jadArtifacts=artifacts; error.jadDetails=cause?errorDetails(cause):null; return error;
  };
  console.log("[JAD][START]",{partnerId:partner.id,base,prefix,loginUrl,accountUrl,accountConfigured:Boolean(accountId),otpProvided:Boolean(cleanOtp),playwrightVersion:(()=>{try{return require("playwright/package.json").version}catch{return "unknown"}})(),browsersPath:process.env.PLAYWRIGHT_BROWSERS_PATH||"default",chromeExecutablePath:process.env.CHROME_EXECUTABLE_PATH||"default"});
  try{
    try {
      const executable=chromium.executablePath ? chromium.executablePath() : "";
      console.log("[JAD][CHROMIUM][BEFORE_LAUNCH]",{executable,exists:executable?fs.existsSync(executable):false,launchOptions:{...launchOptions,args:[...launchOptions.args]}});
      browser=await chromium.launch(launchOptions);
      trace.push({label:"chromium-launched",time:new Date().toISOString(),executable,exists:executable?fs.existsSync(executable):false});
      console.log("[JAD][CHROMIUM][LAUNCHED]",{executable});
    } catch (launchError) {
      const executable=chromium.executablePath ? chromium.executablePath() : "";
      const details=errorDetails(launchError);
      console.error("[JAD][CHROMIUM][LAUNCH_FAILED]",{...details,executable,exists:executable?fs.existsSync(executable):false,platform:process.platform,arch:process.arch,node:process.version,cwd:process.cwd()});
      const wrapped=await diagnosticError(`فشل تشغيل Chromium: ${details.message}${executable ? ` | المسار: ${executable}` : ""}`,"JAD_CHROMIUM_LAUNCH_FAILED",launchError);
      wrapped.executablePath=executable;
      throw wrapped;
    }
    let savedStorageState=null;
    try{
      const encryptedState=String(partner.jadStorageStateEncrypted||"");
      if(encryptedState){
        const decoded=decryptIntegrationSecret(encryptedState);
        const parsed=JSON.parse(decoded);
        if(parsed&&Array.isArray(parsed.cookies))savedStorageState=parsed;
      }
    }catch(error){console.warn("[JAD][SESSION][STATE_INVALID]",String(error?.message||error));}
    const contextOptions={locale:"ar",timezoneId:"America/Toronto",userAgent:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36",viewport:{width:1365,height:900},extraHTTPHeaders:{"Accept-Language":"ar,en-US;q=0.9,en;q=0.8"},ignoreHTTPSErrors:true};
    if(savedStorageState)contextOptions.storageState=savedStorageState;
    const context=await browser.newContext(contextOptions);
    page=await context.newPage();
    page.setDefaultTimeout(25000); page.setDefaultNavigationTimeout(45000);

    await page.goto(landingUrl,{waitUntil:"domcontentloaded"}).catch(()=>null);
    await page.waitForTimeout(900);
    await record(savedStorageState?"session-probe":"landing");
    const probeHtml=await page.content().catch(()=>"");
    const probeText=htmlText(probeHtml);
    const probeHasLogin=Boolean(await page.locator('input[type="password"],input[name="pass"],button[name="btn-login"],input[name="btn-login"]').count().catch(()=>0));
    let reusedSession=Boolean(savedStorageState&&!probeHasLogin&&!isJadLoginPage(probeHtml,page.url())&&/الصفحة الرئيسية|الحسابات|الحوالات|يورو|دولار|الرصيد/i.test(probeText));
    if(reusedSession){
      trace.push({label:"session-reused",url:page.url(),time:new Date().toISOString()});
      console.log("[JAD][SESSION][REUSED]",{partnerId:partner.id,url:page.url()});
    }else{
      await page.goto(loginUrl,{waitUntil:"domcontentloaded"});
      await record("login-page");

      const mail=page.locator('input[name="mail"],input[type="email"],input[name*="user" i],input[name*="login" i]').first();
      const pass=page.locator('input[name="pass"],input[type="password"]').first();
      if(await mail.count()===0||await pass.count()===0)throw await diagnosticError("تعذر العثور على حقول تسجيل الدخول في موقع جاد");
      await mail.fill(username); await pass.fill(password);
      const submit=page.locator('button[name="btn-login"],input[name="btn-login"],button[type="submit"],input[type="submit"]').first();
      if(await submit.count()===0)throw await diagnosticError("تعذر العثور على زر تسجيل الدخول في موقع جاد");
      await Promise.all([page.waitForNavigation({waitUntil:"domcontentloaded",timeout:30000}).catch(()=>null),submit.click()]);
      await page.waitForTimeout(1200); await record("after-credentials");

    // Detect OTP in the main page or any iframe. Jad may render Authenticator inside a nested frame.
    let otpTarget=null;
    let otpContext=null;
    let otpHint=false;
    for(const frame of page.frames()){
      const frameText=await frame.locator('body').innerText({timeout:2500}).catch(()=>"");
      if(/رمز\s*(?:التحقق|التوثيق|المصادقة)|authenticator|verification\s*code|one[- ]time|otp|2fa/i.test(frameText))otpHint=true;
      const candidates=frame.locator('input:not([type="hidden"]):not([type="password"]):not([type="email"]):not([name="mail"])');
      for(let i=0;i<await candidates.count();i+=1){
        const c=candidates.nth(i); if(!(await c.isVisible().catch(()=>false)))continue;
        const meta=await c.evaluate(el=>({name:el.name||"",id:el.id||"",type:el.type||"",inputmode:el.inputMode||"",autocomplete:el.autocomplete||"",placeholder:el.placeholder||"",maxlength:el.maxLength||0})).catch(()=>({}));
        const signature=Object.values(meta).join(" ");
        if(/otp|code|token|verify|verification|auth|two|2fa|numeric|one-time|pin/i.test(signature)||meta.maxlength===6||meta.maxlength===8){otpTarget=c;otpContext=frame;break;}
      }
      if(otpTarget)break;
    }
    if(!otpTarget&&otpHint){
      for(const frame of page.frames()){
        const candidates=frame.locator('input[type="text"],input[type="tel"],input:not([type])');
        for(let i=0;i<await candidates.count();i+=1){const c=candidates.nth(i);if(await c.isVisible().catch(()=>false)){otpTarget=c;otpContext=frame;break;}}
        if(otpTarget)break;
      }
    }
    if(otpTarget){
      if(!/^\d{6,8}$/.test(cleanOtp))throw await diagnosticError("أدخل رمز Google Authenticator الحالي ثم أعد المحاولة","JAD_OTP_REQUIRED");
      await otpTarget.fill(cleanOtp);
      const scope=otpContext||page.mainFrame();
      const otpSubmit=scope.locator('button[type="submit"],input[type="submit"],button:has-text("تأكيد"),button:has-text("تحقق"),button:has-text("دخول"),button:has-text("متابعة")').first();
      if(await otpSubmit.count())await Promise.all([page.waitForLoadState("domcontentloaded",{timeout:30000}).catch(()=>null),otpSubmit.click()]);
      else {await otpTarget.press("Enter");await page.waitForLoadState("domcontentloaded").catch(()=>null);}
      await page.waitForTimeout(1800); await record("after-otp");
    }else if(otpHint){throw await diagnosticError("ظهرت صفحة رمز التحقق ولكن لم يتمكن البرنامج من تحديد خانة الرمز","JAD_OTP_FIELD_NOT_FOUND");}
    }

    // Allow client-side redirects and intermediate transfer pages to finish.
    for(let i=0;i<8;i+=1){
      await page.waitForTimeout(650);
      const html=await page.content(); const url=page.url();
      if(!isJadLoginPage(html,url)&&!/\/log(?:_2)?\/?(?:$|[?#])/i.test(url))break;
    }
    await record("authenticated-landing");

    // Do not treat a failed login page as an authenticated session merely because
    // the URL or visible text changed. Jad sometimes returns /log with an error.
    const verifyAuthenticatedSession=async()=>{
      const html=await page.content().catch(()=>"");
      const body=htmlText(html);
      const hasPassword=await page.locator('input[type="password"],input[name="pass"]').count().catch(()=>0);
      const hasLoginButton=await page.locator('button[name="btn-login"],input[name="btn-login"]').count().catch(()=>0);
      const rejected=/(?:اسم المستخدم|كلمة المرور|بيانات الدخول).{0,35}(?:غير صحيحة|خاطئة|مرفوضة)|خطأ في تسجيل الدخول|invalid credentials|incorrect password|login failed|رمز.{0,20}(?:خاطئ|منتهي)/i.test(body);
      if((hasPassword&&hasLoginButton)||rejected){
        const reason=rejected?"رفض موقع جاد بيانات الدخول أو رمز التحقق":"بقيت صفحة تسجيل الدخول ظاهرة بعد الإرسال";
        throw await diagnosticError(`${reason}. استخدم اسم المستخدم وكلمة المرور الصحيحين ورمز Authenticator جديدًا`,"JAD_LOGIN_REJECTED");
      }
      return true;
    };
    await verifyAuthenticatedSession();

    // Read every currency card from Jad dashboard before navigating to the statement page.
    // Jad may render the cards asynchronously or inside an iframe. Poll all frames so
    // patterns such as "8,857 [EU icon] يورو لكم" are not missed.
    const collectDashboardCurrencySource=async()=>{
      const chunks=[];
      for(const frame of page.frames()){
        const text=await frame.locator("body").innerText().catch(()=>"");
        const html=await frame.content().catch(()=>"");
        if(text)chunks.push(text);
        if(html)chunks.push(html);
      }
      return chunks.join(" ");
    };
    let dashboardCurrencySource="";
    let dashboardCurrencyBalances={};
    for(let attempt=0;attempt<12;attempt+=1){
      dashboardCurrencySource=await collectDashboardCurrencySource();
      dashboardCurrencyBalances=parseJadCurrencyBalances(dashboardCurrencySource);
      const hasPrimary=dashboardCurrencyBalances.USD||dashboardCurrencyBalances.EUR;
      if(hasPrimary)break;
      await page.waitForTimeout(650);
    }
    // One extra wait for delayed secondary cards (especially EUR) after USD appears.
    if(dashboardCurrencyBalances.USD&&!dashboardCurrencyBalances.EUR){
      for(let attempt=0;attempt<8;attempt+=1){
        await page.waitForTimeout(500);
        dashboardCurrencySource=await collectDashboardCurrencySource();
        dashboardCurrencyBalances=parseJadCurrencyBalances(dashboardCurrencySource);
        if(dashboardCurrencyBalances.EUR)break;
      }
    }
    trace.push({label:"dashboard-currency-balances",url:page.url(),time:new Date().toISOString(),balances:dashboardCurrencyBalances,preview:safeText(htmlText(dashboardCurrencySource)).slice(0,1400)});

    // Jad commonly exposes the statement on pl.m even when the authenticated
    // landing URL remains /log. Probe the known authenticated endpoint first,
    // preserving the current browser session and cookies.
    const knownStatementUrls=[
      `${base}${prefix}/pl.m`,
      `${base}${prefix}/pl`,
      `${base}${prefix}/account`,
      `${base}${prefix}/statement`
    ];

    // Jad often serves the statement form directly on the authenticated landing page
    // (usually /pl.m). Do not leave that page unless no suitable form exists there.
    const findAccountForm=async()=>{
      const forms=page.locator('form');
      let best=null;
      let bestScore=-1;
      const inspected=[];
      for(let i=0;i<await forms.count();i+=1){
        const form=forms.nth(i);
        const info=await form.evaluate((node,index)=>{
          const controls=[...node.elements].map(el=>({
            name:el.name||'',id:el.id||'',type:el.type||'',tag:el.tagName||'',value:el.value||'',
            placeholder:el.placeholder||'',text:(el.innerText||el.value||'').trim()
          }));
          return {index,action:node.action||location.href,method:(node.method||'POST').toUpperCase(),controls};
        },i).catch(()=>null);
        if(!info)continue;
        const names=info.controls.map(c=>String(c.name||'').toLowerCase());
        const signature=info.controls.map(c=>`${c.name} ${c.id} ${c.placeholder} ${c.text}`).join(' ');
        let score=0;
        if(names.includes('currency')||names.some(n=>/curr|coin|money|currency_id/.test(n)))score+=5;
        if(names.includes('date2')||names.some(n=>/from|start|date_from|firstdate/.test(n)))score+=5;
        if(names.includes('date3')||names.some(n=>/to|end|date_to|lastdate/.test(n)))score+=5;
        if(/كشف\s*حساب|statement|account|الرصيد|مدين|دائن/i.test(signature))score+=4;
        if(/mail|pass|btn-login|otp|authenticator/i.test(signature))score-=12;
        inspected.push({index:i,action:info.action,method:info.method,score,names:names.filter(Boolean)});
        if(score>bestScore){bestScore=score;best=form;}
      }
      trace.push({label:'account-form-scan',url:page.url(),time:new Date().toISOString(),bestScore,forms:inspected});
      return bestScore>=7?best:null;
    };

    let accountForm=await findAccountForm();
    if(!accountForm){
      const authenticatedUrl=page.url();
      for(const target of knownStatementUrls){
        await page.goto(target,{waitUntil:'domcontentloaded'}).catch(()=>null);
        await page.waitForTimeout(850);
        await record(`known-account-page-${target.split('/').pop()||'root'}`);
        const candidateHtml=await page.content().catch(()=>'');
        if(!isJadLoginPage(candidateHtml,page.url())){
          accountForm=await findAccountForm();
          if(accountForm)break;
        }
      }
      if(!accountForm){
        await page.goto(authenticatedUrl,{waitUntil:'domcontentloaded'}).catch(()=>null);
        await page.waitForTimeout(500);
      }
      const links=await page.locator('a[href]').evaluateAll(items=>items.map((a,index)=>({
        index,href:a.href||'',text:(a.innerText||a.textContent||'').replace(/\s+/g,' ').trim()
      }))).catch(()=>[]);
      const candidates=links.map(link=>{
        let score=0;
        if(/كشف\s*حساب|حركة\s*الحساب|account\s*statement|statement/i.test(link.text))score+=20;
        if(/الحساب|account/i.test(link.text))score+=8;
        if(/pl\.m|account|statement|ledger/i.test(link.href))score+=6;
        if(/logout|signout|\/log(?:_|\/|$)|javascript:/i.test(link.href))score-=30;
        return {...link,score};
      }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score);
      trace.push({label:'account-link-candidates',url:page.url(),time:new Date().toISOString(),candidates:candidates.slice(0,12)});

      for(const candidate of candidates.slice(0,12)){
        await page.goto(candidate.href,{waitUntil:'domcontentloaded'}).catch(()=>null);
        await page.waitForTimeout(700);
        await record(`account-candidate-${candidate.index}`);
        const candidateHtml=await page.content().catch(()=>'');
        if(!isJadLoginPage(candidateHtml,page.url())){
          accountForm=await findAccountForm();
          if(accountForm)break;
        }
        await page.goto(authenticatedUrl,{waitUntil:'domcontentloaded'}).catch(()=>null);
        await page.waitForTimeout(500);
      }
    }

    // Final fallback: try the configured/known account URL, but never accept a
    // redirect back to the login page as a valid account page.
    if(!accountForm){
      await page.goto(accountUrl,{waitUntil:'domcontentloaded'}).catch(()=>null);
      await page.waitForLoadState('networkidle',{timeout:12000}).catch(()=>null);
      await page.waitForTimeout(900);
      await record('account-page-fallback');
      const accountHtml=await page.content().catch(()=>'');
      if(!isJadLoginPage(accountHtml,page.url()))accountForm=await findAccountForm();
    }

    if(!accountForm){
      const forms=await page.locator('form').evaluateAll(items=>items.map((form,index)=>({
        index,
        action:form.action,
        method:form.method,
        controls:[...form.elements].map(el=>({name:el.name||'',type:el.type||'',value:el.value||''})).filter(x=>x.name)
      }))).catch(()=>[]);
      trace.push({label:'account-forms-final',url:page.url(),time:new Date().toISOString(),forms});
      throw await diagnosticError('تم تسجيل الدخول، لكن لم يتم العثور على نموذج كشف الحساب في صفحات جاد المتاحة','JAD_ACCOUNT_FORM_NOT_FOUND');
    }
    await record('account-form-ready');

    const formInfo=await accountForm.evaluate(form=>({
      action:form.action,
      method:(form.method||"POST").toUpperCase(),
      controls:[...form.elements].map(el=>({
        name:el.name||"",type:el.type||"",tag:el.tagName||"",value:el.value||"",
        options:el.tagName==="SELECT"?[...el.options].map(o=>({value:o.value,text:o.text,selected:o.selected})):undefined
      })).filter(x=>x.name)
    }));
    trace.push({label:"account-form-detected",url:page.url(),time:new Date().toISOString(),form:{action:formInfo.action,method:formInfo.method,controls:formInfo.controls.map(c=>({name:c.name,type:c.type,tag:c.tag,value:/pass|token|otp/i.test(c.name)?"[hidden]":safeText(c.value)}))}});

    const setNamedValue=async(name,value)=>{
      const field=accountForm.locator(`[name="${name}"]`).first();
      if(await field.count()===0)return false;
      const tag=await field.evaluate(el=>el.tagName).catch(()=>"");
      if(tag==="SELECT"){
        const selected=await field.selectOption(String(value)).catch(()=>[]);
        if(!selected.length){
          await field.selectOption({label:String(value)}).catch(()=>[]);
        }
      }else{
        await field.fill(String(value)).catch(async()=>{await field.evaluate((el,v)=>{el.value=v;el.dispatchEvent(new Event("input",{bubbles:true}));el.dispatchEvent(new Event("change",{bubbles:true}));},String(value));});
      }
      return true;
    };

    await setNamedValue("currency",String(partner.accountCurrency||"USD").toLowerCase());
    await setNamedValue("date1","date");
    await setNamedValue("date2",start);
    await setNamedValue("date3",end);

    // Select the external account only in a genuine account/customer control.
    // Never overwrite the submit button named `confirm`.
    if(accountId){
      const accountCandidates=accountForm.locator('select, input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="date"])');
      let accountChosen=false;
      for(let i=0;i<await accountCandidates.count();i+=1){
        const candidate=accountCandidates.nth(i);
        const meta=await candidate.evaluate(el=>({name:el.name||"",id:el.id||"",tag:el.tagName||"",type:el.type||"",placeholder:el.placeholder||"",options:el.tagName==="SELECT"?[...el.options].map(o=>({value:o.value,text:o.text})):[]})).catch(()=>({}));
        if(/^(currency|date1|date2|date3|confirm)$/i.test(meta.name||""))continue;
        const signature=`${meta.name||""} ${meta.id||""} ${meta.placeholder||""}`;
        const optionMatch=Array.isArray(meta.options)&&meta.options.some(o=>String(o.value)===accountId||String(o.text).includes(accountId));
        if(optionMatch||/account|client|customer|cust|member|رقم|حساب|عميل/i.test(signature)){
          if(meta.tag==="SELECT"){
            const result=await candidate.selectOption(accountId).catch(()=>[]);
            if(!result.length)await candidate.selectOption({label:accountId}).catch(()=>[]);
          }else await candidate.fill(accountId).catch(()=>null);
          accountChosen=true;
          trace.push({label:"account-selected",control:meta.name||meta.id||"unknown",time:new Date().toISOString()});
          break;
        }
      }
      if(!accountChosen)trace.push({label:"account-control-not-found",accountId:"[configured]",time:new Date().toISOString()});
    }

    let html="";
    let postedStatus=0;
    let postedUrl=page.url();
    for(let attempt=1;attempt<=3;attempt+=1){
      // Do not click Jad's disabled Save button. Serialize and POST the real form
      // from inside the authenticated browser page, preserving cookies, hidden
      // fields, disabled named controls and the submit button name/value.
      const formSnapshot=await accountForm.evaluate(form=>({
        action:form.action||location.href,
        method:(form.method||"POST").toUpperCase(),
        valid:typeof form.checkValidity==="function"?form.checkValidity():true,
        controls:[...form.elements].map(el=>({
          name:el.name||"",type:el.type||"",tag:el.tagName||"",value:el.value||"",
          disabled:Boolean(el.disabled),required:Boolean(el.required),
          valid:el.validity?el.validity.valid:true,validationMessage:el.validationMessage||""
        })).filter(item=>item.name)
      })).catch(()=>null);
      trace.push({label:`account-form-state-${attempt}`,time:new Date().toISOString(),form:formSnapshot?{
        action:formSnapshot.action,method:formSnapshot.method,valid:formSnapshot.valid,
        controls:formSnapshot.controls.map(c=>({name:c.name,type:c.type,tag:c.tag,value:/pass|token|otp/i.test(c.name)?"[hidden]":safeText(c.value),disabled:c.disabled,required:c.required,valid:c.valid,validationMessage:safeText(c.validationMessage)}))
      }:null});

      const posted=await accountForm.evaluate(async form=>{
        const pairs=[];
        const add=(name,value)=>{if(name)pairs.push([String(name),String(value??"")]);};
        for(const el of [...form.elements]){
          if(!el.name)continue;
          const type=String(el.type||"").toLowerCase();
          if((type==="checkbox"||type==="radio")&&!el.checked)continue;
          if(el.tagName==="SELECT"&&el.multiple){
            for(const option of [...el.selectedOptions])add(el.name,option.value);
          }else if(type!=="submit"&&type!=="button"&&type!=="reset"&&type!=="file"){
            add(el.name,el.value);
          }
        }
        const submitter=form.querySelector('[name="confirm"],button[type="submit"],input[type="submit"]');
        if(submitter&&submitter.name)add(submitter.name,submitter.value||"");
        const body=new URLSearchParams();
        for(const [key,value] of pairs)body.append(key,value);
        const target=new URL(form.action||location.href,location.href).href;
        const method=(form.method||"POST").toUpperCase();
        const response=await fetch(target,{
          method,credentials:"include",redirect:"follow",
          headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8","Accept":"text/html,application/xhtml+xml"},
          body:method==="GET"?undefined:body.toString()
        });
        return {status:response.status,url:response.url,html:await response.text(),payload:[...body.entries()]};
      }).catch(error=>({error:String(error&&error.message||error)}));

      if(!posted||posted.error){
        trace.push({label:`account-direct-post-error-${attempt}`,time:new Date().toISOString(),error:posted?.error||"unknown"});
        await page.waitForTimeout(700*attempt);
        continue;
      }

      postedUrl=posted.url;
      postedStatus=posted.status;
      html=posted.html;
      const text=safeText(htmlText(html).slice(0,1200));
      trace.push({label:`account-direct-post-${attempt}`,url:postedUrl,status:postedStatus,time:new Date().toISOString(),payload:posted.payload.map(([k,v])=>[k,/pass|token|otp/i.test(k)?"[hidden]":safeText(v)]),text});
      if(postedStatus>=200&&postedStatus<400&&(/<tbody/i.test(html)||/كشف\s*حساب|الرصيد|مدين|دائن|حركة/i.test(text)))break;
      await page.waitForTimeout(900*attempt);
    }

    if(postedStatus<200||postedStatus>=400)throw await diagnosticError(`تعذر إرسال نموذج كشف الحساب الحقيقي إلى جاد (${postedStatus})`,"JAD_ACCOUNT_POST_FAILED");
    if(isJadLoginPage(html,postedUrl)&&!/<tbody/i.test(html))throw await diagnosticError("رفض موقع جاد الجلسة عند طلب كشف الحساب؛ أدخل رمز Authenticator جديدًا","JAD_SESSION_REJECTED");
    if(!/<tbody/i.test(html)&&!/كشف\s*حساب|الرصيد|مدين|دائن|حركة/i.test(htmlText(html)))throw await diagnosticError("تم تسجيل الدخول وإرسال النموذج، لكن جاد لم يعرض كشف الحساب. تحقق من رقم الحساب الخارجي أو اختر الحساب الصحيح","JAD_STATEMENT_NOT_FOUND");
    const statement=parseJadStatement(html);
    const currencyBalances={...dashboardCurrencyBalances};
    const statementCurrency=String(partner.accountCurrency||"USD").toUpperCase();
    if(!currencyBalances[statementCurrency] && (statement.receivable||statement.payable||statement.balance)){
      currencyBalances[statementCurrency]={receivable:statement.receivable,payable:statement.payable,balance:statement.balance};
    }
    const freshStorageState=await context.storageState().catch(()=>null);
    return {...statement,currencies:currencyBalances,fromDate:start,toDate:end,mode:"BROWSER",diagnostic:trace.slice(-10),_storageState:freshStorageState};
  }catch(error){
    if(!error.jadTrace)error.jadTrace=trace.slice(-16);
    if(!error.jadArtifacts)error.jadArtifacts=await saveDiagnosticArtifacts(error.code||"JAD_ERROR");
    if(!error.jadDetails)error.jadDetails=errorDetails(error);
    console.error("[JAD][FAILURE]",{code:error.code||"JAD_ERROR",message:error.message,details:error.jadDetails,trace:error.jadTrace,artifacts:error.jadArtifacts});
    throw error;
  }finally{
    if(browser)await browser.close().catch(closeError=>console.error("[JAD][CHROMIUM][CLOSE_FAILED]",errorDetails(closeError)));
    console.log("[JAD][END]",{partnerId:partner.id,time:new Date().toISOString()});
  }
}

async function syncJadPartner(partner,options={}){
  const mode=String(process.env.JAD_CONNECTOR_MODE||"browser").toLowerCase();
  if(mode==="http")return syncJadPartnerHttp(partner,options);
  try{
    return await syncJadPartnerBrowser(partner,options);
  }catch(error){
    // إذا رفض جاد الجلسة المحفوظة، نعيد المحاولة مرة واحدة بجلسة جديدة.
    // هذا يعيد سلوك الربط البسيط الذي كان أكثر استقرارًا في الإصدارات القديمة.
    const hasSavedSession=Boolean(partner?.jadStorageStateEncrypted);
    if(hasSavedSession && ["JAD_SESSION_REJECTED","JAD_LOGIN_REJECTED"].includes(String(error?.code||""))){
      console.warn("[JAD][SESSION][RETRY_FRESH]",{partnerId:partner.id,code:error.code});
      const freshPartner={...partner,jadStorageStateEncrypted:""};
      return await syncJadPartnerBrowser(freshPartner,options);
    }
    const allowFallback=String(process.env.JAD_HTTP_FALLBACK||"false").toLowerCase()==="true";
    if(!allowFallback||error?.code!=="JAD_BROWSER_UNAVAILABLE")throw error;
    console.warn("[JAD] Browser connector unavailable; falling back to HTTP connector:",error?.message||error);
    return syncJadPartnerHttp(partner,options);
  }
}


app.get("/api/partners", auth, (_req,res)=>{
  const store=readStore();
  const partners=Array.isArray(store.partners)?store.partners:[];
  const transactions=Array.isArray(store.partnerTransactions)?store.partnerTransactions:[];
  const payments=Array.isArray(store.partnerPayments)?store.partnerPayments:[];

  const rows=partners.map(partner=>{
    const partnerTransactions=transactions.filter(item=>item.partnerId===partner.id);
    const partnerPayments=payments.filter(item=>item.partnerId===partner.id);

    const receivable=partnerTransactions
      .filter(item=>item.type==="RECEIVABLE")
      .reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);

    const payable=partnerTransactions
      .filter(item=>item.type==="PAYABLE")
      .reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);

    const receivedPayments=partnerPayments
      .filter(item=>item.direction==="RECEIVED")
      .reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);

    const paidPayments=partnerPayments
      .filter(item=>item.direction==="PAID")
      .reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);

    const receivableBalance=Math.max(receivable-receivedPayments,0)+safeNumber(partner.externalReceivable);
    const payableBalance=Math.max(payable-paidPayments,0)+safeNumber(partner.externalPayable);

    const {passwordEncrypted,...publicPartner}=partner;
    return {
      ...publicPartner,
      hasPassword:Boolean(passwordEncrypted),
      receivable:+receivableBalance.toFixed(2),
      payable:+payableBalance.toFixed(2),
      net:+(receivableBalance-payableBalance).toFixed(2)
    };
  }).sort((a,b)=>String(a.name).localeCompare(String(b.name),"ar"));

  const totals=rows.reduce((acc,item)=>{
    acc.receivable+=safeNumber(item.receivable);
    acc.payable+=safeNumber(item.payable);
    return acc;
  },{receivable:0,payable:0});

  res.json({
    rows,
    totals:{
      receivable:+totals.receivable.toFixed(2),
      payable:+totals.payable.toFixed(2),
      net:+(totals.receivable-totals.payable).toFixed(2)
    }
  });
});

app.post("/api/partners", auth, (req,res)=>{
  const {
    name,
    contactName="",
    phone="",
    whatsapp="",
    email="",
    country="",
    city="",
    address="",
    notes="",
    systemUrl="",
    connectionType="WEB",
    accountCurrency="CAD",
    integrationName="",
    username="",
    password="",
    externalAccountId="",
    connectorType="GENERIC",
    pathPrefix="/ssljd/merkez112/1/2",
    syncFromDate="",
    syncEnabled=false
  }=req.body||{};

  if(!name)return res.status(400).json({message:"اسم المورد أو الشركة مطلوب"});

  const partner=mutate(store=>{
    const item={
      id:id(),
      name:String(name),
      contactName,
      phone,
      whatsapp,
      email,
      country,
      city,
      address,
      notes,
      systemUrl:String(systemUrl||"").trim(),
      connectionType:["API","WEB","CSV","EXCEL","PDF"].includes(String(connectionType).toUpperCase())?String(connectionType).toUpperCase():"WEB",
      accountCurrency:String(accountCurrency||"CAD").toUpperCase(),
      integrationName:String(integrationName||name),
      username:String(username||""),
      passwordEncrypted:encryptIntegrationSecret(password),
      externalAccountId:String(externalAccountId||""),
      connectorType:String(connectorType||"GENERIC").toUpperCase(),
      pathPrefix:String(pathPrefix||"/ssljd/merkez112/1/2"),
      syncFromDate:String(syncFromDate||""),
      externalReceivable:0,externalPayable:0,externalBalance:0,
      syncEnabled:Boolean(syncEnabled),
      connectionStatus:String(systemUrl||"").trim()?"CONFIGURED":"MANUAL",
      lastSyncAt:null,
      createdAt:now(),
      createdBy:req.user.id
    };
    store.partners.push(item);
    audit(store,req.user.id,"CREATE","PARTNER",item.id,{name:item.name});
    return item;
  });

  res.status(201).json(partner);
});

app.patch("/api/partners/:id", auth, (req,res)=>{
  const allowed=["name","contactName","phone","whatsapp","email","country","city","address","notes","systemUrl","connectionType","accountCurrency","integrationName","username","externalAccountId","connectorType","pathPrefix","syncFromDate","syncEnabled"];
  let updated=null;
  mutate(store=>{
    const partner=store.partners.find(item=>item.id===req.params.id);
    if(!partner)return;
    if(req.body?.password)partner.passwordEncrypted=encryptIntegrationSecret(req.body.password);
    for(const key of allowed){
      if(req.body?.[key]===undefined)continue;
      partner[key]=key==="syncEnabled"?Boolean(req.body[key]):String(req.body[key]??"");
    }
    partner.connectionType=String(partner.connectionType||"WEB").toUpperCase();
    partner.accountCurrency=String(partner.accountCurrency||"CAD").toUpperCase();
    partner.connectionStatus=String(partner.systemUrl||"").trim()?"CONFIGURED":"MANUAL";
    partner.updatedAt=now();
    audit(store,req.user.id,"UPDATE","PARTNER",partner.id,{integration:true});
    updated={...partner};
  });
  if(!updated)return res.status(404).json({message:"الشركة غير موجودة"});
  res.json(updated);
});

app.post("/api/partners/:id/test-connection", auth, async (req,res)=>{
  const store=readStore();const partner=(store.partners||[]).find(item=>item.id===req.params.id);
  if(!partner)return res.status(404).json({message:"الشركة غير موجودة"});
  try{
    if(String(partner.connectorType||"").toUpperCase()==="JAD"){
      const result=await syncJadPartner(partner,{fromDate:new Date(Date.now()-7*86400000).toISOString().slice(0,10),otp:req.body?.otp});
      mutate(current=>{const item=current.partners.find(x=>x.id===partner.id);if(item){item.connectionStatus="READY";item.lastConnectionTestAt=now();item.lastSyncError="";item.lastJadDiagnostic=[];item.lastJadArtifacts=null;item.updatedAt=now();}});
      return res.json({ok:true,status:"READY",message:`تم الاتصال بنجاح، الرصيد المكتشف ${result.balance} ${partner.accountCurrency||"USD"}`});
    }
    normalizeBaseUrl(partner.systemUrl);
    mutate(current=>{const item=current.partners.find(x=>x.id===partner.id);if(item){item.connectionStatus="READY";item.lastConnectionTestAt=now();item.updatedAt=now();}});
    res.json({ok:true,status:"READY",message:"الرابط صالح. اختر موصل الشركة لإجراء مزامنة فعلية."});
  }catch(error){
    mutate(current=>{const item=current.partners.find(x=>x.id===partner.id);if(item){
      // لا نحول الشركة إلى "خطأ" إذا سبق أن نجحت مزامنة فعلية وجُلب الرصيد.
      // نحفظ خطأ المحاولة الأخيرة كسجل تحذيري فقط، وتبقى الحالة "متصل" حتى تنجح/تفشل مزامنة فعلية جديدة دون أي نجاح سابق.
      const hasSuccessfulSync=Boolean(item.lastSyncAt) && Number.isFinite(Number(item.externalBalance));
      item.connectionStatus=hasSuccessfulSync?"READY":"ERROR";
      item.lastSyncError=String(error.message||error);
      item.lastConnectionTestErrorAt=now();
      item.lastJadDiagnostic=Array.isArray(error.jadTrace)?error.jadTrace.slice(-16):[];
      item.lastJadArtifacts=error.jadArtifacts||null;
      item.updatedAt=now();
    }});
    res.status(400).json({message:error.message||"تعذر اختبار الاتصال",code:error.code||"JAD_ERROR",diagnostic:Array.isArray(error.jadTrace)?error.jadTrace.slice(-10):[],artifacts:error.jadArtifacts?{available:true,createdAt:error.jadArtifacts.createdAt}:null,details:error.jadDetails||null});
  }
});

app.post("/api/partners/:id/sync", auth, async (req,res)=>{
  const snapshot=readStore();const partner=(snapshot.partners||[]).find(item=>item.id===req.params.id);
  if(!partner)return res.status(404).json({message:"الشركة غير موجودة"});
  if(String(partner.connectorType||"").toUpperCase()!=="JAD")return res.status(400).json({message:"لا يوجد موصل فعلي محدد لهذه الشركة"});
  try{
    const result=await syncJadPartner(partner,{fromDate:req.body?.fromDate,toDate:req.body?.toDate,otp:req.body?.otp});
    const storageState=result?._storageState||null;
    if(result&&Object.prototype.hasOwnProperty.call(result,"_storageState"))delete result._storageState;
    let publicPartner=null;
    mutate(store=>{
      const item=store.partners.find(x=>x.id===partner.id);if(!item)return;
      const mainDebt=normalizeJadCurrencyDebt(result.receivable,result.payable,{prefer:safeNumber(result.balance)<0?"PAYABLE":"RECEIVABLE"});
      const normalizedCurrencies={};
      for(const [currency,value] of Object.entries((result.currencies&&typeof result.currencies==="object")?result.currencies:{})){
        normalizedCurrencies[String(currency).toUpperCase()]=normalizeJadCurrencyDebt(value?.receivable,value?.payable,{prefer:safeNumber(value?.balance)<0?"PAYABLE":"RECEIVABLE"});
      }
      result.receivable=mainDebt.receivable;result.payable=mainDebt.payable;result.balance=mainDebt.balance;result.currencies=normalizedCurrencies;
      item.externalReceivable=result.receivable;item.externalPayable=result.payable;item.externalBalance=result.balance;item.externalBalances=normalizedCurrencies;
      if(storageState)item.jadStorageStateEncrypted=encryptIntegrationSecret(JSON.stringify(storageState));
      item.lastSyncAt=now();item.lastSyncError="";item.lastJadDiagnostic=[];item.lastJadArtifacts=null;item.connectionStatus="READY";item.updatedAt=now();
      item.lastImportedMovementCount=result.movements.length;
      const {passwordEncrypted,...safe}=item;publicPartner={...safe,hasPassword:Boolean(passwordEncrypted)};
      audit(store,req.user.id,"SYNC","PARTNER",item.id,{connector:"JAD",balance:result.balance,receivable:result.receivable,payable:result.payable,currencies:Object.keys(result.currencies||{}),count:result.movements.length});
    });
    res.json({message:"تم جلب الرصيد من شركة جاد",partner:publicPartner,result:{...result,movements:result.movements.slice(-20)}});
  }catch(error){
    let stalePartner=null;
    let hasSuccessfulSync=false;
    mutate(store=>{const item=store.partners.find(x=>x.id===partner.id);if(item){
      // لا نمسح آخر رصيد ناجح عند انتهاء OTP أو انقطاع جاد مؤقتًا.
      hasSuccessfulSync=Boolean(item.lastSyncAt) && (
        Number.isFinite(Number(item.externalBalance)) ||
        (item.externalBalances && typeof item.externalBalances==="object" && Object.keys(item.externalBalances).length>0)
      );
      item.connectionStatus=hasSuccessfulSync?"READY":"ERROR";
      item.lastSyncError=String(error.message||error);
      if(["JAD_SESSION_REJECTED","JAD_LOGIN_REJECTED"].includes(String(error.code||"")))item.jadStorageStateEncrypted="";
      item.lastSyncAttemptErrorAt=now();
      item.lastJadDiagnostic=Array.isArray(error.jadTrace)?error.jadTrace.slice(-16):[];
      item.lastJadArtifacts=error.jadArtifacts||null;
      item.updatedAt=now();
      if(hasSuccessfulSync){
        const {passwordEncrypted,...safe}=item;
        stalePartner={...safe,hasPassword:Boolean(passwordEncrypted)};
      }
    }});
    if(hasSuccessfulSync&&stalePartner){
      return res.json({
        ok:true,
        stale:true,
        message:"تعذر تحديث الرصيد الآن؛ تم الاحتفاظ بآخر رصيد ناجح",
        reason:String(error.message||"تعذر تحديث البيانات مؤقتًا"),
        partner:stalePartner,
        lastSyncAt:stalePartner.lastSyncAt,
        result:{
          balance:safeNumber(stalePartner.externalBalance),
          receivable:safeNumber(stalePartner.externalReceivable),
          payable:safeNumber(stalePartner.externalPayable),
          currencies:stalePartner.externalBalances&&typeof stalePartner.externalBalances==="object"?stalePartner.externalBalances:{},
          movements:[]
        },
        warningCode:error.code||"JAD_TEMPORARY_ERROR"
      });
    }
    res.status(400).json({message:error.message||"تعذر جلب الرصيد",code:error.code||"JAD_ERROR",diagnostic:Array.isArray(error.jadTrace)?error.jadTrace.slice(-10):[],artifacts:error.jadArtifacts?{available:true,createdAt:error.jadArtifacts.createdAt}:null,details:error.jadDetails||null});
  }
});

app.get("/api/partners/:id/jad-diagnostic", auth, (req,res)=>{
  const store=readStore();
  const partner=(store.partners||[]).find(item=>item.id===req.params.id);
  if(!partner)return res.status(404).json({message:"الشركة غير موجودة"});
  res.json({message:partner.lastSyncError||"لا يوجد خطأ مسجل",diagnostic:Array.isArray(partner.lastJadDiagnostic)?partner.lastJadDiagnostic:[],artifacts:partner.lastJadArtifacts?{available:true,createdAt:partner.lastJadArtifacts.createdAt}:null,lastSyncAt:partner.lastSyncAt||null,status:partner.connectionStatus||"CONFIGURED"});
});

app.get("/api/partners/:id/jad-diagnostic/screenshot", auth, (req,res)=>{
  const store=readStore();
  const partner=(store.partners||[]).find(item=>item.id===req.params.id);
  if(!partner)return res.status(404).json({message:"الشركة غير موجودة"});
  const file=partner.lastJadArtifacts?.png;
  if(!file||!fs.existsSync(file))return res.status(404).json({message:"لا توجد لقطة تشخيص متاحة؛ أعد اختبار الاتصال ثم افتح اللقطة مباشرة"});
  res.type("png").sendFile(path.resolve(file));
});

app.get("/api/partners/:id", auth, (req,res)=>{
  const store=readStore();
  const partner=(Array.isArray(store.partners)?store.partners:[])
    .find(item=>item?.id===req.params.id);

  if(!partner)return res.status(404).json({message:"المورد أو الشركة غير موجود"});

  const transactions=(Array.isArray(store.partnerTransactions)?store.partnerTransactions:[])
    .filter(item=>item.partnerId===partner.id)
    .sort((a,b)=>String(b.date||b.createdAt).localeCompare(String(a.date||a.createdAt)));

  const payments=(Array.isArray(store.partnerPayments)?store.partnerPayments:[])
    .filter(item=>item.partnerId===partner.id)
    .sort((a,b)=>String(b.date||b.createdAt).localeCompare(String(a.date||a.createdAt)));

  const receivable=transactions.filter(item=>item.type==="RECEIVABLE")
    .reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);
  const payable=transactions.filter(item=>item.type==="PAYABLE")
    .reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);
  const received=payments.filter(item=>item.direction==="RECEIVED")
    .reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);
  const paid=payments.filter(item=>item.direction==="PAID")
    .reduce((sum,item)=>sum+safeNumber(item.cadAmount??item.amount),0);

  const {passwordEncrypted,...safePartner}=partner;
  res.json({
    partner:{...safePartner,hasPassword:Boolean(passwordEncrypted)},
    transactions,
    payments,
    totals:{
      receivable:+(Math.max(receivable-received,0)+safeNumber(partner.externalReceivable)).toFixed(2),
      payable:+(Math.max(payable-paid,0)+safeNumber(partner.externalPayable)).toFixed(2),
      net:+(Math.max(receivable-received,0)-Math.max(payable-paid,0)).toFixed(2)
    }
  });
});

app.post("/api/partners/:id/transactions", auth, (req,res)=>{
  const {type,amount,currency="CAD",date="",dueDate="",reference="",description=""}=req.body||{};
  const numericAmount=Number(amount);

  if(!["RECEIVABLE","PAYABLE"].includes(type)){
    return res.status(400).json({message:"نوع العملية غير صحيح"});
  }
  if(!Number.isFinite(numericAmount)||numericAmount<=0){
    return res.status(400).json({message:"المبلغ غير صحيح"});
  }

  const store=readStore();
  const partner=(Array.isArray(store.partners)?store.partners:[])
    .find(item=>item?.id===req.params.id);
  if(!partner)return res.status(404).json({message:"المورد أو الشركة غير موجود"});

  const transaction=mutate(currentStore=>{
    const item={
      id:id(),
      partnerId:partner.id,
      type,
      amount:numericAmount,
      currency:String(currency).toUpperCase(),
      date:date||new Date().toISOString().slice(0,10),
      dueDate:dueDate||"",
      reference,
      description,
      createdAt:now(),
      createdBy:req.user.id
    };
    currentStore.partnerTransactions.push(item);
    audit(currentStore,req.user.id,"CREATE","PARTNER_TRANSACTION",item.id,{
      partnerId:partner.id,type,amount:numericAmount
    });
    return item;
  });

  res.status(201).json(transaction);
});

app.post("/api/partners/:id/payments", auth, (req,res)=>{
  const {direction,amount,currency="CAD",date="",reference="",notes=""}=req.body||{};
  const numericAmount=Number(amount);

  if(!["RECEIVED","PAID"].includes(direction)){
    return res.status(400).json({message:"اتجاه الدفعة غير صحيح"});
  }
  if(!Number.isFinite(numericAmount)||numericAmount<=0){
    return res.status(400).json({message:"المبلغ غير صحيح"});
  }

  const store=readStore();
  const partner=(Array.isArray(store.partners)?store.partners:[])
    .find(item=>item?.id===req.params.id);
  if(!partner)return res.status(404).json({message:"المورد أو الشركة غير موجود"});

  const payment=mutate(currentStore=>{
    const item={
      id:id(),
      partnerId:partner.id,
      direction,
      amount:numericAmount,
      currency:String(currency).toUpperCase(),
      date:date||new Date().toISOString().slice(0,10),
      reference,
      notes,
      createdAt:now(),
      createdBy:req.user.id
    };
    currentStore.partnerPayments.push(item);
    audit(currentStore,req.user.id,"PAYMENT","PARTNER",partner.id,{
      direction,amount:numericAmount
    });
    return item;
  });

  res.status(201).json(payment);
});

app.get("/api/partners/:id/statement", auth, (req,res)=>{
  const store=readStore();
  const partner=(Array.isArray(store.partners)?store.partners:[])
    .find(item=>item?.id===req.params.id);

  if(!partner)return res.status(404).json({message:"المورد أو الشركة غير موجود"});

  const from=String(req.query.from||"");
  const to=String(req.query.to||"");
  const inRange=(date)=>{
    const value=String(date||"").slice(0,10);
    return (!from||value>=from)&&(!to||value<=to);
  };

  const transactions=(Array.isArray(store.partnerTransactions)?store.partnerTransactions:[])
    .filter(item=>item.partnerId===partner.id&&inRange(item.date||item.createdAt));
  const payments=(Array.isArray(store.partnerPayments)?store.partnerPayments:[])
    .filter(item=>item.partnerId===partner.id&&inRange(item.date||item.createdAt));

  const entries=[
    ...transactions.map(item=>({
      id:item.id,
      date:item.date||String(item.createdAt).slice(0,10),
      kind:item.type==="RECEIVABLE"?"دين لنا":"دين علينا",
      debit:item.type==="RECEIVABLE"?safeNumber(item.amount):0,
      credit:item.type==="PAYABLE"?safeNumber(item.amount):0,
      reference:item.reference||"",
      description:item.description||""
    })),
    ...payments.map(item=>({
      id:item.id,
      date:item.date||String(item.createdAt).slice(0,10),
      kind:item.direction==="RECEIVED"?"استلام دفعة":"دفع مبلغ",
      debit:item.direction==="PAID"?safeNumber(item.amount):0,
      credit:item.direction==="RECEIVED"?safeNumber(item.amount):0,
      reference:item.reference||"",
      description:item.notes||""
    }))
  ].sort((a,b)=>String(a.date).localeCompare(String(b.date)));

  let runningBalance=0;
  const rows=entries.map(entry=>{
    runningBalance+=safeNumber(entry.debit)-safeNumber(entry.credit);
    return {...entry,balance:+runningBalance.toFixed(2)};
  });

  res.json({
    company:{name:"شركة العبود للتجارة",nameEn:"AlAboud Trading Company"},
    partner,
    from:from||null,
    to:to||null,
    generatedAt:now(),
    rows,
    finalBalance:+runningBalance.toFixed(2)
  });
});


function aiMonthKey(value){return String(value||"").slice(0,7)}
function aiDateKey(value){return String(value||"").slice(0,10)}
function aiAnalytics(store){
  const today=new Date();
  const todayKey=today.toISOString().slice(0,10);
  const monthKey=todayKey.slice(0,7);
  const previousMonth=new Date(Date.UTC(today.getUTCFullYear(),today.getUTCMonth()-1,1)).toISOString().slice(0,7);
  const validTx=(store.transactions||[]).filter(t=>t&&!t.isDeleted&&t.status!=="CANCELLED");
  const expenses=(store.expenses||[]).filter(e=>e&&!e.isDeleted);
  const customers=(store.customers||[]).filter(c=>c&&!c.isDeleted).map(c=>customerSummary(store,c));
  const txProfit=rows=>rows.reduce((a,t)=>a+safeNumber(t.totalProfit),0);
  const expenseCad=rows=>rows.reduce((a,e)=>a+safeNumber(e.cadAmount,e.amount),0);
  const monthTx=validTx.filter(t=>aiMonthKey(t.transferDate||t.createdAt)===monthKey);
  const previousTx=validTx.filter(t=>aiMonthKey(t.transferDate||t.createdAt)===previousMonth);
  const monthExpenses=expenses.filter(e=>aiMonthKey(e.date||e.createdAt)===monthKey);
  const previousExpenses=expenses.filter(e=>aiMonthKey(e.date||e.createdAt)===previousMonth);
  const todayTx=validTx.filter(t=>aiDateKey(t.transferDate||t.createdAt)===todayKey);
  const todayExpenses=expenses.filter(e=>aiDateKey(e.date||e.createdAt)===todayKey);
  const monthNet=txProfit(monthTx)-expenseCad(monthExpenses);
  const previousNet=txProfit(previousTx)-expenseCad(previousExpenses);
  const receivables=customers.reduce((a,c)=>a+safeNumber(c.finalBalance),0);
  const overdue=customers.filter(c=>c.overdue).sort((a,b)=>b.finalBalance-a.finalBalance);
  const capital=(store.capitalMovements||[]).reduce((a,m)=>a+(m.type==="IN"?safeNumber(m.amount):-safeNumber(m.amount)),0);
  const categoryTotals={};
  for(const e of monthExpenses){const k=e.category||"Other";categoryTotals[k]=(categoryTotals[k]||0)+safeNumber(e.cadAmount,e.amount)}
  const currencyTotals={};
  for(const t of monthTx){const k=t.currency||"CAD";currencyTotals[k]=(currencyTotals[k]||0)+safeNumber(t.amount)}
  const topExpense=Object.entries(categoryTotals).sort((a,b)=>b[1]-a[1])[0]||["لا يوجد",0];
  const topCurrency=Object.entries(currencyTotals).sort((a,b)=>b[1]-a[1])[0]||["لا يوجد",0];
  const duplicateExpenses=[];
  const seen=new Map();
  for(const e of expenses){const key=[e.title,e.amount,e.currency,e.date].join('|');if(seen.has(key))duplicateExpenses.push(e);else seen.set(key,e.id)}
  const anomalies=[];
  if(duplicateExpenses.length)anomalies.push({level:"warning",title:"مصروفات مكررة محتملة",message:`تم العثور على ${duplicateExpenses.length} مصروفات متشابهة تحتاج مراجعة.`});
  if(monthExpenses.length>=3){const avg=expenseCad(monthExpenses)/monthExpenses.length;for(const e of monthExpenses){if(safeNumber(e.cadAmount,e.amount)>avg*3)anomalies.push({level:"danger",title:"مصروف غير اعتيادي",message:`المصروف ${e.title} أعلى بكثير من متوسط هذا الشهر.`})}}
  if(overdue.length)anomalies.push({level:"danger",title:"ديون متأخرة",message:`يوجد ${overdue.length} عملاء متأخرين بإجمالي ${receivables.toFixed(2)} CAD.`});
  const profitTrend=previousNet?((monthNet-previousNet)/Math.abs(previousNet))*100:(monthNet>0?100:0);
  let score=100;
  if(monthNet<0)score-=30;
  if(profitTrend<-15)score-=15;
  if(capital<safeNumber(store.notificationSettings?.lowCashLimit,5000))score-=20;
  if(overdue.length)score-=Math.min(20,overdue.length*3);
  if(anomalies.length)score-=Math.min(15,anomalies.length*3);
  score=Math.max(0,Math.min(100,Math.round(score)));
  const recentMonths=[];
  for(let i=5;i>=0;i--){const d=new Date(Date.UTC(today.getUTCFullYear(),today.getUTCMonth()-i,1));const key=d.toISOString().slice(0,7);const t=validTx.filter(x=>aiMonthKey(x.transferDate||x.createdAt)===key);const e=expenses.filter(x=>aiMonthKey(x.date||x.createdAt)===key);recentMonths.push({month:key,net:+(txProfit(t)-expenseCad(e)).toFixed(2),expenses:+expenseCad(e).toFixed(2),profit:+txProfit(t).toFixed(2)})}
  const values=recentMonths.map(x=>x.net);const forecast=values.length?values.reduce((a,b)=>a+b,0)/values.length:0;
  const recommendations=[];
  if(overdue.length)recommendations.push(`ابدأ بتحصيل ديون ${overdue.slice(0,3).map(c=>c.name).join("، ")}.`);
  if(topExpense[1]>0)recommendations.push(`راجع مصروفات ${topExpense[0]} لأنها الأعلى هذا الشهر.`);
  if(profitTrend<0)recommendations.push("راجع أسعار البيع والتكاليف لأن صافي الربح أقل من الشهر الماضي.");
  if(capital<safeNumber(store.notificationSettings?.lowCashLimit,5000))recommendations.push("السيولة أقل من الحد المحدد؛ قلل المصروفات غير الضرورية مؤقتًا.");
  if(!recommendations.length)recommendations.push("الأداء مستقر. استمر في متابعة التحصيل والمصروفات يوميًا.");
  return {generatedAt:now(),healthScore:score,today:{transactions:todayTx.length,grossProfit:+txProfit(todayTx).toFixed(2),expenses:+expenseCad(todayExpenses).toFixed(2),netProfit:+(txProfit(todayTx)-expenseCad(todayExpenses)).toFixed(2)},month:{transactions:monthTx.length,grossProfit:+txProfit(monthTx).toFixed(2),expenses:+expenseCad(monthExpenses).toFixed(2),netProfit:+monthNet.toFixed(2),profitTrend:+profitTrend.toFixed(1),topExpenseCategory:topExpense[0],topCurrency:topCurrency[0]},finance:{capital:+capital.toFixed(2),receivables:+receivables.toFixed(2),overdueCount:overdue.length},forecast:{nextMonthNet:+forecast.toFixed(2),method:"متوسط آخر 6 أشهر"},anomalies:anomalies.slice(0,8),recommendations:recommendations.slice(0,6),overdueCustomers:overdue.slice(0,8),monthlyTrend:recentMonths,system:{database:process.env.DATABASE_URL?"PostgreSQL Cloud":"JSON Local",users:(store.users||[]).length,devices:(store.devices||[]).filter(d=>d.active).length,lastBackupAt:store.companySettings?.lastBackupAt||null}};
}
app.get("/api/ai/overview",auth,(req,res)=>res.json(aiAnalytics(readStore())));
app.post("/api/ai/assistant",auth,(req,res)=>{
  const question=String(req.body?.question||"").trim();
  if(!question)return res.status(400).json({message:"اكتب سؤالك أولاً"});
  const store=readStore();const a=aiAnalytics(store);const q=question.toLowerCase();let answer="";let data=[];let action=null;
  if(/ربح|ارباح|أرباح|profit/.test(q)){answer=`صافي ربح اليوم ${a.today.netProfit.toFixed(2)} CAD، وصافي ربح هذا الشهر ${a.month.netProfit.toFixed(2)} CAD. التغير عن الشهر السابق ${a.month.profitTrend.toFixed(1)}%.`;}
  else if(/مصروف|expenses?/.test(q)){answer=`مصروفات اليوم ${a.today.expenses.toFixed(2)} CAD، ومصروفات الشهر ${a.month.expenses.toFixed(2)} CAD. أعلى تصنيف هو ${a.month.topExpenseCategory}.`;data=(store.expenses||[]).slice().reverse().slice(0,10);}
  else if(/دين|متأخر|receivable/.test(q)){answer=`إجمالي الديون لنا ${a.finance.receivables.toFixed(2)} CAD، ويوجد ${a.finance.overdueCount} عملاء متأخرين.`;data=a.overdueCustomers;}
  else if(/رأس المال|راس المال|سيولة|capital/.test(q)){answer=`رأس المال المسجل حاليًا ${a.finance.capital.toFixed(2)} CAD. ${a.recommendations.find(x=>x.includes("السيولة"))||"السيولة ضمن المتابعة."}`;}
  else if(/توقع|forecast/.test(q)){answer=`التوقع التقريبي لصافي الشهر القادم هو ${a.forecast.nextMonthNet.toFixed(2)} CAD، اعتمادًا على ${a.forecast.method}.`;}
  else if(/صحة|تقييم|health/.test(q)){answer=`تقييم صحة الشركة ${a.healthScore} من 100. أهم توصية: ${a.recommendations[0]}`;}
  else if(/نسخ احتياطي|backup/.test(q)){answer="يمكنك إنشاء نسخة احتياطية الآن من الإعدادات. أوصي بإنشائها بعد أي تغييرات كبيرة.";action={type:"NAVIGATE",page:"settings"};}
  else if(/عميل/.test(q)){const name=question.replace(/.*عميل\s*/i,"").trim();const rows=(store.customers||[]).filter(c=>!c.isDeleted&&(!name||String(c.name||"").includes(name))).map(c=>customerSummary(store,c)).slice(0,10);answer=rows.length?`وجدت ${rows.length} نتيجة للعملاء.`:"لم أجد عميلًا مطابقًا.";data=rows;}
  else if(/حوال/.test(q)){data=(store.transactions||[]).filter(t=>!t.isDeleted).slice().reverse().slice(0,10);answer=`هذه أحدث ${data.length} حوالات مسجلة.`;}
  else {answer=`ملخص ذكي: صحة الشركة ${a.healthScore}/100، صافي الشهر ${a.month.netProfit.toFixed(2)} CAD، الديون لنا ${a.finance.receivables.toFixed(2)} CAD. ${a.recommendations[0]}`;}
  audit(store,req.user.id,"ASK","AI_ASSISTANT","assistant",{question:question.slice(0,250)});
  res.json({answer,data,action,overview:a});
});

app.get("/api/expenses", auth, (_req,res)=>res.json(readStore().expenses.slice().reverse()));
app.post("/api/expenses", auth, (req,res)=>{const {title,amount,currency="CAD",exchangeRate=1,category="Other",date=new Date().toISOString().slice(0,10)}=req.body||{};const n=Number(amount),rate=Number(exchangeRate);const normalizedCurrency=String(currency||"CAD").toUpperCase();if(!title||!Number.isFinite(n)||n<=0||!Number.isFinite(rate)||rate<=0)return res.status(400).json({message:"Invalid expense"});const e=mutate(s=>{const x={id:id(),title,amount:+n.toFixed(2),currency:normalizedCurrency,exchangeRate:+rate.toFixed(6),cadAmount:+(n*rate).toFixed(2),category,date,createdAt:now(),createdBy:req.user.id};s.expenses.push(x);audit(s,req.user.id,"CREATE","EXPENSE",x.id,{currency:x.currency,exchangeRate:x.exchangeRate,cadAmount:x.cadAmount});return x;});res.status(201).json(e);});
app.get("/api/capital", auth, (_req,res)=>res.json(readStore().capitalMovements.slice().reverse()));
app.post("/api/capital", auth, (req,res)=>{const {type="IN",amount,currency="CAD",description="",date=new Date().toISOString().slice(0,10)}=req.body||{};const n=Number(amount);if(!["IN","OUT"].includes(type)||!Number.isFinite(n)||n<=0)return res.status(400).json({message:"Invalid capital movement"});const m=mutate(s=>{const x={id:id(),type,amount:+n.toFixed(2),currency,description,date,createdAt:now(),createdBy:req.user.id};s.capitalMovements.push(x);audit(s,req.user.id,"CREATE","CAPITAL",x.id);return x;});res.status(201).json(m);});

app.patch("/api/capital/:id", auth, (req,res)=>{
  const {type,amount,currency,description,date}=req.body||{};
  const n=Number(amount);
  if(!["IN","OUT"].includes(type)||!Number.isFinite(n)||n<=0){
    return res.status(400).json({message:"بيانات حركة رأس المال غير صحيحة"});
  }
  const updated=mutate(store=>{
    const item=store.capitalMovements.find(entry=>entry.id===req.params.id);
    if(!item)return null;
    item.type=type;
    item.amount=+n.toFixed(2);
    item.currency=String(currency||"CAD").toUpperCase();
    item.description=String(description||"");
    item.date=date||new Date().toISOString().slice(0,10);
    item.updatedAt=now();
    item.updatedBy=req.user.id;
    audit(store,req.user.id,"UPDATE","CAPITAL",item.id,{type:item.type,amount:item.amount});
    return item;
  });
  if(!updated)return res.status(404).json({message:"حركة رأس المال غير موجودة"});
  res.json(updated);
});

app.delete("/api/capital/:id", auth, (req,res)=>{
  const removed=mutate(store=>{
    const index=store.capitalMovements.findIndex(entry=>entry.id===req.params.id);
    if(index<0)return null;
    const [item]=store.capitalMovements.splice(index,1);
    audit(store,req.user.id,"DELETE","CAPITAL",item.id,{type:item.type,amount:item.amount});
    return item;
  });
  if(!removed)return res.status(404).json({message:"حركة رأس المال غير موجودة"});
  res.json({message:"تم حذف حركة رأس المال",id:removed.id});
});

const publicDir = path.resolve(__dirname, "../public");
const indexFile = path.join(publicDir, "index.html");

if (!fs.existsSync(indexFile)) {
  console.error("Frontend files are missing. Run: npm run render-build");
}


const BACKUP_ARRAYS=["customers","transactions","payments","expenses","capitalMovements","exchangeRates","generalDebts","generalDebtPayments","partners","partnerTransactions","partnerPayments","notificationActions"];

app.get("/api/backup", auth, (req,res)=>{
  const store=readStore();
  const company=(store.companies||[]).find(item=>item.id===req.user.companyId);
  const data={};
  for(const key of BACKUP_ARRAYS)data[key]=Array.from(store[key]||[]).map(item=>({...item}));
  data.notificationSettings={...(store.notificationSettings||{})};
  const payload={
    format:"ALABOUD_BACKUP",
    version:"16.0.18",
    createdAt:now(),
    company:{id:req.user.companyId,name:company?.name||""},
    data
  };
  const filename=`alaboud-backup-${new Date().toISOString().replace(/[:.]/g,"-")}.json`;
  res.setHeader("Content-Type","application/json; charset=utf-8");
  res.setHeader("Content-Disposition",`attachment; filename="${filename}"`);
  res.send(JSON.stringify(payload,null,2));
});

app.get("/api/security/status", auth, (req,res)=>{
  if(req.user.role!=="ADMIN")return res.status(403).json({message:"متاح للمدير فقط"});
  const store=readStore(); const logs=store.auditLogs||[]; let chainValid=true,prev="GENESIS";
  for(const item of logs){const copy={...item};delete copy.integrityHash;if(item.previousHash!==prev||sha256(JSON.stringify(copy))!==item.integrityHash){chainValid=false;break;}prev=item.integrityHash;}
  res.json({version:"18.0.0",passwordHashing:"scrypt",sessionHours:12,httpsRequired:IS_PROD,auditIntegrity:chainValid,activeDevices:(store.devices||[]).filter(x=>x.active!==false).length,failedLogins24h:logs.filter(x=>x.action==="LOGIN_FAILED"&&Date.now()-new Date(x.createdAt).getTime()<86400000).length,securityScore:[IS_PROD,JWT_SECRET!=="LOCAL_TRIAL_CHANGE_ME_6_0",chainValid].filter(Boolean).length===3?95:78});
});

app.post("/api/backup/encrypted", auth, rateLimit("backup",10,60*60*1000),(req,res)=>{
  if(req.user.role!=="ADMIN")return res.status(403).json({message:"متاح للمدير فقط"}); const password=String(req.body?.password||""); const policy=passwordPolicy(password); if(!policy.ok)return res.status(400).json({message:policy.message});
  const store=readStore(),data={};for(const key of BACKUP_ARRAYS)data[key]=Array.from(store[key]||[]).map(item=>({...item})); const payload={format:"ALABOUD_BACKUP",version:"18.0.0",createdAt:now(),companyId:req.user.companyId,data}; const encrypted=encryptJson(payload,password);
  mutate(root=>audit(root,req.user.id,"EXPORT_ENCRYPTED","BACKUP",id(),{ip:req.ip})); res.setHeader("Content-Disposition",`attachment; filename="alaboud-secure-backup-${Date.now()}.abs"`);res.json(encrypted);
});

app.post("/api/backup/restore", auth, (req,res)=>{
  try{
    const payload=req.body||{};
    if(payload.format!=="ALABOUD_BACKUP"||!payload.data||typeof payload.data!=="object"){
      return res.status(400).json({message:"ملف النسخة الاحتياطية غير صالح"});
    }
    mutate(store=>{
      for(const key of BACKUP_ARRAYS){
        const existing=Array.from(store[key]||[]);
        for(const item of existing)item.companyId=`RESTORED_OLD_${req.user.companyId}`;
        const rows=Array.isArray(payload.data[key])?payload.data[key]:[];
        for(const row of rows){
          const clean={...row};delete clean.companyId;
          store[key].push(clean);
        }
      }
      if(payload.data.notificationSettings&&typeof payload.data.notificationSettings==="object"){
        store.notificationSettings={...payload.data.notificationSettings};
      }
      audit(store,req.user.id,"RESTORE","BACKUP",id(),{sourceVersion:payload.version||"unknown",createdAt:payload.createdAt||null});
    });
    res.json({message:"تمت استعادة النسخة الاحتياطية بنجاح"});
  }catch(error){
    res.status(400).json({message:error.message||"تعذر استعادة النسخة الاحتياطية"});
  }
});

app.use(express.static(publicDir, {
  index: "index.html",
  maxAge: 0,
  etag: true,
  setHeaders(res, filePath){
    if(filePath.endsWith("index.html")){
      res.setHeader("Cache-Control","no-store, no-cache, must-revalidate, proxy-revalidate");
      res.setHeader("Pragma","no-cache");
      res.setHeader("Expires","0");
    }else{
      res.setHeader("Cache-Control","no-cache");
    }
  }
}));

app.get("/", (_req, res) => {
  if (!fs.existsSync(indexFile)) {
    return res.status(503).send("Frontend build is missing");
  }
  res.sendFile(indexFile);
});

app.use((req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  if (!fs.existsSync(indexFile)) return res.status(404).send("Not Found");
  res.setHeader("Cache-Control","no-store, no-cache, must-revalidate");
  return res.sendFile(indexFile);
});

app.use((req,res)=>{
  res.status(404).json({message:"API route not found"});
});

app.use((err,_req,res,_next)=>{
  console.error(err);
  res.status(400).json({message:err.message||"Request failed"});
});

async function startServer(){
  await initStore();
  seedAdmin();
  app.listen(PORT,"0.0.0.0",()=>{
  console.log(`AlAboud Enterprise Cloud v17.0.1 running on port ${PORT}`);
  console.log(`Frontend directory: ${publicDir}`);

  const runHourlyRateRefresh=async()=>{
    try{
      const results=await refreshAutomaticRates("SYSTEM_HOURLY");
      const successCount=results.filter(item=>item.ok).length;
      console.log(`Hourly exchange-rate refresh: ${successCount}/${results.length} updated`);
    }catch(error){
      console.error("Hourly exchange-rate refresh failed:",error.message);
    }
  };

  setTimeout(runHourlyRateRefresh,60*1000);
  setInterval(runHourlyRateRefresh,60*60*1000);
  });
}
startServer().catch(error=>{
  console.error("Server startup failed:",error);
  process.exit(1);
});
