# ALABOUD Android v13.1 Enterprise Professional

- يعرض نظام الويب v13.1 داخل WebView.
- تحديثات الواجهة والصفحات تظهر تلقائيًا بعد نشر الويب.
- رقم الإصدار 13.1.0.
- GitHub Actions جاهز لبناء Debug APK.
