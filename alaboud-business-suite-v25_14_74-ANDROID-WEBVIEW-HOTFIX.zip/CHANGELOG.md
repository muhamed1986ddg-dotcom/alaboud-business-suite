## Android v25.14.74 — WebView Startup Hotfix

- إصلاح الشاشة الداكنة الفارغة في APK v25.14.73 الناتجة عن قراءة `webView.url` من خيط JavaScript Bridge الخلفي أثناء أول رسم لصفحة الدخول.
- نقل حالة ثقة الأصل إلى قيمة `@Volatile` تُحدّث من callbacks الخاصة بـWebView على خيط الواجهة، مع بقاء المطابقة التامة لمضيف Cloud Run وفصل الجسر عند أي انتقال غير موثوق.
- إضافة اختبار انحدار خاص بسلامة خيط WebView. هذا تحديث Android فقط؛ Web/Backend يبقيان على v25.14.73.

## v25.14.73 — Security & Session Reliability

- قصر Android WebView على أصل Cloud Run الرسمي بمطابقة تامة، وإزالة تمرير رمز البصمة طويل الأمد إلى JavaScript.
- تنفيذ تسجيل الدخول بالبصمة داخل طبقة Android الأصلية وربط الجهاز بالرمز؛ صفحات الويب غير الموثوقة لا تملك الجسر الأصلي.
- إصلاح نطاق `users` و`branches` و`sessions` ليكون على مستوى الشركة، مع إبقاء البيانات المالية على مستوى الفرع.
- جعل تسجيل الخروج وتغيير/إعادة تعيين كلمة المرور وتعطيل المستخدم يبطل الجلسات ورموز البصمة فعليًا.
- منع كلمة مرور المدير الافتراضية في الإنتاج، وفرض تغييرها عند إنشاء الحساب الأول، وإغلاق التسجيل العام افتراضيًا في الإنتاج.
- حظر SSRF في موصلات الشركات: فحص DNS لكل طلب وتحويل، حظر العناوين الخاصة، تثبيت الاتصال على العنوان المتحقق منه، والتحقق الصارم من TLS.
- رفع `nodemailer` وVite وسلسلة البناء إلى إصدارات مصححة؛ `npm audit` للخلفية والواجهة: صفر ثغرات.
- إصلاح مسارات CI واختبارات E2E/الواجهة، وإضافة بوابة إصدار واحدة عبر `npm test`.
- حذف 44 نسخة توثيق متطابقة من الجذر و13 نسخة إضافية من `docs/` و7 ملفات `selftest_v8*` و43 ملف اختبار أرشيفي ميت ومسارات نشر Render القديمة.
- دمج ملفات تشغيل Windows المكررة والمكسورة في نسختين صحيحتين داخل الجذر، وإضافة تقرير الفحص الشامل وخطة النجاح.
- لا تغيير في معادلات الأعمال المالية ولا مخطط قاعدة البيانات.

## 25.14.60
- عزل تحديثات telemetry (integration logs / API-key usage) عن app_state write-behind لمنع تعارض optimistic revision أثناء مزامنة جاد.
- إضافة JAD revision-isolation regression guard.
- استبعاد data/ من Docker build context.

# v25.14.60 — Startup Runtime Guard
- Fixed the Git-source startup regression where `apiKeyMiddleware` referenced `mutate` without importing it.
- Added a hard Docker build guard that fails before image publication if `mutate` is missing from the `./store` import.

- Fixed Cloud Run startup crash caused by `mutate` being omitted from the store import while API-key middleware and integration logging still required it.
- Preserved v25.14.57 idempotency-scope and optimistic-revision protections.
- Added a runtime startup regression test that launches the real server and fails CI if the process crashes before listening.
- No financial formulas, JAD parsing, customer balances, or database data were changed.

## v25.14.57

- Tenant-scoped durable idempotency receipts; database replay now happens only after authentication.
- Explicit `scope_key` persistence and migration for `operation_receipts`.
- Optimistic `app_state.revision` guard prevents stale full-state snapshots from overwriting a newer commit.
- Ambiguous-commit verification and operation status are tenant-scoped.
- CI build now gates the main financial/session/JAD/SMS regression tests in addition to pool/write reliability checks.
- No financial formulas, customer balances, or JAD parsing logic changed.

## v25.14.56

- Fixed PostgreSQL operation receipt UPSERT to match the live composite unique constraint `(scope_key, operation_key, method, path)`.
- No database data migration or destructive schema change.

## v25.14.55

- إصلاح قارئ أرصدة شركة جاد فقط بدون تغيير موصلات بقية الشركات.
- قراءة النص المرئي الفعلي من لوحة جاد بدل HTML المخفي الذي قد يحتوي بطاقات مكررة أو أرصدة قديمة.
- إضافة دعم ILS/الشيكل وتوسيع قائمة العملات الشائعة مع الحفاظ على USD وEUR وTRY وبقية العملات.
- تفضيل اسم العملة الأكثر تحديدًا عند تشابه الأسماء، لمنع خلط «دولار أسترالي» مع «دولار» الأمريكي.
- لا تغييرات على قاعدة البيانات أو الحسابات المالية أو موصلات تواصل/دهب/سوريانا.

## v25.14.54
- Fixed Rasel Syria local SMS integration to use the account-documented `/api/v2/messages/send` contract.
- Sends verification messages with `channel: local_sms`, `messageType: free_text`, and `content.text`.
- Keeps `X-API-Key` authentication and does not use WhatsApp `sessionName`.
- Added regression coverage for the Rasel local SMS v2 contract and synchronized runtime/client version to 25.14.54.

## v25.14.54
- Corrected runtime APP_VERSION and all release-version surfaces so /api/health reports the deployed release accurately.
- Preserved Write Reliability Guard and Secure HttpOnly Sessions.
- Preserved Rasel SMS v1 API contract.
- Added runtime-version regression guard.

## v25.14.51
- Added mandatory idempotency keys to sensitive financial writes after authentication.
- Added CI pool-leak, timeout-recovery, duplicate-write, and durable-write serialization checks.
- No financial formula or database schema changes.

## v25.14.50
- نقل جلسة الويب إلى HttpOnly + Secure + SameSite cookie مع توافق انتقالي للجلسات القديمة.
- إزالة تخزين JWT الجديد في localStorage، مع ترقية تلقائية للجلسات القديمة عند أول طلب ناجح.
- إضافة حماية Origin/installation-header لطلبات الكتابة المعتمدة على الكوكي للحد من CSRF.
- تسجيل الخروج أصبح يبطل جلسة الخادم ويحذف كوكي الجلسة.
- Android WebView يستخدم كوكي الجلسة لطلبات التنبيه بدل قراءة JWT من localStorage.

## v25.14.49

- ربط `assertBalancedEntry` بمسارات الحوالات ودفعات العملاء والديون والمصروفات ورأس المال كحارس توازن قبل الكتابة.
- إضافة تحقق فعلي من أن دفعة العميل موزعة بالكامل بين الحوالات والحساب القديم.
- تشديد `FinancialIntegrity` لرفض القيم السالبة وغير الرقمية والسطر المدين/الدائن في الوقت نفسه.
- لا تغيير على معادلات الأعمال أو بيانات قاعدة البيانات.

## v25.14.48
- Added a repository-wide `.gitignore` safety policy for secrets, credentials, local databases, backups, exports and generated artifacts.
- Expanded sensitive-file detection and added `npm run check:sensitive`.
- Normal production builds now run the sensitive-file check before frontend bundling.
- No financial or database calculation logic changed in this release.

## v25.14.47
- إصلاح خصم دفعات العميل بعد تصفير الحساب: الدفعة الجديدة لا تُوزع على حوالات مؤرشفة قبل التصفير.
- احتساب دفعات نفس يوم التصفير بالاعتماد على وقت الإنشاء الفعلي (`date`) حتى تظهر في المدفوع وتخفض الرصيد النهائي.
- إضافة اختبار انحدار لسيناريو 9100 - 4000 = 5100.

## v25.14.47
- إصلاح الحساب القديم الذي يُضاف بعد تصفير حساب العميل؛ أصبح يدخل في الحساب الجديد ويظهر في الصفحات والحسابات المرتبطة دون إعادة الحركات المؤرشفة.

## v25.14.45
- إصلاح تحديث الحساب القديم فورًا بعد الحفظ ومنع عرض نسخة مخبأة قديمة.
- مسح ذاكرة GET المؤقتة بعد إضافة/تعديل/حذف/تصفير العميل حتى تتحدث العملاء والدين والميزانية والجرد عند إعادة تحميلها.
- تحديث بيانات العميل محليًا مباشرة من استجابة PATCH قبل إعادة الجلب.

## v25.14.44

- إظهار الحساب القديم (له/عليه) مباشرة في قائمة العملاء مع الرصيد النهائي واتجاهه.
- تحديث بيانات العميل فور حفظ الحساب القديم بدون انتظار إعادة فتح الصفحة.
- تصحيح إضافة الحساب القديم إلى رسالة كشف الحساب عبر واتساب مع احترام اتجاه له/عليه.
- توحيد لوحة التحكم لتفصل ديون العملاء لنا عن ديون العملاء علينا بدل جمع الرصيد السالب داخل المستحقات.
- تصحيح حساب الرصيد في مسار PostgreSQL الأصلي بحيث يكون الحساب القديم «له» سالبًا و«عليه» موجبًا.
- الإبقاء على محرك FinancialEngine كمصدر موحد للميزانية والجرد الشهري والدين العام وكشوف العملاء.

## v25.14.43
- Show settings action success/error messages inside the active modal, including password change confirmation on mobile.

## v25.14.42 - Password change hash compatibility fix

- إصلاح تغيير كلمة المرور للحسابات التي تستخدم scrypt بدل bcrypt.
- توحيد التحقق من كلمة المرور الحالية مع منطق المصادقة الموجود في النظام.
- الحفاظ على رسالة نجاح واضحة عند اكتمال تغيير كلمة المرور.

## v25.14.41
- إصلاح ظهور لوحة تغيير كلمة السر داخل نافذة الإعدادات على الهاتف.
- ضمان ظهور حقول كلمة المرور الحالية والجديدة والتأكيد وزر الحفظ.

## v25.14.40 — Account Verification Confirm Fix

- Keep an active OTP challenge when verification contact data is saved without changing the target.
- Invalidate only challenges whose email/phone destination actually changed.
- Show verification success/error feedback directly beside the OTP controls.

## v25.14.40 — Rasel SMS Verification
- Added Rasel SMS provider for account verification using RASEL_API_KEY.
- Kept WhatsApp on Twilio and email on SMTP.
- Updated account verification provider status and settings guidance.


## v25.14.37 — Budget & Inventory Reference Fix
- Fixed `customerBalanceTotals is not defined` in capital overview and monthly inventory APIs.
- Restored budget and monthly inventory pages while preserving v25.14.35 customer receivable/payable classification.
- Added regression coverage for the FinancialEngine binding.

## v25.14.35 — Customer receivable/payable classification

- Fixed customer balances in capital calculations so positive customer balances are gross receivables and negative balances are gross payables.
- Customer old account marked "له" now appears explicitly under debt/payables and reduces net capital through liabilities, not by making receivables negative.
- Customer old account marked "عليه" remains an explicit receivable.
- Kept net capital mathematically unchanged while making Debt For Us / Debt On Us / budget / monthly inventory classifications consistent.
- Added explicit customer/company payable breakdown in the Debt On Us view and aligned the capital liquidity ratio with gross Debt For Us / Debt On Us totals.
- Added regression coverage for customer receivable/payable split.

## v25.14.34 — Settings layout + customer old account direction
- Fixed the settings header/version overflow on mobile.
- Added customer old-account direction: عليه (receivable) or له (payable).
- Customer statements now show whether the old account and final balance are له or عليه.
- Old-account payable values enter general debt as PAYABLE instead of receivable.

# v25.14.33

- نقل اختيار الفرع النشط من القائمة الجانبية إلى صفحة الإعدادات > إدارة الفروع.
- عرض الفرع النشط داخل بطاقة واضحة مع إمكانية تغييره مباشرة من الإعدادات.
- تمييز بطاقة الفرع النشط بصريًا وإزالة مبدّل الفرع من القائمة الرئيسية لتقليل ازدحام الهاتف.

# v25.14.31

- Keep authenticated sessions for up to 30 days (instead of 12 hours / 30-minute idle timeout).
- Persist session registry in the application state so remembered sessions survive state replacement/restarts.
- Android now points to the Google Cloud Run production service.
- Android biometric/face/device-credential login is offered after the first successful password + 2FA login and auto-prompts on later launches when enabled.
- Biometric device token lifetime increased to 90 days; passwords are never stored for biometric login.

# v25.14.30

- Fixed PAID transfer creation sending a duplicate payment request after the backend had already recorded the initial full payment.
- Prevents `Payment exceeds remaining balance` and the misleading internal-server-error toast after a successful transfer creation.
- Transaction payment endpoint now returns 400/404 for business-rule errors instead of surfacing them as generic 500 errors.
- Health/readiness version synchronized to 25.14.30.

# v25.14.29

- Fixed PostgreSQL PoolClient leak caused by a missing `isConnectionError()` helper in release paths.
- Added regression coverage for successful client release and broken-client destruction.
- Added Arabic root-cause and deployment verification notes.

## v25.14.28 — Isolated Durable Writes
- عزل اتصالات إضافة/تعديل/حذف في PostgreSQL write pool مستقل عن health والتقارير والتحديثات الخلفية.
- إيقاف relational mirror افتراضيًا لتقليل الضغط على PostgreSQL؛ يمكن تفعيله صراحةً عبر RELATIONAL_MIRROR_ENABLED=true.
- إعادة إنشاء write pool وحده عند 57P03/انقطاع الاتصال بدل التأثير على بقية الاتصالات.
- منع أخطاء pool قديم من إعادة تدوير pool جديد بعد الاستعادة.
- تأكيد ambiguous COMMIT من نفس write pool المعزول قبل إعادة العملية.

## v25.14.27 — Write Path Stability

- فصل /health بالكامل عن قرارات إعادة إنشاء PostgreSQL Pool.
- health لم يعد يستطيع قطع Pool أثناء إضافة/تعديل/حذف.
- تقليل probing إلى مرة كل 15 ثانية، وعدم probing عند وجود طلبات تنتظر Pool.
- إزالة write-readiness gate المعتمدة على connectionState القديمة.
- عملية الحفظ نفسها (acquire/BEGIN/COMMIT) أصبحت المصدر الوحيد لتقرير جاهزية الكتابة.
- لا تغيير في الحسابات المالية أو البيانات.

## v25.14.26 — Reliable Soft Delete

- تحويل حذف الحوالة من HTTP DELETE إلى PATCH soft-delete في الواجهة.
- استخدام نفس مسار PATCH المتين الذي ثبت نجاح التعديل عليه في الإنتاج.
- الحذف ما زال منطقيًا: isDeleted=true مع حذف دفعات الحوالة منطقيًا وحفظ Audit Trail.
- إبقاء DELETE القديم في الخادم للتوافق مع الإصدارات القديمة فقط.
- لا تغيير في الحسابات المالية أو بيانات الحوالات الأخرى.

## v25.14.25 — PostgreSQL Pool Leak Fix

- إصلاح جذري لتسريب PoolClient عند انتهاء مهلة pool.connect قبل وصول الاتصال.
- الاتصال الذي يصل متأخرًا يتم release(true) فورًا ولا يبقى محجوزًا في Pool.
- عدم إعادة إنشاء PostgreSQL Pool بسبب مهلة انتظار محلية فقط.
- رفع مهلة handshake الداخلية إلى 12 ثانية مع إبقاء عملية المستخدم محدودة إلى 6 ثوانٍ.
- هذا الإصلاح يستهدف مباشرة استقرار الحفظ والإضافة والتعديل والحذف.

## v25.14.24 — Unified Version Source

- توحيد رقم الإصدار الظاهر في الواجهة مع إصدار الـAPI والـBackend وملفات package وAndroid.
- إصلاح بقاء الواجهة على v25.14.20 بعد رفع الإصدارات الأحدث.
- لا تغييرات على البيانات أو الحسابات المالية.

## v25.14.20 — PostgreSQL Watchdog Recovery
- إضافة watchdog حقيقي لاتصالات PostgreSQL: إذا تجاوز الاستعلام المهلة يتم قطع socket نفسه، وليس فقط إنهاء Promise الواجهة.
- وضع مهلة مستقلة لاكتساب PoolClient حتى لا يبقى طلب transactions في حالة Pending أثناء تعافي قاعدة البيانات.
- إعادة بناء queryWithRetry على عميل مخصص يتم التخلص منه فور أي خطأ اتصال.
- جعل recovery probes وhealth probes محدودة زمنيًا وقابلة لتدمير الاتصال العالق.
- جعل /api/health يعرض حالة الاتصال فورًا دون انتظار استعلام PostgreSQL متعطل.
- حماية المرآة العلائقية بمهلات BEGIN/Projection/COMMIT حتى لا تحتجز اتصالًا وتؤخر العمليات المالية.
- الإبقاء على COMMIT المتين وIdempotency receipts ومنع تكرار الإضافة أو التعديل أو الحذف.

# v25.14.19 — Database Write Readiness Gate

- منع بدء عمليات الإضافة/التعديل/الحذف أثناء حالة PostgreSQL reconnecting إلا بعد جاهزية محددة المهلة.
- إضافة hard deadline على خطوات المعاملة بما فيها COMMIT.
- منع ROLLBACK المعلق على socket مكسور؛ يتم التخلص من العميل المعطوب بدلًا من إبقاء HTTP Pending.
- خفض مهلة الكتابة وإعادة المحاولة في الواجهة إلى 15 ثانية مع نفس Idempotency-Key.
- الحفاظ على durable commit وoperation receipts ومنع التكرار.

# v25.14.18 — Transaction Write Timeout Recovery

- Bound PostgreSQL pool acquisition for interactive operations so PATCH/DELETE cannot remain pending indefinitely.
- Added server-side `lock_timeout`, `statement_timeout`, and idle transaction timeout for durable financial writes.
- Added client-side query timeout for BEGIN/write/COMMIT while preserving durable COMMIT semantics.
- Classified PostgreSQL lock/statement timeouts as retryable transient failures.
- Made idempotency receipt preflight fail open quickly instead of entering the general long database recovery loop before every write.
- Bounded `/api/operations/:key/status` receipt checks used after ambiguous write failures.
- Kept the same Idempotency-Key replay and durable receipt verification to prevent duplicate edits/deletes.

# v25.14.17 — PostgreSQL Edit/Delete Recovery

- أصلح إعادة اتصال PostgreSQL بعد فشل التعديل أو الحذف: أي client يفشل أثناء المعاملة يُزال من الـ pool بدل إعادته كاتصال سليم.
- منع إعادة إنشاء الـ pool من event الخاص بعميل checked-out حتى لا يتسابق مع معاملة مالية أخرى نشطة.
- إضافة تحقق durable من `operation_receipts` بعد انقطاع الاتصال أثناء COMMIT؛ إذا كان التعديل/الحذف قد ثبت بالفعل، يُعامل كنجاح ولا يعاد تنفيذه.
- مسارا تعديل وحذف الحوالات يعيدان الآن 503 retryable برسالة تشغيلية واضحة عند انقطاع PostgreSQL بدل 400/500 برسالة `Connection terminated unexpectedly`.
- لا تغيير في قواعد الحسابات المالية أو آلية soft-delete أو Idempotency.

# v25.14.16 — Edit/Delete Reliability

- Safe same-key replay for ambiguous update/delete writes.
- Removed redundant post-COMMIT delete verification that could return false 500 errors.
- Preserved durable PostgreSQL COMMIT and idempotency guarantees.

# v25.14.15 — Automatic Customer Recovery

- قائمة العملاء تعيد المحاولة تلقائيًا أثناء استعادة PostgreSQL بدل مطالبة المستخدم بالمحاولة يدويًا.
- الاحتفاظ بآخر قائمة عملاء ناجحة في sessionStorage وعرضها مؤقتًا عند انقطاع قاعدة البيانات.
- إعادة تحديث القائمة فور عودة health إلى حالة connected.
- قائمة اختيار العميل تستخدم نفس الاستعادة الهادئة لتقليل النماذج الفارغة.
- أخطاء PostgreSQL المؤقتة في مسار العملاء تُعاد كـ 503 retryable بدل خطأ 500 عام.

# v25.14.14 — Low-Latency Durable Operations

- Reduced PostgreSQL round trips for durable add/edit/delete operations by combining the advisory lock, app-state upsert, and idempotency receipt in one SQL statement.
- Preserved synchronous COMMIT confirmation and persistent idempotency.
- Bounded interactive PostgreSQL recovery so a temporary outage no longer leaves operation buttons waiting for up to a minute.
- Frontend begins ambiguous-commit verification after 25 seconds instead of waiting 95 seconds.
- Relational mirror remains asynchronous and does not block interactive saves.

# v25.14.14 — Fast Interactive Operations

- Interactive list/detail reads now prefer the already-committed in-memory tenant state instead of waiting for the asynchronous relational mirror. Set `NATIVE_INTERACTIVE_READS=true` only when native mirror reads are explicitly required.
- PostgreSQL pool keeps one warm connection by default (`PG_POOL_MIN=1`) and extends idle retention to 15 minutes to avoid repeated TLS/database handshakes before writes.
- Relational mirror projections are coalesced for 1.5 seconds (`RELATIONAL_MIRROR_DELAY_MS`) so bursts of add/edit/delete operations do not compete with a full mirror projection.
- Fixed duplicate connection-failure counter increment.
- Financial writes remain synchronous and are only acknowledged after PostgreSQL COMMIT; idempotency and commit confirmation remain unchanged.

# v25.14.13 — Fast Durable Operations

- سرّع مسار الإضافة والتعديل والحذف مع الحفاظ على تأكيد PostgreSQL قبل إظهار النجاح.
- أزال النسخ المتكرر الكامل لحالة البرنامج في كل عملية مالية، وأصبح التعديل يتم على Draft خاص واحد ثم يُعتمد بعد COMMIT.
- أوقف النسخ المتزامن الإضافي قبل تحديث المرآة العلائقية عندما تكون لقطة الحفظ غير قابلة للتغيير.
- جعل تحديث القوائم بعد نجاح الإضافة/التعديل/الحذف يعمل في الخلفية في الشاشات الأساسية بدل إبقاء الزر والنافذة منتظرين طلبات GET إضافية.
- لم يتم تحويل العمليات المالية إلى write-behind؛ سلامة الحفظ وIdempotency ما زالت كما هي.

# v25.14.12 — Dark Capital Turnover Card

- Replaced the bright white capital turnover panel with the app dark navy theme.
- Gold heading, light readable explanatory text, and green highlighted turnover value.
- Improved mobile readability without changing financial calculations.

# v25.14.11 — Capital Transfer-Style Mobile Cards

- Rebuilt mobile capital history using the same card pattern as the transfers page.
- Prevented horizontal overflow and cropped values inside the capital modal.
- Added clear two-column field rows for date, type, original amount, currency, exchange rate, CAD value, and description.
- Kept edit/delete actions inside each mobile card.
- Preserved the additions total card and desktop table.

# v25.14.10 — Mobile Capital History & Additions Total

- إصلاح سجل رأس المال على الهاتف وتحويل كل حركة إلى بطاقة عمودية متجاوبة.
- إضافة زر واضح باسم «مجموع الإضافات» لعرض إجمالي رأس المال المضاف فقط.
- منع القص والتمرير الأفقي داخل سجل رأس المال على الشاشات الصغيرة.
- إبقاء تصميم الجدول على الكمبيوتر دون تغيير.

# v25.14.9 — Capital Added Total

- Added a **المجموع النهائي** button to the capital movement history.
- The button reveals the total of all capital additions in CAD across the complete capital ledger.
- Withdrawals are not included in this figure.
- Deleted/soft-deleted movements are excluded when present.
- The total updates after add, edit, and delete because it is derived from the freshly loaded ledger.

# v25.14.8 — Simple Monthly Inventory

- تبسيط الجرد الشهري ليعتمد على **صافي رأس المال** بنفس معادلة صفحة الميزانية.
- الكاش الموجود في الخزنة يُدخل يدويًا فقط.
- قيمة الجرد النهائية = صافي رأس المال + كاش الخزنة.
- تثبيت لقطة الجرد الشهرية والأرشيف والتنبيه في اليوم المحدد بقيت كما هي.
- تبسيط أرشيف الجرد ليعرض صافي رأس المال، كاش الخزنة، والقيمة النهائية.

# v25.14.7 — Inventory Debt & Profit Integrity

- Fixed monthly inventory "debts payable" so it includes local company payables, external partner payables, and remaining manual payable debts using the same source semantics as the debt page.
- Added current-month net profit to the inventory screen and monthly snapshot for reconciliation.
- Profit is informational only and is not added to the final inventory value to avoid double counting.
- Added payable breakdown fields for audit and troubleshooting.

# v25.14.6 — Monthly Inventory & Reminder

- إضافة زر/تبويب **الجرد الشهري** داخل صفحة التقارير والأرباح.
- معادلة الجرد: إجمالي النقد + أرصدة الشركات + ديون العملاء لنا + ديون الشركات لنا - الديون علينا + الكاش في الخزنة.
- الكاش في الخزنة يُدخل يدويًا فقط وقت تثبيت الجرد.
- حفظ Snapshot ثابت لكل شهر مع التاريخ، المستخدم، الملاحظات، وقيمة كل بند.
- منع إنشاء جردين لنفس الشهر.
- أرشيف شهري مع الفرق عن الشهر السابق.
- تحديد يوم الجرد من 1 إلى 28، افتراضيًا يوم 20.
- تنبيه قبل الجرد بيوم، في يوم الجرد، وبعد التأخير حتى يتم التثبيت.
- تنبيه عام داخل البرنامج يفتح صفحة الجرد مباشرة.
- تضمين سجلات الجرد ضمن النسخ الاحتياطية وعزلها حسب الشركة/الفرع.

# Changelog

## v25.14.4 — Commit Confirmation & Idempotency

- Added durable PostgreSQL `operation_receipts` committed atomically with `app_state`.
- Added operation-status verification endpoint for ambiguous client outcomes.
- Frontend now verifies timeout/database-disconnect writes before showing failure.
- Reusing a committed `Idempotency-Key` replays the committed result instead of duplicating the mutation.
- Pending operations are no longer forgotten merely because the client socket closes.

## v25.14.3 — Database Recovery Guard

- Added one shared PostgreSQL recovery gate with readiness probes (`SELECT 1`).
- Extended the durable-write recovery budget for Render PostgreSQL startup windows.
- Prevented repeated pool recreation storms while PostgreSQL is still recovering.
- Sanitized PostgreSQL technical messages across API toasts and database-status banners.
- Kept financial writes synchronous: no success is returned before PostgreSQL `COMMIT`.
- Increased client write timeout to match the backend recovery budget and preserve the same idempotency key.

# CHANGELOG

## v25.14.3 — Deterministic Financial Math

- ربط `Money.js` فعليًا بحسابات الحوالات والعملاء بدل بقائه معزولًا في الاختبارات.
- تحويل حساب قيمة الحوالة، المستحق، ربح فرق السعر، الأجور وإجمالي الربح إلى Fixed-point باستخدام BigInt.
- تحويل تجميع حوالات العملاء والدفعات والديون إلى جمع عشري حتمي.
- اعتماد ROUND_HALF_UP في جميع العمليات الجديدة.
- إضافة اختبار تكامل يمنع العودة إلى الحسابات العائمة في المسارات المالية الرئيسية.

## v25.14.1 — Customer Quick Transfer
- إضافة زر «إضافة حوالة للعميل» داخل ملف العميل.
- تعبئة العميل تلقائيًا وقفل الاختيار مع إمكانية تغييره يدويًا.
- العودة إلى ملف العميل وتحديث رصيده وسجل حوالاته بعد الحفظ.
- تحسين ترتيب أزرار ملف العميل على الهاتف.


## v25.14.0 — Financial Transaction Integrity
- Synchronous PostgreSQL transaction commit for durable financial snapshots.
- Cross-instance advisory lock and row-level `FOR UPDATE` lock.
- Atomic state revision counter.
- Standardized soft-delete audit metadata and delete reasons.
- Deterministic decimal arithmetic and balanced-entry validation utilities.
- Added financial integrity and transaction policy tests.

# v25.10.0 — Architecture and Financial Integrity

- Confirmed durable writes with rollback on persistence failure.
- Centralized customer financial calculations.
- PostgreSQL sorting for every customer sort mode.
- Immediate local customer insertion with silent server reconciliation.
- Extracted health routes and customer UI components.
- Added end-to-end financial workflow coverage.
- Archived release notes and removed redundant project files.

# v25.8.2 — Global Button Cleanup

- Removed the duplicated global quick-action strip from Dashboard.
- Kept creation actions in their owning pages.
- Removed dead CSS tied to the deleted shortcut strip.
- Added an automated responsibility check for the primary customer and transfer pages.

# v25.8.1 — UI Responsibility Cleanup

- Removed duplicated create-transfer and payment actions from the transfers page.
- Removed duplicate overdue, profit, and unpaid-total controls from the transfers page.
- Transfers page now focuses on viewing, filtering, editing, deleting, exporting, and paid/unpaid status.
- Removed the full-payment shortcut from transfer rows; payments remain centralized in Customers.
- Removed the unused add-transfer form and related exchange-rate request from the transfers bundle.

# v25.6.0

- Manual companies ledger and opening balances.
- Automatic CAD normalization for partner ledger entries.
- Manual/connected company modes.

## v25.5.2 — Compact Net Debt Summary

- Removed the per-currency debt cards from the general debt page.
- General debt now shows only headline balances and counts.
- Company balance in the receivable summary is now the final net balance after subtracting company payable debt.
- The lower total now equals customer debt plus final company balance.

## v25.5.1 — Simplified Debt Dashboard

- Simplified the General Debt page into a numbers-only financial dashboard.
- Removed customer/company names and detailed debt rows from the page display.
- Kept totals, currency summaries, counts, and hidden action modals.
- Receivable view now shows customer debt, final company balance, and grand total only.

## v25.5.0 — Automatic Financial Consistency

- توحيد التحويلات الحالية على آخر سعر صرف آلي ناجح.
- منع خلط أرصدة CAD مع USD داخل مجموع واحد.
- إضافة الرصيد النهائي لكل شركة بالدولار الكندي مع وقت آخر تحديث آلي.
- جعل ملخص الشركات الافتراضي بالدولار الكندي.
- تحسين اختيار أحدث سعر باستخدام effectiveAt/sourceDate/updatedAt/createdAt.
- إضافة فحوصات تمنع عودة الخلط بين العملات.

## v25.4.9 — Unified Debt Balance

- توحيد رصيد دين العملاء في صفحة العملاء وصفحة الدين العام باستخدام نفس دالة الحساب.
- منع احتساب الحوالات والحساب القديم مرتين داخل ملخص الدين العام.
- احتساب دين الشركات من أرصدة الشركاء فقط.
- جعل المجموع الكلي يساوي رصيد العملاء + رصيد الشركات بدقة.

## v25.4.8 — Receivable Balance Summary
- Kept the complete upper section of General Debts unchanged.
- Replaced the lower receivable list with three balances only: customers, companies, and total.
- Added a server-calculated CAD-normalized receivable breakdown.

## v25.4.7 — Customer Debt Total

- إضافة بطاقة واحدة واضحة تعرض إجمالي الدين الكامل المستحق على جميع العملاء بالدولار الكندي.
- الحساب يشمل جميع العملاء وليس الصفحة الحالية فقط.
- تحديث الإجمالي بعد الإضافة والتعديل والحذف والدفعات.

## v25.4.6 — Compact Mobile Exchange Rates

- Added compact mobile exchange-rate rows using the format `🇺🇸 1 USD = 1.40 🇨🇦 CAD`.
- Reduced mobile card height, spacing, controls, and summary clutter.
- Preserved the full desktop exchange-rate table.

# v25.3.5

- تحويل سجل الحوالات على الهاتف إلى بطاقات قصيرة حقيقية من صفوف مضغوطة.
- إخفاء الجدول الطويل على الهاتف مع إبقائه على الكمبيوتر.
- عدم تغيير الحسابات أو البيانات.

# v25.3.5
- Compact two-column transfer cards on mobile.
- Added visible labels and a single-row action area.
- Desktop ledger remains unchanged.

# v25.3.3

- Prevent false save-failure messages during PostgreSQL recovery by allowing durable write requests to wait for backend retry completion.
- Use a 180-second timeout for write requests and 30 seconds for reads.
- Add a safer timeout message that does not claim the operation definitely failed.
- Update client and Android version metadata.

# v25.3.2

- Guard checked-out PostgreSQL clients against unhandled error events.
- Recreate the pool safely after transient client disconnections.
- Protect migration, verification, and rollback clients.
- Avoid logging recoverable database disconnects as fatal uncaught exceptions.

# v25.3.1

- Added PostgreSQL recovery-mode resilience with exponential backoff and jitter.
- Increased durable write retries to eight by default.
- Recreates the PostgreSQL pool after transient connection failures.
- Treats 57P03/recovery errors as retryable and returns a clear Arabic 503 message without false save success.
- Added resilience classification and backoff tests.

# v25.3.0
- Complete test coverage for all 12 shared UI components.
- Remove the final unused `.rate-modal` and `.budget-modal` CSS wrappers.

# v25.2.1 — UI Cleanup & Test Foundation

- Removed retired modal CSS rules left after the shared UI migration.
- Removed LoadingButton and UnifiedModal compatibility wrappers.
- Updated confirmAction to use AppModal and AppButton directly.
- Added unit tests for AppModal, AppTable, AppButton and AppPagination.
- Added UI component tests to GitHub Actions and strengthened the UI quality gate.
- Preserved financial logic and database behavior.

# v25.1.0

- Expanded the shared UI component library with inputs, selects, badges, toolbars, loaders, empty states, pagination, and responsive tables.
- Migrated Reports & Profits to the shared design system.
- Migrated General Debts modals to AppModal and AppButton.
- Added mobile card rendering for AppTable and unified dark form styles.
- Preserved all accounting logic and database behavior.

# v25.0.0
- Added shared UI foundation components.
- Migrated Exchange Rates modals, buttons, cards and tables to the shared UI system.
- Added design tokens and centralized CSS entry point.
- Preserved legacy CSS temporarily for non-migrated screens.

# v24.2.4

- Completed API permission wiring for backups, restore, notification settings, reports, AI, developer, device and security routes.
- Added defense-in-depth authorization to backup and restore routes.
- Expanded access-control regression tests.
- Preserved global async route error capture and centralized error handling.

# v24.2.1

- Fixed overdue customer cards in the unified dark theme.
- Added high-contrast financial numbers and responsive card layout.
- Removed remaining bright metric surfaces on the overdue page.

## 24.2.0
- Unified the dark design system across all application pages.
- Removed unintended white surfaces from cards, tables, forms, modals, reports, settings, customer screens, payments, debts, budget, exchange rates and the AI command center.
- Added common color tokens, stronger text contrast, tabular financial numbers and consistent form/table/modal styling.
- Preserved a light print stylesheet for statements and reports.

# v24.0.7

- Treat customer old balance as an opening balance, never as a payment.
- Allocate customer payments to oldest transactions first, then to the opening balance.
- Store and display only the remaining opening balance after payment allocation.
- Exclude opening-balance reductions from total paid and payment history.
- Restore the deducted opening balance when deleting a grouped customer payment.
- Correct customer statement grand-total calculation.

# v24.0.6

- اعتماد تصميم سجل الحوالات الاحترافي على الكمبيوتر.
- إضافة العملة والمبلغ الأصلي وسعر الصرف والقيمة والعمولة والمجموع النهائي بـ CAD.
- إضافة الفلاتر والبحث والتصدير والترقيم.
- الإبقاء على واجهة الهاتف متجاوبة وعلى الحسابات الحالية دون تغيير.

# v24.0.5

- Split the monolithic App.jsx into lazy-loaded dashboard, customer, detail, and transaction modules.
- Removed duplicate login and unused compatibility screens.
- Optimized language DOM translation and deferred non-critical dashboard data.
- Unified application version to 24.0.5.

# سجل التغييرات (Changelog)

## v23.0.32 — Unified Modal System

- Added a shared modal component and standardized confirmation dialogs.
- Replaced browser confirm dialogs for destructive and sensitive operations.
- Added Escape/backdrop close behavior and mobile layout.
- Added a reusable loading button to prevent duplicate submissions.
- No database schema or customer-data changes.

## v23.0.20 - Production safety and release cleanup

- Removed bundled customer/store data and generated frontend assets from the source archive.
- Removed obsolete root server and legacy App backup files.
- Unified application, frontend, backend, and visible UI versions to 23.0.20.
- Disabled JSON storage fallback in production when DATABASE_URL is missing.
- Added PostgreSQL wiring and generated initial administrator password to Render Blueprint.
- Added frontend dev and preview commands and moved Vite tooling to devDependencies.
- Added expired rate-limit bucket cleanup.

> تم دمج جميع ملفات RELEASE_*.md المتفرقة (101 ملف) في هذا الملف الواحد، مرتبة من الأحدث إلى الأقدم.
> الملفات الأصلية منقولة إلى `docs/releases/` للأرشفة.

---

## COMPANIES UNIFIED PAGE REPORT

# تقرير توحيد صفحة الشركات — v23.0.25

تم إرجاع إدارة الشركات والربط الخارجي إلى صفحة واحدة رئيسية.

## ما تم الحفاظ عليه
- زر جلب الرصيد لكل شركة.
- حقل رمز Authenticator.
- فتح رابط الشركة.
- عرض سجل ربط جاد.
- الرصيد حسب العملة ووقت آخر مزامنة.
- فتح ملف الشركة وتعديلها وحذفها واختبار الاتصال.

## ما تم تغييره
- إزالة الصفحات المتكررة من القائمة الجانبية.
- إبقاء خيار واحد: الشركات والربط الخارجي.
- إضافة زر تحديث جميع الشركات.
- إعدادات الإضافة والتعديل قابلة للإظهار والإخفاء داخل الصفحة.
- سجل العمليات يعرض آخر 6 عمليات افتراضيًا ويمكن توسيعه إلى 100.
- الروابط القديمة للصفحات المنفصلة تفتح الصفحة الموحدة حفاظًا على التوافق.

لم يتم تعديل بيانات PostgreSQL أو بيانات العملاء أو الشركات.

---

## COMPANY PAGES SPLIT REPORT

# تقرير فصل صفحات الشركات

تمت إعادة تنظيم قسم الشركات إلى خمس صفحات مستقلة في القائمة الجانبية:

1. جميع الشركات: قائمة الشركات وفتح حساب كل شركة.
2. أرصدة الشركات: ملخص الأرصدة وتفاصيل العملات.
3. مزامنة الشركات: المزامنة اليدوية، رموز Authenticator، وحالة الاتصال.
4. إعدادات الربط: إضافة الشركات، تعديل بيانات الربط، اختبار الاتصال والحذف.
5. سجل عمليات الشركات: إحصاءات المزامنة وآخر 100 عملية.

## تحسينات الأداء

- لا يتم طلب مركز المزامنة إلا عند فتح صفحة المزامنة أو سجل العمليات.
- نموذج بيانات الربط لا يظهر ولا يُحمّل للمستخدم إلا داخل صفحة إعدادات الربط.
- تم إنشاء ملفات Lazy مستقلة لكل صفحة لتأجيل التحميل حتى فتحها.

## سلامة البيانات

لم يتم تعديل مخطط PostgreSQL أو حذف أو تغيير أي بيانات للعملاء أو الشركات أو الأرصدة.

---

## REPORTS PROFITS UNIFIED

# تقرير توحيد التقارير والأرباح — v23.0.30

## المنفذ
- دمج صفحة الأرباح والتقارير الشهرية في صفحة واحدة باسم **التقارير والأرباح**.
- إضافة تبويبين داخل الصفحة: **ملخص الأرباح** و**التقرير الشهري**.
- حذف قسم **أكثر العملاء تعاملًا خلال الشهر** من صفحة التقارير.
- حذف قسم **تفاصيل حوالات الشهر** من صفحة التقارير.
- إبقاء المؤشرات المالية والحركة اليومية والتصدير/الطباعة.
- حذف الخيارين المنفصلين من القائمة الجانبية واستبدالهما بخيار واحد.
- توجيه الروابط القديمة `profits` و`monthly-report` إلى الصفحة الموحدة للحفاظ على التوافق.

## البيانات
لم يتم تعديل PostgreSQL أو حذف أي بيانات. التعديل خاص بالواجهة والتنظيم فقط.

---

## UNIFIED MODAL SYSTEM REPORT

# تقرير نظام النوافذ الموحد — v23.0.32

- إضافة مكوّن UnifiedModal مشترك.
- إضافة نافذة تأكيد موحدة بدل window.confirm.
- دعم زر Esc والضغط خارج النافذة.
- إضافة LoadingButton لمنع الضغط المتكرر وإظهار جاري الحفظ.
- تطبيق التأكيد الموحد على حذف العملاء والحوالات والدفعات والشركات والمصروفات وحركات رأس المال واستعادة النسخ الاحتياطية وتصفير حساب العميل.
- تحسين العرض على الهاتف.
- لا توجد تغييرات على PostgreSQL أو البيانات.

---

## DEBTS UNIFIED PAGE REPORT

# تقرير توحيد صفحة الديون — v23.0.26

- الحفاظ على بطاقات دين لنا، دين علينا، صافي الديون بالدولار الكندي.
- الحفاظ على ملخص كل عملة بصورة مستقلة.
- إضافة صفحة ديون واحدة بأزرار: جميع الديون، دين لنا، دين علينا، المتأخرة، المسددة، الدفعات.
- نقل نموذج إضافة الدين إلى نافذة منبثقة.
- إضافة البحث وتحميل أول 50 سجلًا ثم تحميل المزيد.
- إضافة سجل دفعات الديون داخل الصفحة نفسها.
- عدم تعديل بيانات PostgreSQL أو حذف أي دين.

---

## FULL FIX REPORT

# تقرير الإصلاح الكامل — v23.0.20

## الإصلاحات المنفذة
- تثبيت تصدير جميع الشاشات الكسولة في `frontend/src/LazyScreens.jsx` لمنع خطأ React 3068.
- توحيد إصدار الخادم والواجهة على `23.0.20`.
- تحسين تشفير بيانات الشركات الخارجية مع دعم مفاتيح قديمة عبر `LEGACY_INTEGRATION_SECRET` دون تغيير بيانات PostgreSQL.
- إضافة رسالة عربية واضحة عند تعذر فك بيانات دخول شركة بدل رسالة OpenSSL الغامضة.
- تحسين استقرار PostgreSQL بإضافة keep-alive ومعالج أخطاء للـPool وإعادة محاولة الكتابة تلقائيًا.
- منع خطأ ROLLBACK من إسقاط الخادم عندما يكون اتصال PostgreSQL ميتًا.
- تحديث أمر بناء Render ليثبت تبعيات التطوير للواجهة والخادم باستخدام `npm ci --include=dev`.
- إزالة `server.js` القديم من الجذر وملف `data/store.json` من نسخة التوزيع.
- إضافة توثيق لمتغيرات `INTEGRATION_SECRET` و`LEGACY_INTEGRATION_SECRET` و`PG_WRITE_RETRIES`.

## إعداد Render
- Root Directory: فارغ
- Build Command: `npm run render-build`
- Start Command: `npm start`

لا تغيّر `JWT_SECRET` أو `DATABASE_URL` الحاليين.
لا تضف `INTEGRATION_SECRET` جديدًا قبل اختبار النسخة. إذا بقيت بيانات الشركات القديمة غير قابلة للفك، ضع المفتاح القديم فقط في `LEGACY_INTEGRATION_SECRET` أو أعد حفظ بيانات دخول الشركات.

## التحقق
- نجح فحص Syntax الكامل للخادم: `npm run check --prefix backend`.
- تعذر إكمال Build داخل بيئة الفحص فقط لأن مستودع npm الداخلي لم يوفر الحزمة الاختيارية `yallist@3.1.1`. أمر البناء مصمم ليعمل على Render عبر npm الرسمي.

---

## OPERATION TOASTS REPORT

# v23.0.31 — رسائل نجاح وفشل العمليات

- إضافة رسالة نجاح تلقائية بعد الإضافة والتعديل والحذف والتسديد والتحديث.
- إضافة رسالة خطأ واضحة عند فشل عمليات الكتابة.
- تطبيق الرسائل على العملاء والحوالات والديون والمصروفات ورأس المال والشركات وأسعار الصرف والفروع والمستخدمين والإعدادات.
- رسائل النجاح تختفي بعد 3 ثوانٍ، ورسائل الخطأ بعد 4.5 ثانية.
- لا تظهر الرسائل لطلبات القراءة أو تسجيل الدخول، ولا تغيّر أي بيانات في PostgreSQL.

---

## DEBT NET CAD REPORT

# تقرير صافي الديون بالدولار الكندي — v23.0.23

تم تنفيذ ما يلي:

- عرض إجمالي الدين لنا بعد تحويل جميع العملات إلى CAD.
- عرض إجمالي الدين علينا بعد تحويل جميع العملات إلى CAD.
- حساب صافي الديون النهائي: الدين لنا ناقص الدين علينا.
- استخدام أحدث أسعار الصرف المحفوظة في البرنامج ومسارات التحويل المباشرة أو غير المباشرة.
- إضافة زر لتحديث أسعار الصرف ثم إعادة الاحتساب فورًا.
- عرض وقت آخر سعر صرف مستخدم.
- إظهار العملات التي لا يوجد لها سعر تحويل بدل تجاهلها بصمت.
- إبقاء المجاميع الأصلية لكل عملة للمراجعة المحاسبية.

لا يتضمن هذا التعديل حذفًا أو تغييرًا لبيانات PostgreSQL.

---

## TRANSACTIONS SPLIT REPORT

# تقرير فصل صفحات الحوالات — v23.0.22

تم تنفيذ التعديلات التالية:

- فصل الحوالات في القائمة إلى صفحات مستقلة:
  - جميع الحوالات.
  - الحوالات غير المدفوعة.
  - الحوالات المدفوعة.
  - الحوالات المتأخرة لأكثر من 7 أيام.
  - سجل دفعات الحوالات.
- إبقاء نموذج إضافة الحوالة داخل صفحة «جميع الحوالات» فقط.
- إضافة بحث برقم الحوالة أو اسم العميل أو العملة.
- عرض أول 50 نتيجة ثم زر لتحميل 50 نتيجة إضافية.
- عدم إجراء أي تعديل على بيانات PostgreSQL أو جداول العملاء والحوالات.
- تحديث رقم الإصدار إلى v23.0.22.

ملاحظة: التقسيم الحالي يخفف رسم الجداول في المتصفح، لكنه ما زال يجلب قائمة الحوالات من المسار الحالي. يمكن تنفيذ Pagination من PostgreSQL في مرحلة لاحقة.

---

## TRANSACTIONS UNIFIED REPORT

# تقرير توحيد صفحة الحوالات — v23.0.25

## المنفذ
- توحيد جميع صفحات الحوالات في صفحة واحدة.
- إبقاء عنصر واحد فقط للحوالات في القائمة الجانبية.
- إضافة تبويبات داخلية: جميع الحوالات، المدفوعة، غير المدفوعة، الدفعات، والمتأخرة.
- تحويل نموذج إضافة الحوالة إلى نافذة منبثقة.
- إضافة بطاقات إجمالية بالدولار الكندي:
  - إجمالي جميع الحوالات.
  - الرصيد غير المدفوع.
  - إجمالي المدفوع.
- الإبقاء على البحث، الفاتورة، التعديل، التسديد الكامل، وتحميل 50 نتيجة إضافية.
- دعم الروابط القديمة للصفحات المنفصلة وتحويلها إلى الصفحة الموحدة.

## سلامة البيانات
لم يتم تعديل بنية PostgreSQL أو حذف/تغيير أي بيانات حالية. التعديل يخص الواجهة وطريقة العرض فقط.

## الفحص
- نجح فحص Backend الكامل.
- تعذر تشغيل Vite محليًا بسبب عدم توفر إحدى حزم npm في مستودع بيئة الفحص، وليس بسبب خطأ مثبت في كود المشروع.

---

## CODE SPLITTING REPORT

# تقرير تحسين الأداء — تقسيم الشاشات

الإصدار: v23.0.20

## ما تم

- تقسيم ملف `frontend/src/LazyScreens.jsx` الكبير إلى ملفات مستقلة داخل `frontend/src/screens/`.
- أصبح كل قسم يُحمّل عند فتحه فقط عبر `React.lazy`.
- الشاشات المقسمة: الأرباح، أسعار الصرف، الديون العامة، الشركاء، رأس المال، التقرير الشهري، الإعدادات، مركز الذكاء الاصطناعي، والمصروفات.
- الإبقاء على `LazyScreens.jsx` كملف توافق صغير فقط.
- تحديد سجل أسعار الصرف افتراضيًا بآخر 50 سجلًا، وبحد أقصى 200.
- ضمان تثبيت Chromium أثناء بناء Render لتشغيل موصل جاد.

## الأمان والبيانات

لم يتم تعديل قاعدة PostgreSQL أو حذف بيانات العملاء أو الحوالات أو الديون.

---

## OVERDUE CUSTOMERS PAGE REPORT

# تقرير فصل صفحة العملاء المتأخرين

تم تنفيذ التعديلات التالية:

- إضافة عنصر مستقل في القائمة باسم: العملاء المتأخرون.
- عرض عدد العملاء المتأخرين بجانب اسم الصفحة.
- ربط الصفحة بالمكوّن المخصص OverdueCustomers بدل إعادة فتح صفحة العملاء.
- إزالة بطاقة العملاء المتأخرين من إحصاءات صفحة العملاء.
- إزالة لوحة تنبيهات العملاء المتأخرين من داخل صفحة العملاء.
- جعل توصيات لوحة التحكم الخاصة بالتأخير تفتح الصفحة المستقلة مباشرة.
- الحفاظ على وظائف فتح حساب العميل، كشف الحساب، واتساب، تسجيل التواصل، ووعد الدفع.
- لم يتم تعديل PostgreSQL أو بيانات العملاء.

## الفحص
- نجح تحليل JSX لملف App.jsx.
- نجح فحص جميع ملفات Backend عبر npm run check --prefix backend.
- تعذر إكمال Vite build محليًا بسبب غياب حزمة Rollup الاختيارية الخاصة ببيئة Linux، وليس بسبب خطأ JSX.

---

## SETTINGS MOBILE REPORT

# تقرير تحديث الإعدادات — v23.0.27

- تحويل صفحة الإعدادات إلى لوحة أزرار واضحة.
- فتح كل وظيفة داخل نافذة منبثقة مستقلة.
- الحفاظ على جميع وظائف الإعدادات السابقة.
- إصلاح ضعف تباين النص داخل البطاقات البيضاء في تطبيق الهاتف.
- تحسين حجم الخط والقراءة على الشاشات الصغيرة.
- منع تداخل محتوى الإعدادات مع شريط التنقل السفلي.
- دعم إغلاق النافذة من زر الإغلاق أو الضغط خارجها.

لم يتم تعديل PostgreSQL أو بيانات العملاء والحوالات والديون.

---

## DESKTOP DASHBOARD V24.0.0

# تقرير واجهة الكمبيوتر الاحترافية — v24.0.0

تم اعتماد التصميم الداكن الكحلي والذهبي كواجهة الكمبيوتر الرسمية للوحة التحكم.

## المنفذ
- قائمة جانبية ثابتة مخصصة للكمبيوتر.
- شريط علوي مضغوط للشعار والبحث والوقت وحالة الاتصال.
- ست بطاقات مؤشرات رئيسية قابلة للفتح.
- رسم أداء آخر سبعة أيام مع ملخص الميزانية والتنبيهات.
- أقسام أفضل العملاء وتحليل الربح والمقارنة التنفيذية.
- تحميل البيانات الحالية نفسها دون تغيير الحسابات أو قاعدة البيانات.
- إخفاء عناصر الهاتف في الكمبيوتر وإبقاء تصميم الهاتف مستقلاً.
- دعم شاشات 1280 بكسل فما فوق مع تخطيط مرن.

## البيانات
لم يتم تعديل PostgreSQL أو مسارات API أو طريقة حساب الأرباح والديون.

---

## MOBILE FINAL REVIEW V23.0.39

# v23.0.39 — المراجعة النهائية لواجهة الهاتف

## ما تم تنفيذه

- منع ظهور الخلفية البيضاء أثناء تحميل الشاشات الكسولة.
- توحيد تباين البطاقات والأرقام في الوضع الداكن.
- زيادة وضوح المبالغ وتثبيت عرض الأرقام.
- تحسين حقول الإدخال والقوائم والنصوص الإرشادية.
- جعل جميع مناطق الضغط لا تقل عن 44 بكسل.
- تحسين التمرير الأفقي للجداول دون تعطيل التمرير العمودي للصفحة.
- إضافة مساحة آمنة أسفل آخر عنصر في كل صفحة.
- رفع رسائل النجاح وزر الذكاء الاصطناعي فوق شريط التنقل.
- تحسين تمرير النوافذ المنبثقة وعزل تمريرها عن الصفحة الخلفية.
- تحسين ترتيب أزرار الإجراءات على الشاشات الصغيرة.

## سلامة البيانات

هذا الإصدار يغيّر الواجهة فقط ولا يغيّر PostgreSQL أو بيانات العملاء أو الحوالات أو الديون.

---

## MOBILE COLORS NUMBERS V23.0.38

# v23.0.38 — إصلاح ألوان وأرقام تطبيق الهاتف

- إزالة البطاقات البيضاء من صفحة العملاء المتأخرين على الهاتف.
- استخدام خلفيات كحلية داكنة وحدود ذهبية خفيفة.
- رفع تباين العناوين والقيم والأرقام.
- عرض المبالغ بصيغة واحدة مثل `1,500.00 CAD`.
- إزالة تكرار رمز العملة `CAD CAD`.
- تحسين وضوح حقول الإدخال والنصوص الثانوية.
- لم يتم تعديل قاعدة البيانات أو العمليات المالية.

---

## MOBILE SCROLL FIX V23.0.37

# إصلاح تمرير تطبيق الهاتف — v23.0.37

- جعل محتوى الصفحة حاوية التمرير الوحيدة على الهاتف.
- تثبيت الرأس وشريط التنقل خارج منطقة المحتوى المتحركة.
- تفعيل التمرير اللمسي السلس داخل Android WebView وiPhone.
- إضافة مساحة سفلية تمنع شريط التنقل وزر AI من تغطية آخر عنصر.
- إصلاح قفل الصفحة بعد إغلاق النوافذ المنبثقة.
- تطبيق الإصلاح على جميع الصفحات دون تعديل البيانات أو الوظائف المالية.

---

## EXCHANGE RATES GLOBAL USD V23.0.36

# تحديث صفحة العملات وأسعار الصرف — v23.0.36

- أصبحت أسعار العملات تلقائية بالكامل دون حقول تعديل يدوي.
- الدولار الأمريكي USD هو العملة الأساسية لجميع أسعار العملات.
- يجلب الخادم أسعار 23 عملة من نشرة عالمية مرجعية دفعة واحدة.
- الصفحة الرئيسية نظيفة، والنوافذ المنبثقة مخصصة لإدارة العملات والسجل والإعدادات والتفاصيل.
- يحتفظ النظام بآخر سعر ناجح إذا تعذر المصدر.
- التحديث يتم يدويًا بزر واحد وتلقائيًا كل ساعة.
- أسعار الذهب تبقى تلقائية بالكامل.
- لم يتم تعديل بيانات العملاء أو الحوالات أو الديون في PostgreSQL.

---

## MOBILE SAFE AREA V23.0.35

# تحديث واجهة الهاتف v23.0.35

- اعتماد الشعار الرسمي الموجود في `frontend/public/alaboud-company-logo.webp`.
- منع تداخل رأس التطبيق مع شريط الساعة والكاميرا.
- منع تداخل شريط التنقل ومساعد AI مع أزرار Android وiPhone.
- إضافة دعم `safe-area-inset-top` و`safe-area-inset-bottom`.
- رفع القائمة السفلية عن حافة الشاشة مع إطار وظل احترافي.
- إضافة مساحة سفلية آمنة لجميع الصفحات والنوافذ.
- جعل القائمة الجانبية تحترم شريط الحالة ومنطقة الإيماءات.
- ضبط Android WebView ليبقى داخل حدود أشرطة النظام.
- لم يتم تعديل قاعدة البيانات أو الوظائف المالية.

---

## PERFORMANCE OPTIMIZATION V23.0.34

# تقرير تحسين الأداء — v23.0.34

- خفض تحديث لوحة التحكم التلقائي من كل دقيقة مع 8 طلبات إلى تحديث ملخص خفيف كل 5 دقائق.
- إيقاف التحديثات عندما تكون الصفحة في الخلفية.
- تحميل بيانات لوحة التحكم الثقيلة مرة واحدة فقط ثم استخدام التخزين المؤقت.
- تحديد عدد السجلات المطلوبة للمعاملات والعملاء والمصروفات وسجل الأسعار.
- رفع مدة التخزين المؤقت الافتراضية لطلبات GET إلى 60 ثانية ومنع تكرار الطلبات المتزامنة.
- إزالة معامل `_live` الذي كان يمنع الاستفادة من التخزين المؤقت.
- تقليل طلب تنبيهات العملاء بحيث يعمل فقط في الصفحات المتعلقة بالعملاء أو لوحة التحكم.
- تحسين تقسيم حزم Vite لكل شاشة مستقلة.
- إضافة شاشة تحميل داكنة وخفيفة عند الانتقال لأول مرة.
- لا توجد تغييرات على PostgreSQL أو البيانات المالية.

---

## V23 0 29 CUSTOMERS ON DEMAND REPORT

# تقرير الإصدار v23.0.29

## صفحة العملاء عند الطلب

- لا تظهر قائمة العملاء تلقائيًا عند فتح صفحة العملاء.
- تبقى بطاقات الملخص والأزرار السريعة ظاهرة.
- تمت إضافة زر **قائمة العملاء** لفتح القائمة عند الحاجة فقط.
- عند فتح القائمة يظهر مربع البحث مباشرة مع عدد النتائج.
- تمت إضافة زر **إغلاق القائمة** لإخفائها ومسح البحث.
- لم تتم إضافة العملاء المتأخرين داخل الصفحة؛ تبقى لهم صفحتهم المستقلة.
- تم الحفاظ على فتح ملف العميل، تعديل العميل، حذف العميل، تصفير الحساب، إضافة حوالة وإضافة دفعة.
- لم يتم تعديل PostgreSQL أو أي بيانات عملاء.

---

## V23 0 28 INTEGRITY AUDIT REPORT

# تقرير الإصدار v23.0.28

- منع تكرار رقم هاتف العميل بعد توحيد صيغة الرقم.
- إظهار العميل الموجود مع زر فتح ملفه عند محاولة التكرار.
- دعم تسديد الدين علينا أو تحصيل الدين لنا، كاملًا أو جزئيًا.
- تحديث المتبقي والحالة وسجل دفعات الديون تلقائيًا.
- توسيع سجل التدقيق بالقيمة قبل وبعد، المستخدم، IP والفرع عند توفرهما.
- عدم تسجيل كلمات المرور أو رموز Authenticator في سجل التدقيق.
- لم تُحذف أو تُعدّل بيانات PostgreSQL الموجودة.

---

## RELEASE NOTES V23.0.20

# ملاحظات إصدار v23.0.20

## الإصلاحات المنفذة

- توحيد رقم الإصدار إلى 23.0.20 في المشروع والواجهة والخادم.
- حذف ملف بيانات التشغيل `data/store.json` من نسخة التوزيع.
- إضافة نموذج بيانات فارغ وآمن في `examples/store.example.json`.
- حذف `server.js` القديم من جذر المشروع.
- حذف `App_v16.0.15_FIXED.jsx` القديم.
- حذف ملفات البناء القديمة من `backend/public` و`frontend/dist`.
- منع تشغيل التخزين المحلي JSON في وضع الإنتاج عند غياب `DATABASE_URL`.
- ربط PostgreSQL في ملفات Render Blueprint.
- توليد كلمة مرور المدير الأولية عبر متغير بيئة بدل الاعتماد فقط على كلمة ثابتة.
- إضافة تنظيف دوري لسجلات Rate Limiter المنتهية.
- إضافة أوامر `dev` و`preview` للواجهة.
- نقل Vite وملحق React إلى `devDependencies`.
- تحديث `scripts/package.json` إلى الإصدار الحالي.

## التحقق

نجح فحص JavaScript للخادم عبر:

```bash
npm run check --prefix backend
```

لم يكتمل اختبار التثبيت والبناء داخل بيئة الفحص بسبب عدم توفر الحزمة `xtend@4.0.2` في مستودع npm الداخلي للبيئة. هذا ليس خطأً مثبتًا في كود المشروع. للتحقق على جهازك شغّل:

```bash
npm install
npm run render-build
npm run check --prefix backend
npm test --prefix backend
```

---

## v23.0.3_PARTNERS

# الإصدار v23.0.3 — موصلات الشركات

- إصلاح قراءة رصيد تواصل المفرد ورموز العملات US وEU.
- إضافة موصل دهب لمسار `/branch/api/index.php` مع Google Authenticator.
- إضافة موصل سوريانا اعتمادًا على رابطها الكامل ومسار تسجيل الدخول `/log`.
- إضافة خانة Authenticator وزر اختبار الاتصال وجلب الرصيد لدهب وسوريانا.
- إبقاء المزامنة يدوية لحماية استقرار Render المجاني.
- إصلاح تفسير الفاصلة في رصيد تواصل: 20,908 تعني عشرين ألفًا وتسعمئة وثمانية وليست 20.908.

---

## v23.0.2_STABLE

# الإصدار v23.0.2 المستقر

- إصلاح تراكم نسخ قاعدة البيانات في الذاكرة الذي كان يؤدي إلى Status 134 و502 على Render.
- دمج عمليات الحفظ المتقاربة والاحتفاظ بآخر نسخة فقط أثناء الكتابة إلى PostgreSQL.
- تعطيل المزامنة التلقائية الثقيلة للشركات؛ تبقى المزامنة اليدوية متاحة.
- تشغيل موصل جاد بوضع HTTP الأخف افتراضيًا.
- إيقاف تثبيت Chromium أثناء بناء Render لتقليل الذاكرة والوقت والحجم.
- تخفيض اتصالات PostgreSQL الافتراضية على الخطة المجانية إلى اتصالين.
- تحسين قراءة رصيد تواصل عندما تعيد الواجهة رصيدًا مفردًا بدل قائمة.
- دعم رموز العملات المختصرة التي تستخدمها بعض واجهات الشركات مثل US وEU.

لا يغيّر هذا الإصدار بنية البيانات ولا يحذف بيانات PostgreSQL.

---

## v23.0.1

# إصلاحات v23.0.1

- إضافة واجهة «نسيت كلمة السر» والاستعادة بالبريد أو رقم الهاتف المسجل.
- الحفاظ على التحقق بخطوتين عبر Google Authenticator للحساب.
- إصلاح حفظ أرصدة تواصل لجميع العملات بدل حذف ما عدا الدولار واليورو.
- دعم أسماء وحقول «المبلغ النظامي / الليرة النظامية» في استجابة تواصل.
- منع تكرار رقم العميل وإضافة ترقيم تلقائي عند ترك الرقم فارغًا.
- إظهار رسالة تأكيد بعد حفظ العميل.
- ضغط الشعار تلقائيًا إلى WebP قبل حفظه وحل مشكلة الصور الكبيرة.
- إضافة سوريانا ودهب إلى أنواع الشركات، مع توضيح أن المزامنة الفعلية تنتظر API رسميًا لكل شركة.
- إصلاح اختبارات المشروع القديمة التي كانت تتوقع إصدارًا وكلمة مرور قديمين.

## متطلبات التشغيل

يجب ضبط SMTP لإرسال روابط استعادة كلمة المرور في الإنتاج. الاستعادة برقم الهاتف تتحقق من الرقم المسجل ثم ترسل الرابط إلى البريد المرتبط بالحساب.

ربط سوريانا ودهب لجلب الرصيد يحتاج عنوان API أو نموذج طلب رسمي/موثق من كل شركة؛ لم تتم إضافة تخمين أو استخراج غير آمن لبيانات الدخول.

---

## v23.0.0

# ALABOUD Business Suite v23.0.0 — Enterprise Stable Release

## التحسينات المنفذة

- إضافة وحدة جاهزية الإنتاج وفحص إعدادات البيئة.
- توحيد رقم الإصدار من مصدر مركزي.
- إضافة بصمة SHA-256 للنسخ الاحتياطية.
- رفض استعادة النسخ المعدلة أو التالفة.
- تحسين نقطة `/api/health` لتعرض حالة قاعدة البيانات وجاهزية الإنتاج.
- تحسين معالجة أخطاء الخادم وإضافة `requestId` دون كشف تفاصيل داخلية.
- إغلاق خادم HTTP وقاعدة البيانات بشكل منظم.
- التعامل مع `unhandledRejection` و`uncaughtException`.
- إضافة اختبار مستقل لجاهزية الإنتاج وسلامة النسخ الاحتياطية.

## متطلبات الإنتاج

يجب ضبط:

- `JWT_SECRET` بطول 32 حرفًا على الأقل.
- `DATABASE_URL`.
- `CORS_ORIGIN`.

## ملاحظات التحقق

يجب تشغيل:

```bash
npm run check --prefix backend
npm run test:production --prefix backend
npm run build
```

---

## v22.8.0

# ALABOUD Business Suite v22.8.0
## شبكة الفروع والشركات

- إنشاء وإدارة فروع متعددة داخل الشركة.
- فرع رئيسي تلقائي وترحيل السجلات القديمة إليه.
- اختيار الفرع النشط عبر ترويسة X-Branch-ID ومن واجهة البرنامج.
- عزل بيانات العملاء والحوالات والمصروفات والديون ورأس المال حسب الفرع.
- تقييد المستخدمين بفروع محددة عبر branchIds.
- مؤشرات مالية وتشغيلية لكل فرع وملخص موحد للشبكة.
- سجل تدقيق لإنشاء الفروع وتعديلها.
- واجهة إدارة الفروع ضمن الإعدادات.

---

## v22.6.0

# ALABOUD Business Suite v22.6.0

## REST API Platform & Developer Portal

تم تنفيذ:
- OpenAPI 3.1 عبر `/api/openapi.json`.
- صفحة توثيق للمطورين عبر `/api/docs`.
- دعم مسارات الإصدار `/api/v1/*` مع إبقاء المسارات القديمة متوافقة.
- إنشاء وإدارة وإلغاء مفاتيح API مع الصلاحيات والانتهاء وإحصاءات الاستخدام.
- إدارة Webhooks واختبارها وتعطيلها.
- Integration Logs لطلبات API مع الحالة وزمن الاستجابة وهوية التكامل.
- مصادقة `X-API-Key` إلى جانب JWT.
- تحديث الإصدار إلى 22.6.0.

## متغيرات البيئة
لا توجد متغيرات إلزامية جديدة. ينصح باستخدام HTTPS في الإنتاج، ولا يسمح النظام بروابط Webhook من نوع HTTP في الإنتاج.

---

## v22.5.0

# ALABOUD Business Suite v22.5.0

## Enterprise Security & Audit

- نظام صلاحيات مركزي للأدوار: ADMIN وMANAGER وACCOUNTANT وUSER وVIEWER.
- إرجاع الصلاحيات الفعلية للمستخدم مع الجلسة.
- سجل جلسات نشطة مع عنوان IP ونوع الجهاز وآخر نشاط وتاريخ الانتهاء.
- انتهاء تلقائي للجلسة بعد الخمول (افتراضيًا 30 دقيقة، قابل للتعديل عبر SESSION_IDLE_MINUTES).
- تسجيل خروج للجلسة الحالية أو إنهاء الجلسات الأخرى.
- واجهة إدارية لقراءة سجل التدقيق مع التصفية حسب العملية ونوع السجل.
- استمرار سلسلة سلامة سجل التدقيق باستخدام integrityHash.
- تسجيل عمليات تسجيل الخروج وإلغاء الجلسات داخل سجل التدقيق.

---

## v22.3.5

# ALABOUD Business Suite v22.3.5

## PostgreSQL Native Operations — المرحلة الثانية

- توسيع القراءة المباشرة من PostgreSQL لتشمل الحوالات والدفعات والديون ودفعات الديون والمصروفات وحركات رأس المال.
- الحفاظ على نفس استجابات API الحالية مع رجوع آمن إلى الذاكرة عند تعذر PostgreSQL.
- إضافة `findById` و`countByCompany` إلى المستودع العام.
- إضافة قياسات نجاح وفشل وزمن القراءة الأصلية إلى `/api/health`.
- إضافة `mutateDurable` لتمكين نقاط API الحساسة من انتظار اكتمال الحفظ الذري.
- تستمر الكتابة عبر `PostgresStateAdapter` داخل معاملة واحدة تشمل `app_state` والجداول العلائقية، لذلك لا يحدث حفظ جزئي.

> لا يزال `app_state` موجودًا للتوافق والاسترجاع الآمن. لم يُحذف في هذا الإصدار.

---

## v22.3.4

# ALABOUD Business Suite v22.3.5 — PostgreSQL Native Repositories

- إضافة طبقة Repository مستقلة لقراءة العملاء والشركاء وأسعار الصرف من PostgreSQL.
- المحافظة على شكل واجهات API الحالية دون تغيير.
- رجوع تلقائي وآمن إلى الذاكرة الحالية عند غياب PostgreSQL أو فشل الاستعلام.
- مفتاح تحكم: `POSTGRES_NATIVE_READS=false` لتعطيل القراءة المباشرة مؤقتًا.
- إظهار حالة Native Reads ضمن `/api/health`.
- الكتابة ما زالت تمر عبر نظام المزامنة الانتقالي لضمان التوافق وعدم فقدان البيانات.

---

## v22.3.3

# ALABOUD Business Suite v22.3.3 — PostgreSQL Native Transition

## المنجز فعليًا
- إضافة `RelationalProjector` لمزامنة الحالة التشغيلية مع الجداول العلائقية.
- أصبح حفظ `app_state` وتحديث الجداول العلائقية داخل PostgreSQL Transaction واحدة.
- عند فشل أي كتابة علائقية يتم تنفيذ ROLLBACK كامل.
- مزامنة الحذف للسجلات التابعة للشركة حتى لا تبقى صفوف قديمة.
- إضافة حالة `relationalMirrorEnabled` إلى فحص صحة قاعدة البيانات.
- متغير طوارئ: `RELATIONAL_MIRROR_ENABLED=false` لتعطيل المزامنة العلائقية.

## ما لم يُنجز بعد
- القراءة المباشرة لجميع APIs من الجداول العلائقية لم تُفعّل بعد.
- ما زالت القراءة التشغيلية تعتمد على الحالة المحملة في الذاكرة للحفاظ على توافق الواجهة.

---

## v22.3.2

# ALABOUD Business Suite v22.3.2

- إضافة محرك ترحيل من `app_state` أو نسخة JSON إلى الجداول العلائقية.
- تنفيذ الترحيل داخل PostgreSQL Transaction واحدة.
- عدم تعديل أو حذف مصدر البيانات الحالي.
- تسجيل كل تشغيل وأعداده ومعرّفات السجلات المضافة.
- إضافة أوامر migrate وverify وrollback.
- حفظ الحقول القديمة كاملة في `raw_payload` لتجنب فقدان المعلومات.

---

## v22.3.0

# ALABOUD Business Suite v22.3.0

## طبقة قاعدة البيانات

- إضافة `DatabaseService` كواجهة موحّدة بين منطق التطبيق ومصدر التخزين.
- إضافة محول PostgreSQL الحالي (`PostgresStateAdapter`) مع تجميع الاتصالات وفحص الصحة.
- إضافة محول JSON (`JsonFileAdapter`) للتطوير المحلي والترحيل الآمن.
- الحفاظ على جميع واجهات API الحالية دون تغيير.
- إضافة تسلسل كتابة يمنع تداخل عمليات الحفظ.
- إضافة تفريغ عمليات الكتابة وإغلاق اتصال PostgreSQL عند SIGTERM/SIGINT.
- تطوير `/api/health` ليعرض حالة قاعدة البيانات ورقم الإصدار.

> هذا الإصدار يفصل البنية فقط. ما زال PostgreSQL يخزن الحالة الحالية داخل JSONB. تحويل الكيانات إلى جداول علائقية مستقلة سيكون في v22.3.1 وما بعده.

---

## v22.1.0

# الإصدار 22.1.0 — اختبارات Jest وSupertest

- إضافة Jest كمنظومة اختبارات آلية للباك إند.
- إضافة Supertest لاختبار مسارات API بدون تشغيل خادم منفصل.
- فصل تهيئة التطبيق عن الاستماع إلى المنفذ حتى يصبح السيرفر قابلاً للاختبار.
- إضافة اختبارات للصحة، المصادقة واستعادة كلمة المرور، العملاء، ورأس المال والمصروفات.
- إضافة تقرير تغطية عبر `npm run test:coverage`.
- الاحتفاظ باختبار `selftest` القديم تحت الأمر `npm run test:legacy` للمقارنة المؤقتة.

---

## v22.0.0

# ALABOUD Business Suite v22.0.0

## أمان واستعادة الحساب
- إضافة طلب استعادة كلمة المرور عبر البريد الإلكتروني.
- رابط إعادة تعيين صالح لمدة 15 دقيقة ومخزن بصيغة hash فقط.
- إلغاء رمز الاستعادة فور استخدامه.
- فك قفل الحساب وتصفير المحاولات الفاشلة بعد نجاح الاستعادة.
- عدم كشف وجود البريد المسجل في استجابة API.

## البريد الإلكتروني
- إضافة تكامل SMTP اختياري باستخدام Nodemailer.
- توثيق جميع متغيرات SMTP في `.env.example`.

## الجودة وCI
- إضافة GitHub Actions لفحص صياغة الخادم، تشغيل الاختبارات، بناء الواجهة، وفحص التبعيات.
- إضافة اختبار آلي لمسار: طلب الاستعادة → تعيين كلمة جديدة → تسجيل الدخول.

## ملاحظات تشغيل
- يجب ضبط `APP_BASE_URL` وبيانات `SMTP_*` في Render لإرسال الرسائل فعليًا.
- `RETURN_RESET_TOKEN=true` مخصص للتطوير والاختبارات فقط ولا يعمل كاستجابة في وضع الإنتاج.

---

## v21.6.0

# الإصدار v21.6.0 — لوحة الأصول والالتزامات وصافي رأس المال

## ما تم تعديله
- إعادة تصميم أعلى صفحة الميزانية إلى ثلاث بطاقات رئيسية قابلة للضغط:
  1. المال الكلي = رأس المال + الأرباح المتراكمة + الدين لنا.
  2. إجمالي الالتزامات = الدين علينا + المصروفات المتراكمة.
  3. صافي رأس المال = المال الكلي − إجمالي الالتزامات.
- إضافة نافذة تفاصيل مستقلة لكل بطاقة.
- إضافة نافذة حساب كاملة لصافي رأس المال خطوة بخطوة.
- إضافة `totalLiabilities` إلى استجابة الخادم، وجميع القيم موحدة إلى CAD.
- تحسين العرض على الجوال والكمبيوتر.

## التوافق
- لا يوجد تغيير في بنية قاعدة البيانات.
- البيانات القديمة تبقى متوافقة.

---

## v21.5.2

# الإصدار v21.5.2 — المال الكلي وصافي رأس المال الكامل

- توحيد قيمة «ديون علينا» مع جميع مصادر صفحة الديون.
- احتساب الديون اليدوية متعددة العملات بعد تحويلها إلى CAD.
- احتساب أرصدة الشركات المرتبطة والرصيد الخارجي متعدد العملات.
- إضافة بطاقة «المال الكلي».
- إضافة «صافي رأس المال بعد خصم كل شيء».
- المعادلة: المال الكلي = رأس المال الفعلي + الأرباح المتراكمة + جميع ديون لنا.
- صافي رأس المال = المال الكلي - المصاريف المتراكمة - جميع ديون علينا.

---

## v21.4.0

# ALABOUD Business Suite v21.4.0

## محرك رأس المال متعدد العملات

- تحويل رأس المال والسحوبات تلقائيًا إلى العملة الأساسية CAD.
- حفظ المبلغ الأصلي والعملة وسعر الصرف والقيمة المحولة.
- اعتماد `cadAmount` في الميزانية وإجماليات رأس المال والمؤشرات المالية.
- عرض معاينة التحويل قبل الحفظ.
- عرض سعر التحويل والقيمة الكندية في سجل رأس المال.
- منع حفظ عملة لا يتوفر لها مسار تحويل إلى CAD.
- دعم السجلات القديمة بعرض تحويل محسوب من أحدث سعر متوفر دون تغيير المبلغ الأصلي.

## حالة البناء

- تم تعديل المصدر.
- تم بناء الواجهة الأمامية بنجاح.
- تم نسخ ملفات البناء إلى `backend/public`.
- تم فحص صياغة الخادم بنجاح.
- لم يتم بناء APK في هذا الإصدار.

---

## v21.3.0

# ALABOUD Business Suite v21.3.0

## تصميم أسعار صرف احترافي
- تحويل جدول العملات إلى بطاقات مصرفية حديثة.
- إظهار العلم والاسم والرمز لكل عملة.
- عرض السعر في منتصف البطاقة مع اتجاه الحركة.
- إضافة البحث السريع.
- إضافة مرشحات: الكل، المفضلة، USD، CAD، أخرى.
- إضافة نجمة المفضلة مع حفظ الاختيارات محليًا.
- تحسين كامل للعرض على الهاتف ومنع تداخل النصوص.

---

## v21.2.1

# الإصدار v21.2.1 — تصحيح دقة أسعار الصرف

- إصلاح اختيار زوج العملة الصحيح بدل الاعتماد على العملة الأساسية فقط.
- استخدام USD/العملة مباشرة، أو عكس العملة/USD بصورة صحيحة.
- إضافة تحويل متقاطع عبر CAD فقط عند عدم توفر زوج مباشر.
- إصلاح ظهور أسعار غير منطقية مثل 121.7314 للدولار مقابل الدولار الكندي.
- تحسين جدول أسعار العملات على الهاتف وتحويل كل صف إلى بطاقة واضحة.

---

## v21.2.0

# ALABOUD Business Suite v21.2.0
## USD Base Exchange Board

- اعتماد الدولار الأمريكي USD كعملة أساسية ثابتة في لوحة أسعار الصرف.
- عرض كل صف بصيغة: USD 1 = القيمة + العملة المقابلة.
- دعم CAD وEUR وTRY وSAR وJOD وSYP.
- حساب الأسعار المتقاطعة من أحدث الأسعار المسجلة مقابل CAD.
- تصميم مصرفي جديد ومحاذاة ثابتة للأعلام والرموز والقيم.
- تحسين كامل لشاشات الهاتف ومنع التفاف النصوص أو تداخلها.
- تحسين عرض آخر تحديث وحالة الأسعار المفقودة.

---

## v21.0.5

# إصدار v21.0.5 — إجمالي أجور جاد فقط

- الإبقاء على زر **جلب الرصيد** دون تغيير.
- إضافة زر مستقل باسم **جلب الأجور** لشركة جاد.
- اختيار تاريخ البداية والنهاية.
- عرض **المجموع النهائي للأجور فقط**.
- إزالة جدول الحركات وتفاصيل الحوالات من واجهة الأجور.

---

## v21.0.3

# إصدار 21.0.3 — تقرير أجور حوالات جاد حسب التاريخ

- إضافة حقلي من تاريخ وإلى تاريخ لشركة جاد.
- إضافة زر جلب أجور الحوالات.
- استخراج الأجور من عمود الأجور/العمولة أو من الحركات المسماة أجور أو عمولة.
- عرض جدول بالحركات ومجموع الأجور والعملة ضمن الفترة المطلوبة.
- حفظ آخر مجموع أجور وفترة تم طلبها ضمن بيانات الشركة.

---

## v21.0.2

# الإصدار v21.0.2

## تحسين لوحة أسعار الصرف على الهاتف

- تنظيم رأس بطاقة العملة لمنع أي تشابك بين العلم والرمز ونسبة التغير.
- إعادة عرض الشراء والبيع جنبًا إلى جنب مع أرقام مرنة.
- تصميم احترافي واضح للعملات التي لا تملك سعرًا مع زر إضافة بصري.
- إضافة ملخص لعدد العملات المحدثة والعملات التي تحتاج سعرًا.
- تحسين فرق السعر والرسم المصغر على الشاشات الضيقة.

---

## v20.2.0

# الإصدار v20.2.0 — Budget Intelligence

- إعادة تصميم صفحة الميزانية.
- ملخص مالي ذكي للشهر المحدد.
- تدفق الإضافات والسحوبات بالنسب.
- صافي الأرباح بعد المصروفات.
- مؤشر كفاءة دوران رأس المال.
- ملخص الحركات حسب العملة.
- بحث وتصفية سجل رأس المال.
- تحسين العرض على الهاتف والكمبيوتر.

---

## v20.1.0

# ALABOUD Business Suite v20.1.0

## مدير العملات
- إضافة زر **إضافة عملات** داخل صفحة أسعار الصرف.
- قائمة واسعة من العملات العربية والعالمية مع البحث بالاسم أو الرمز.
- تفعيل وإزالة العملات المستخدمة بسهولة.
- إضافة عملة مخصصة بإدخال الرمز والاسم والعلم.
- حفظ قائمة العملات على الجهاز تلقائيًا.
- استخدام العملات المضافة مباشرة في حقول «من» و«إلى» عند تسجيل سعر جديد.
- تصميم متجاوب للهاتف والكمبيوتر.

لم تُحذف أي ميزة سابقة.

---

## v20.0.0

# ALABOUD Business Suite v20.0.0 — Enterprise UI

## التغييرات
- اعتماد الواجهة الاحترافية الداكنة الجديدة للوحة التحكم.
- إعادة تصميم لوحة أسعار الصرف المباشرة ووضعها في أعلى الصفحة.
- إضافة اسم كل عملة ونسبة اتجاه السعر ومخطط مصغر داخل البطاقة.
- تحسين بطاقات المؤشرات المالية وإضافة تسلسل بصري أوضح للأرقام.
- إضافة شريط حالة للنظام وصحة الشركة والمزامنة وآخر تحديث.
- تحسين التباين والمسافات والظلال والتجاوب مع الهاتف.
- الحفاظ على جميع الوظائف والصفحات السابقة دون حذف.

## التحقق
- نجح بناء React/Vite.
- نجح فحص صياغة backend/src/server.js.
- تم نسخ بناء الواجهة إلى backend/public.

---

## v19.2.2

# ALABOUD Business Suite v19.2.2

## لوحة أسعار الصرف ذات الأولوية

- نقل لوحة أسعار الصرف إلى أعلى لوحة التحكم مباشرة بعد مؤشر صحة الشركة.
- عرض العملات: USD وCAD وEUR وTRY وSYP وSAR وJOD.
- عرض سعر الشراء والبيع لكل عملة مقابل العملة المرجعية.
- إضافة مؤشرات ارتفاع وانخفاض وثبات السعر.
- إضافة زر تحديث مباشر وزر عرض التفاصيل.
- إبقاء آخر أسعار صحيحة عند فشل التحديث، مع إظهار رسالة خطأ واضحة دون تصفير القيم.
- عرض بطاقة واضحة للعملات التي لا يوجد لها سعر مسجل.
- تحسين الاستجابة على الهاتف والكمبيوتر.
- لم تُحذف أي ميزة أو API أو بيانات موجودة.

---

## v19.2.1

# ALABOUD Business Suite v19.2.1

## تحسين وضوح الإعدادات والأرقام المالية

- رفع تباين النصوص داخل جميع بطاقات صفحة الإعدادات.
- تحسين ألوان العناوين والوصف والحقول والنصوص المؤقتة.
- تحسين بطاقة التحقق من التحديثات وإظهار رقم الإصدار بوضوح.
- إضافة ألوان دلالية للأرقام المالية المهمة والإجماليات.
- صافي الربح الموجب باللون الأخضر والخسارة باللون الأحمر.
- المصروفات بالبرتقالي، الإجماليات بالأزرق، الأجور بالذهبي، وأعداد العمليات بالبنفسجي.
- تمييز صافي الربح داخل جدول الأرباح الشهرية.
- تحسين بطاقات مركز القيادة الذكي بحسب حالة الرقم.
- الحفاظ على جميع الميزات والواجهات البرمجية الحالية دون حذف.

---

## v19.2.0

# ALABOUD Business Suite v19.2.0
## Executive Intelligence Center

- بحث عالمي سريع عبر Ctrl + K للعملاء والحوالات والمصروفات.
- رسوم أداء حقيقية لآخر سبعة أيام مبنية على الحوالات المسجلة.
- تصنيف العملاء A/B/C وتحليل الربح وحجم العمليات لكل عميل.
- تحليل أرباح الشهر حسب العملة.
- مقارنة تنفيذية شهرية للحوالات وحجم الأعمال والأرباح والمصروفات.
- تحديث اسم الإصدار مع الحفاظ على جميع الميزات والواجهات السابقة.

---

## v19.1.0

# ALABOUD Business Suite v19.1.0 — مركز المزامنة الذكية

## الإضافات
- مركز مزامنة مباشر يعرض الشركات المفعلة والمستحقة ونتائج اليوم.
- سجل دائم لآخر 500 عملية مزامنة مع المدة والرصيد قبل وبعد.
- مزامنة تلقائية من الواجهة كل دقيقة للشركة التي حان موعدها.
- إعداد مستقل لكل شركة: 1 أو 5 أو 15 أو 30 أو 60 دقيقة.
- اختيار جلب الرصيد فقط أو الرصيد وكشف الحساب.
- الاحتفاظ بآخر رصيد ناجح عند فشل الاتصال.
- لا حذف لأي صفحة أو API أو ميزة سابقة.

---

## v19.0.0

# ALABOUD Business Suite v19.0.0 — Enterprise Dashboard

## الإضافات الجديدة
- لوحة تحكم تنفيذية مباشرة مع تحديث تلقائي كل دقيقة.
- مؤشر صحة الشركة من 100 مع أربع حالات لونية.
- مركز القرارات الذكية المبني على بيانات النظام الفعلية.
- مهام يومية ذكية مبنية على التوصيات والتحصيل والسيولة.
- بطاقات ملونة لصافي الأرباح وصافي الدين ورصيد الصندوق والحوالات والعملاء والمصروفات.
- مؤشرات اتجاه الأرباح الشهرية.
- تحسين الاستجابة للهاتف والكمبيوتر.

## التوافق
- لم يتم حذف أي صفحة أو API أو ميزة حالية.
- لم يتغير هيكل قاعدة البيانات.
- موصلات الشركات وميزات العملاء والحوالات والديون بقيت كما هي.

---

## v18.7.7

# الإصدار v18.7.7

## إضافة الحساب القديم إلى الدين العام

- إضافة المتبقي من الحساب القديم لكل عميل تلقائيًا إلى **دين لنا** في صفحة الدين العام.
- احتساب المبلغ المدفوع من الحساب القديم وإظهار المتبقي فقط ضمن الإجماليات.
- تحديث المجموع تلقائيًا عند تعديل الحساب القديم أو تسجيل دفعة للعميل.
- عدم إضافة الحساب القديم بعد تصفير حساب العميل.
- منع تكرار الدين عبر اشتقاقه مباشرة من بيانات العميل دون إنشاء سجل يدوي منفصل.
- الحفاظ على جميع الميزات السابقة دون حذف.

---

## v18.7.6

# الإصدار v18.7.6

- إصلاح استخراج رصيد تواصل مباشرة من صفوف العملات.
- منع استبدال رصيد الدولار بصفوف عملات أخرى قيمتها صفر.
- دعم المسافات غير المرئية وأسماء الليرة السورية الجديدة.
- جعل رقم الإصدار من ملف مركزي واحد وتحديث عنوان المتصفح تلقائياً.
- لم تُحذف أي ميزة موجودة.

---

## v18.7.5

# إصدار v18.7.5 — إصلاح رصيد شركة تواصل

- إصلاح تصنيف أسماء العملات التي تحتوي على مسافات غير عادية.
- تصنيف «ليرة سورية جديدة» و«ليرة سورية» كعملة SYP.
- تصنيف «ليرة تركية» كعملة TRY.
- منع تصنيف العملات غير المعروفة تلقائيًا كدولار USD.
- تجميع صفوف العملة نفسها بدل استبدال الرصيد السابق.
- إضافة سجل تشخيص لصفوف الرصيد في سجل الخادم.
- الحفاظ على جميع الميزات الحالية دون حذف.

---

## v18.7.4

# الإصدار v18.7.4

- تحسين قراءة رصيد شركة تواصل.
- دعم الأرقام العربية والفواصل العشرية المختلفة.
- دعم إشارة السالب في نهاية الرقم مثل 187.00-.
- قراءة حقول رصيد إضافية دون حذف أي ميزة موجودة.
- تحسين اكتشاف قائمة الأرصدة داخل الاستجابة المتداخلة.

---

## v18.7.2

# الإصدار 18.7.2 — تعديل وحذف الشركات

- إضافة زر **تعديل** لكل شركة في صفحة الشركات والربط الخارجي.
- تحميل بيانات الشركة تلقائيًا إلى نموذج التحرير.
- السماح بتغيير اسم المستخدم وكلمة المرور والرابط ونوع الموصل وبقية البيانات.
- ترك حقل كلمة المرور فارغًا أثناء التعديل يحافظ على كلمة المرور الحالية.
- إضافة زر **حذف** مع نافذة تأكيد.
- حذف الشركة مع الحركات والدفعات المرتبطة بها بعد التأكيد.
- إبقاء موصلي جاد وتواصل دون تغيير.

---

## v18.7.1

# الإصدار 18.7.2 — فصل موصل تواصل عن جاد

- إضافة نوع موصل مستقل `TAWASUL`.
- إبقاء موصل `JAD` دون تغيير.
- تصحيح الشركات القديمة المسماة تواصل التي حُفظت خطأ كـ JAD.
- توجيه اختبار الاتصال والمزامنة إلى موصل تواصل الصحيح.
- استخدام رؤوس طلب مشابهة لتطبيق Android عند الاتصال بواجهة تواصل.
- عرض اسم الموصل المستخدم في جدول الشركات.
- إبقاء `KONTORUN` كاسم قديم متوافق، وتحويله تلقائياً إلى `TAWASUL`.

---

## v18.7.0

# الإصدار 18.7.0

تمت إضافة موصل للتطبيق الجديد المستخرج من ملف APK.

## الوظائف
- تسجيل الدخول إلى واجهة الشركة عبر HTTPS.
- دعم رمز التحقق من تطبيق التوثيق عند طلبه.
- جلب أرصدة العملات من نقطة GA.
- جلب كشف الحساب من نقطة aspro عند توفر رقم العملة/الحساب.
- إدراج الأرصدة الخارجية ضمن صفحة الدين العام.
- إضافة خيار «موصل التطبيق الجديد» في صفحة الشركات والربط الخارجي.

## إعداد الشركة
- الرابط: `https://www.krs47n92t.com`
- الموصل: `موصل التطبيق الجديد — كشف الحساب والرصيد`
- اسم المستخدم وكلمة المرور: بيانات حساب الشركة.
- رقم الحساب الخارجي: رقم العملة المستخدم في كشف الحساب، وغالبًا يبدأ بـ `1`.
- رمز Authenticator: يُكتب عند الاختبار أو جلب الرصيد إذا طلبه الخادم.

تم بناء واجهة React ونسخها إلى `backend/public`. تم فحص صياغة خادم Node. لم يُختبر تسجيل الدخول الحقيقي لعدم توفر بيانات حساب المستخدم ورمز التحقق.

---

## v18.6.30

# إصدار الويب 18.6.30

- توحيد اتصال زر تفعيل البصمة مع تطبيق Android.
- دعم أسماء الجسر الجديدة والقديمة تلقائيًا.
- عرض رسالة الخطأ الحقيقية عند عدم توفر الجسر أو استخدام تطبيق قديم.
- مزامنة حالة البصمة عند فتح صفحة الإعدادات.

---

## v18.6.28

# الإصدار v18.6.28

- إظهار زر تفعيل البصمة أو الوجه داخل تطبيق Android بشكل واضح.
- تحسين اكتشاف جسر Android حتى لا تظهر عبارة «متاح داخل تطبيق الهاتف فقط» بالخطأ.
- إضافة رسالة واضحة عند الحاجة إلى تحديث التطبيق.
- تحديث رقم إصدار تطبيق Android وواجهة الويب.

---

## v18.6.27

# الإصدار v18.6.27

- إصلاح حذف المصروف فعليًا من قاعدة البيانات.
- إصلاح تعديل المصروف وحفظ القيم الجديدة فعليًا.
- سبب المشكلة كان تعديل نسخة مرشحة من بيانات الشركة بدل المصفوفة الأصلية متعددة الشركات.
- الإبقاء على ميزة الدخول بالبصمة أو الوجه من الإصدار السابق.

---

## v18.6.26

# الإصدار v18.6.26

- إضافة زر تفعيل الدخول بالبصمة أو الوجه داخل صفحة الإعدادات.
- طلب تأكيد هوية المستخدم عند التفعيل.
- حفظ رمز الدخول مشفرًا داخل الهاتف.
- إضافة زر تعطيل البصمة أو الوجه.
- إظهار زر الدخول البيومتري في شاشة تسجيل الدخول فقط بعد التفعيل.
- العودة لتسجيل الدخول العادي عند عدم تفعيل الميزة.

---

## v18.6.25

# الإصدار v18.6.25

- إضافة زر تعديل لكل مصروف.
- إضافة زر حذف مع رسالة تأكيد.
- تحديث إجماليات المصروفات مباشرة بعد التعديل أو الحذف.
- إضافة سجل تدقيق لعمليات التعديل والحذف.

---

## v18.6.24

# الإصدار v18.6.24

- قصر أرصدة الدين الخارجي القادمة من جاد على USD وEUR فقط.
- تجاهل SYP وTRY وأي عملة أخرى في جدول الدين الخارجي.
- الإبقاء على تحديد الاتجاه من نص البطاقة: لكم = دين لنا، عليكم = دين علينا.

---

## v18.6.23

# الإصدار v18.6.23 — قراءة «لكم / عليكم» من بطاقات جاد

- يقرأ اتجاه كل رصيد من النص الظاهر داخل بطاقة جاد.
- «لكم» تُسجل في دين لنا.
- «عليكم» تُسجل في دين علينا.
- يمنع انتقال كلمة الاتجاه من بطاقة مجاورة إلى عملة أخرى.
- لا يعتمد على إشارة الرقم الموجب أو السالب لتحديد جهة الدين.

---

## v18.6.22

# الإصدار v18.6.22 — إصلاح اتجاه أرصدة جاد

## الإصلاح
- منع تكرار رصيد جاد نفسه في عمودي **دين لنا** و**دين علينا**.
- عندما يلتقط المحلل القيمة نفسها في الجهتين، تُحفظ مرة واحدة في الجهة الصحيحة بدل ظهور صافي صفر.
- إضافة طبقة حماية ثانية قبل حفظ نتيجة المزامنة في قاعدة البيانات.
- تحديث بطاقات الإجمالي والصافي من الأرصدة المصنفة بعد التطبيع.

## النتيجة المتوقعة
مثال رصيد USD بقيمة 54,981.00:
- دين لنا: 54,981.00
- دين علينا: 0.00
- الصافي: 54,981.00

---

## v18.6.21

# ALABOUD Business Suite Enterprise v18.6.21

- إعادة تسمية زر المزامنة إلى «جلب الرصيد» بشكل واضح.
- إضافة زر «جلب جميع الأرصدة» أعلى صفحة الشركات.
- إعادة محاولة تسجيل الدخول تلقائيًا بجلسة جديدة إذا رفض جاد الجلسة المحفوظة.
- تقليل حالات الرفض الخاطئ لصفحة الدخول بعد نجاح المصادقة.
- الحفاظ على آخر رصيد ناجح عند تعذر الاتصال المؤقت.

---

## v18.6.20

# AlAboud Business Suite v18.6.20

## إصلاح رابط جاد وجلب الرصيد

- قبول رابط جاد الكامل سواء انتهى بـ `/`, أو `/log`, أو `/pl.m`, أو `/account`.
- استخراج مسار تثبيت جاد تلقائيًا من الرابط بدل الاعتماد الكامل على المسار الافتراضي.
- استخدام الرابط المستخرج نفسه في موصل المتصفح وموصل HTTP.
- الإبقاء على جلسة جاد المحفوظة وآخر رصيد ناجح عند فشل تحديث مؤقت.
- تحديث رقم الإصدار في الواجهة والخادم وملفات الحزم.

> جلب الرصيد الحقيقي يحتاج اختبارًا على Render ببيانات جاد ورمز Authenticator صالح عند طلبه.

---

## v18.6.19

# الإصدار v18.6.19 — مزامنة جاد بجلسة محفوظة

- حفظ جلسة جاد الآمنة بعد أول تسجيل دخول ناجح.
- إعادة استخدام الجلسة في زر «مزامنة الآن» بدون طلب رمز Authenticator كل مرة ما دامت الجلسة صالحة.
- إذا انتهت الجلسة، تُحذف تلقائياً ويطلب البرنامج رمز Authenticator جديداً في المحاولة التالية.
- لا يتم إرسال بيانات الجلسة إلى الواجهة؛ تُحفظ مشفرة ضمن بيانات الشركة.
- الحفاظ على آخر أرصدة ناجحة عند الفشل المؤقت.

---

## v18.6.18

# الإصدار v18.6.18 — أسباب فشل المزامنة الواضحة

- عرض سبب فشل المزامنة للمستخدم بدل الرسالة العامة.
- تمييز انتهاء جلسة جاد، رفض بيانات الدخول، طلب رمز Authenticator، مهلة الاتصال، وتعذر الوصول إلى الموقع.
- عدم احتساب الاستجابة القديمة (stale) كمزامنة ناجحة.
- الاحتفاظ بآخر رصيد ناجح مع إظهار تاريخ آخر مزامنة.
- إبقاء التفاصيل التقنية الكاملة داخل Console وRender Logs.

---

## v18.6.17

# الإصدار v18.6.17 — مزامنة الآن والوقت النسبي

- إضافة زر **مزامنة الآن** أعلى صفحة الشركات.
- مزامنة جميع شركات جاد مباشرة دون إعادة تحميل الصفحة.
- مؤشر تحميل أثناء المزامنة.
- عرض آخر مزامنة بصيغة: الآن، قبل دقيقة، قبل ساعات.
- الاحتفاظ بالتاريخ والوقت الكامل أسفل الوقت النسبي.
- الاحتفاظ بآخر رصيد ناجح عند تعذر التحديث مؤقتًا.

---

## v18.6.16

# الإصدار v18.6.16 — حالة المزامنة الناجحة النظيفة

- لا تظهر كلمة `failure` للمستخدم عندما توجد مزامنة ناجحة سابقة وحالة الشركة متصل.
- زر عرض سجل الربط يعرض آخر وقت مزامنة ناجحة بصورة مختصرة.
- تبقى التفاصيل التقنية في Console وRender Logs فقط.
- لا يتم تغيير أو تصفير آخر أرصدة ناجحة عند فشل محاولة مؤقتة.

---

## v18.6.15

# الإصدار v18.6.15 — تثبيت آخر رصيد ناجح

- لا يتم تصفير أرصدة جاد عند انتهاء رمز OTP أو تعذر الاتصال المؤقت.
- يحتفظ النظام بآخر أرصدة ناجحة لجميع العملات.
- تبقى حالة الشركة «متصل» عند وجود مزامنة ناجحة سابقة.
- تعرض الواجهة تنبيهًا مختصرًا بأن آخر رصيد ناجح محفوظ مع وقت المزامنة.
- يعاد تحميل جدول الشركات بعد المحاولة لإظهار القيم المحفوظة فورًا.

---

## v18.6.14

# الإصدار v18.6.14 — تنظيف واجهة ربط جاد

- إصلاح تعريف أعلام العملات في صفحة الشركات.
- منع ظهور مسارات Chromium وصفحات جاد وسجل التشخيص الطويل داخل الواجهة.
- عرض رسائل عربية مختصرة عند فشل الدخول أو المزامنة.
- إبقاء التفاصيل التقنية في Console وRender Logs فقط.
- عرض ملخص قصير عند الضغط على «عرض سجل الربط» دون فتح صفحة جديدة.
- الحفاظ على أرصدة العملات المتعددة داخل سجل الشركة.

---

## v18.6.13

# الإصدار v18.6.13 — إصلاح أعلام العملات

- إصلاح الخطأ `flagOf is not defined` في صفحة الشركات.
- إعادة تشغيل صفحة الشركات وأرصدة العملات المتعددة دون تعطل.
- دعم أعلام USD وCAD وEUR وTRY وSYP وSAR وJOD وGBP وAED.
- المحافظة على جميع ميزات الإصدار v18.6.12.

---

## v18.6.12

# الإصدار v18.6.12 — أرصدة متعددة العملات للشركات

- أبقى خيار العملة في نموذج الشركة بوصفه العملة الأساسية فقط.
- أضاف عمود «أرصدة العملات» داخل جدول الشركات.
- يعرض USD وEUR وبقية العملات في سجل الشركة نفسه.
- يعرض لكل عملة: دين لنا، دين علينا، والصافي.
- يعتمد القيم المحفوظة في `externalBalances` القادمة من موصل جاد.
- يحافظ على التوافق مع الشركات القديمة ذات العملة الواحدة.

---

## v18.6.11

# الإصدار v18.6.11 — قارئ اليورو النهائي من جاد

- قراءة بطاقات العملات من جميع الإطارات داخل صفحة جاد.
- انتظار تحميل بطاقات العملات المتأخرة قبل الانتقال إلى كشف الحساب.
- دعم النمط: `8,857 [أيقونة الاتحاد الأوروبي] يورو لكم`.
- الحفاظ على مزامنة USD والعملات الأخرى دون تغيير.
- تسجيل نتيجة العملات المكتشفة في سجل التشخيص.

---

## v18.6.10

# الإصدار v18.6.10 — إصلاح قراءة عملات لوحة جاد

- تحسين قراءة بطاقات العملات التي تحتوي على أعلام أو رموز بين الرقم واسم العملة.
- دعم قراءة اليورو والدولار وبقية العملات من النص الحي للوحة جاد.
- دعم الأرقام العربية والفواصل العربية.
- انتظار تحميل بطاقات لوحة جاد قبل استخراج الأرصدة.
- إضافة تشخيص مختصر للقيم المكتشفة.

---

## v18.6.9

# الإصدار v18.6.9 — مزامنة جميع عملات جاد

- قراءة بطاقات العملات من صفحة جاد بعد تسجيل الدخول.
- دعم USD وEUR وTRY وSYP وCAD وSAR وJOD وAED وGBP.
- حفظ دين لنا ودين علينا لكل عملة بشكل مستقل.
- إظهار اليورو وباقي العملات في صفحة الدين العام.
- إعادة حساب صافي الديون النهائي بعد التحويل إلى CAD.
- توافق مع البيانات القديمة ذات العملة الواحدة.

---

## v18.6.8

# الإصدار v18.6.8 — صافي الديون متعدد العملات

- تحويل دين لنا ودين علينا لكل العملات إلى العملة الأساسية CAD.
- عرض صافي الديون النهائي في البطاقات العلوية.
- الإبقاء على تفاصيل كل عملة مستقلة أسفل الصفحة.
- استخدام أحدث سعر بيع متاح مع دعم التحويل العكسي والمسارات الوسيطة.
- تنبيه واضح عند عدم توفر سعر صرف لإحدى العملات.

---

## v18.6.7

# الإصدار v18.6.7 — ديون الشركات الخارجية حسب العملة

- يعتمد الدين العام على `externalReceivable` و`externalPayable` الفعليين القادمين من موصل الشركة.
- يظهر دين جاد في بطاقة عملة حساب الشركة الأصلية (مثل USD) دون تحويله أو خلطه مع CAD.
- `externalReceivable` يظهر ضمن دين لنا، و`externalPayable` يظهر ضمن دين علينا.
- لا يُستخدم الرصيد الخارجي الموقّع كدين عند توفر القيم التفصيلية، لمنع ظهور رقم الرصيد بدل مبلغ الدين.
- دعم توافق تلقائي مع السجلات القديمة التي تحتوي فقط على `externalBalance`.

---

## v18.6.6

# الإصدار v18.6.6 — تثبيت حالة الاتصال

- عند نجاح جلب الرصيد تُعرض الحالة **متصل**.
- مسح حالة الخطأ بعد كل مزامنة ناجحة.
- فشل اختبار اتصال مؤقت أو انتهاء رمز OTP لا يمحو آخر مزامنة ناجحة ولا يحول الشركة إلى خطأ.
- يبقى الخطأ محفوظًا في سجل التشخيص فقط.
- الواجهة تعتمد آخر مزامنة ناجحة والرصيد الخارجي لتحديد الحالة الفعلية.

---

## v18.6.5

# الإصدار v18.6.5 — إعادة الاتصال دون فتح صفحة جاد

- منع فتح لقطة التشخيص أو صفحة تسجيل الدخول في تبويب جديد عند عرض سجل الربط.
- تنفيذ اختبار الاتصال والمزامنة داخل الخلفية فقط.
- مسح لقطات وأخطاء التشخيص القديمة بعد نجاح الاتصال أو المزامنة.
- إبقاء المستخدم داخل صفحة الشركات مع رسالة نجاح أو خطأ واضحة.

---

## v18.6.4

# الإصدار v18.6.4 — ربط الرصيد الخارجي بالدين العام

- إظهار رصيد الشركة الخارجي تلقائيًا في صفحة الدين العام.
- الرصيد السالب يظهر ضمن **دين علينا**.
- الرصيد الموجب يظهر ضمن **دين لنا**.
- يتم تحديث نفس الصف تلقائيًا عند كل مزامنة دون إنشاء ديون مكررة.
- يعتمد الصف على عملة حساب الشركة وتاريخ آخر مزامنة.

---

## v18.6.3

# الإصدار v18.6.3 — التحقق من جلسة جاد واكتشاف كشف الحساب

- منع اعتبار صفحة تسجيل الدخول جلسة ناجحة إذا رفض جاد كلمة المرور أو رمز التحقق.
- تجربة صفحة `pl.m` الموثقة داخل الجلسة قبل البحث العام.
- توسيع اكتشاف نماذج كشف الحساب وأسماء حقول التاريخ والعملة.
- تحسين التشخيص عند رفض بيانات الدخول.

---

## v18.6.2

# الإصدار v18.6.2 — اكتشاف صفحة كشف حساب جاد

- استخدام نموذج كشف الحساب الموجود في صفحة الدخول الناجح قبل الانتقال لأي مسار آخر.
- اكتشاف روابط كشف الحساب وترتيبها تلقائيًا بدل الاعتماد على `/account` فقط.
- رفض أي مسار يعيد صفحة تسجيل الدخول.
- تسجيل النماذج والروابط المرشحة في سجل التشخيص.

---

## v18.6.1

# الإصدار v18.6.1 — إرسال نموذج جاد مباشرة

- إلغاء الضغط على زر Save المعطّل نهائيًا.
- إرسال نموذج كشف الحساب الحقيقي من جلسة Chromium الموثقة.
- الحفاظ على الحقول المخفية والحقول المعطلة واسم/قيمة زر الإرسال.
- تسجيل صلاحية كل حقل والبيانات المرسلة للتشخيص.

---

## v18.6.0

# الإصدار v18.6.0 — إصلاح زر نموذج جاد المعطّل

- تجاوز زر البحث المعطّل في نموذج كشف الحساب لدى جاد بطريقة آمنة.
- الحفاظ على اسم وقيمة زر الإرسال داخل الطلب.
- استخدام الإرسال البرمجي للنموذج الحقيقي عندما يمنع الموقع النقر على الزر.
- إبقاء التشخيص الكامل لتتبع أي خطأ لاحق.

---

## v18.5.9

# الإصدار v18.5.9 — تشخيص جاد الكامل

- عرض رسالة تشغيل Chromium الأصلية بدل التحذير العام.
- تسجيل مسار Chromium وهل الملف موجود على Render.
- تسجيل إصدار Playwright وبيئة التشغيل.
- تسجيل stack trace والسبب الداخلي للفشل.
- إيقاف الرجوع التلقائي إلى موصل HTTP افتراضياً حتى لا يُخفى خطأ المتصفح.
- إعادة تفاصيل التشخيص إلى الواجهة وRender Logs.

---

## v18.5.8

# الإصدار v18.5.8 — إرسال نموذج جاد الحقيقي

- إصلاح تفسير الحقل `confirm`: لم يعد يُستخدم كرقم حساب.
- تعبئة نموذج كشف الحساب الحقيقي داخل صفحة جاد.
- الحفاظ على الحقول المخفية والرموز الديناميكية.
- إرسال النموذج بالطريقة الأصلية للمتصفح، مع إعادة محاولة آمنة.
- اختيار رقم الحساب فقط من حقل حساب/عميل فعلي.

---

## v18.5.7

# الإصدار v18.5.7 — تشخيص جاد وإعادة المحاولة

- إعادة محاولة طلب كشف الحساب ثلاث مرات بعد اكتمال الجلسة.
- انتظار networkidle قبل فتح الحساب.
- حفظ لقطة شاشة وHTML تشخيصي عند الفشل داخل مساحة مؤقتة محمية.
- إضافة زر عرض سجل الربط داخل صفحة الشركات.
- عرض مراحل تسجيل الدخول والتحويل وطلب الحساب برسائل أوضح.
- إخفاء اسم المستخدم وأكواد OTP من السجل التشخيصي.

---

## v18.5.6

# الإصدار v18.5.6 — تثبيت Chromium داخل المشروع على Render

- تثبيت Chromium داخل `backend/node_modules/playwright-core/.local-browsers` عبر `PLAYWRIGHT_BROWSERS_PATH=0`.
- تنفيذ تنزيل Chromium صراحة أثناء `render-build` بدل الاعتماد على postinstall فقط.
- إضافة متغير Render `PLAYWRIGHT_BROWSERS_PATH=0`.
- إبقاء موصل جاد على وضع browser وتعطيل HTTP fallback.

---

## v18.5.2

# الإصدار v18.5.2 — ربط جاد مع Google Authenticator

- إضافة حقل رمز Google Authenticator بجانب شركة جاد.
- إرسال الرمز مرة واحدة فقط أثناء اختبار الاتصال أو المزامنة، دون حفظه في قاعدة البيانات.
- اكتشاف شاشة التحقق في موقع جاد وتعبئة الرمز آليًا داخل جلسة Chromium.
- رسالة واضحة عند الحاجة إلى رمز جديد أو عند انتهاء صلاحيته.
- تحديث واجهة الشركات وحالة الإصدار وقناة الفحص الصحي.

---

## v18.5.1

# الإصدار 18.5.1 — إصلاح ربط جاد على Render

- استبدال `playwright-chromium` بحزمة `playwright`.
- تنزيل Chromium تلقائياً أثناء تثبيت backend عبر `postinstall`.
- إجبار موصل جاد على وضع المتصفح في إعدادات Render.
- تعطيل الانتقال التلقائي إلى موصل HTTP عند غياب Chromium، حتى يظهر الخطأ الحقيقي بوضوح.
- تحديث استدعاء Playwright داخل الخادم.

بعد رفع المشروع إلى GitHub، نفّذ في Render: **Manual Deploy → Clear build cache & deploy**.

---

## v18.5.0

# إصدار v18.5.0 — إصلاح Render وموصل جاد عبر Playwright

- تصحيح React وReact DOM إلى الإصدار الموجود 18.3.1.
- إزالة ملفات package-lock القديمة التي كانت تشير إلى إصدارات وروابط غير صالحة.
- تغيير تثبيت Render من npm ci إلى npm install لإعادة إنشاء قفل صحيح من npm الرسمي.
- تحسين انتظار انتقال صفحة تسجيل الدخول في موصل جاد عبر Playwright.
- إزالة خيار Chromium الأحادي العملية الذي قد يسبب انهيار المتصفح على Render.
- تحديث رقم الإصدار إلى 18.5.0.

## النشر
استخدم Manual Deploy ثم Clear build cache & deploy على Render بعد دفع التغييرات.

---

## v18.4.1

# الإصدار v18.4.1

- إصلاح روابط Playwright داخل package-lock لتستخدم registry.npmjs.org بدل رابط داخلي غير متاح على Render.
- تثبيت playwright-chromium على 1.61.1 بشكل صريح.
- إضافة .npmrc في جذر المشروع لاستخدام سجل npm الرسمي.

---

## v18.4.0

# إصدار 18.4.0 — موصل جاد عبر متصفح حقيقي

## التحديثات
- إضافة موصل Playwright/Chromium لتسجيل الدخول إلى جاد بجلسة متصفح حقيقية.
- فتح صفحة `pl.m` ثم صفحة الدخول، تعبئة `mail` و`pass`، وترك رمز `tok` المرتبط بالجلسة كما يولده الموقع.
- فتح صفحة الحساب وكشف الحساب داخل نفس سياق المتصفح والكوكيز.
- الاحتفاظ بالموصل HTTP القديم كخيار احتياطي عند تعذر تشغيل Chromium فقط.
- متغيرات اختيارية: `JAD_CONNECTOR_MODE=browser|http` و `JAD_HTTP_FALLBACK=true|false`.
- لم تُحذف أي بيانات أو ميزات موجودة.

## Render
أمر البناء المعتاد `npm run render-build` يثبت `playwright-chromium` ويحمّل Chromium تلقائياً. قد يكون البناء الأول أطول من المعتاد.

---

## v18.3.10

# الإصدار v18.3.10 — إصلاح تدفق جلسة جاد

- تهيئة جلسة جاد عبر صفحة `pl.m` قبل فتح نموذج الدخول.
- الحفاظ على جميع ملفات Cookies أثناء التحويلات.
- تحديث ترويسة Referer تلقائياً مع كل Redirect لمحاكاة المتصفح.
- دعم نماذج الانتقال الوسيطة التي تحتوي على حقول hidden وأزرار submit آمنة.
- زيادة عدد خطوات متابعة ما بعد تسجيل الدخول.
- الحفاظ على قاعدة البيانات وجميع الميزات الحالية دون حذف بيانات.

---

## v18.3.9

# الإصدار 18.3.9

## إصلاح ربط شركة جاد

- قراءة نموذج تسجيل الدخول الحقيقي وحقوله المخفية بدل الاعتماد على مسار ثابت فقط.
- إرسال رمز `tok` المرتبط بنفس جلسة PHP.
- متابعة تحويلات HTTP وتحويلات JavaScript وMeta Refresh.
- إكمال نماذج POST المخفية الآمنة بعد تسجيل الدخول.
- تهيئة جلسة الفرع عبر `log_2` قبل فتح صفحة الحساب.
- إعادة محاولة فتح الحساب مرة واحدة عند عودة الموقع إلى صفحة الدخول.
- تحسين رسائل الخطأ وسجل التشخيص دون طباعة كلمة المرور أو قيم ملفات الارتباط.

لا يتم حذف أو تغيير بيانات PostgreSQL.

---

## v18.3.8

# الإصدار 18.3.8

- إصلاح فحص جلسة جاد لتجنب اعتبار نصوص JavaScript أو زر غير تابع لتسجيل الدخول كجلسة منتهية.
- إرسال النموذج الوسيط فقط عندما تكون جميع حقوله مخفية وآمنة.
- استخدام ترويسات المتصفح عند فتح صفحة الحساب.
- الحفاظ على نفس ملفات الارتباط خلال جميع التحويلات.

---

## v18.3.7

# إصدار 18.3.7 — إصلاح انتهاء جلسة جاد

- منع إرسال نموذج تسجيل الخروج الموجود في صفحة `log_2` بالخطأ.
- اختيار نموذج إكمال تسجيل الدخول الحقيقي فقط.
- تجاهل نماذج تسجيل الدخول والخروج والتنقل.
- دعم الحقول المخفية والقوائم وزر الإرسال في نموذج إكمال الجلسة.
- المحافظة على Cookies وجلسة PHP نفسها حتى جلب كشف الحساب.

بعد رفع النسخة إلى Render اضغط **جلب الرصيد** من صفحة الشركات.

---

## v18.3.6

# الإصدار v18.3.6

- حفظ جميع Cookies الخاصة بجاد وليس PHPSESSID فقط.
- دعم Set-Cookie المتعدد وملفات Cloudflare.
- تنفيذ نموذج POST الوسيط في صفحة log_2 تلقائيًا.
- استخدام نفس Cookie Jar حتى صفحة account وكشف الحساب.
- الحفاظ على البيانات السابقة وقاعدة PostgreSQL.

---

## v18.3.5

# ALABOUD Business Suite v18.3.5

- جلب رمز الحماية `tok` مباشرة من صفحة `/log`.
- الاحتفاظ بنفس جلسة `PHPSESSID` بين GET وPOST.
- إرسال الحقول `mail`, `pass`, `tok`, `btn-login` تماماً مثل المتصفح.
- استخدام Referer الصحيح `/log` ومتابعة التحويل إلى `/log_2`.
- تحسين التحقق من نجاح تسجيل الدخول بدون نتائج رفض خاطئة.
- الحفاظ على بيانات PostgreSQL والشركات الحالية.

```bash
npm install
npm run render-build
git add .
git commit -m "v18.3.5 fix Jad CSRF token login"
git push origin main
```

---

## v18.3.4

# ALABOUD Business Suite v18.3.4

## إصلاح موصل شركة جاد

- متابعة تحويلات HTTP 301 و302 و303 و307 و308 تلقائيًا.
- الاحتفاظ بملف جلسة PHPSESSID أثناء جميع خطوات تسجيل الدخول.
- فتح صفحة الحساب بعد الدخول لتهيئة جلسة كشف الحساب.
- إرسال Origin وReferer وبيانات النموذج بالشكل المناسب.
- التحقق من رفض تسجيل الدخول أو انتهاء الجلسة برسائل عربية واضحة.
- إبقاء رقم الحساب اختياريًا لشركة جاد ومتاحًا للشركات الأخرى.
- الحفاظ على بيانات PostgreSQL وعدم حذف الشركات أو السجلات الحالية.

## أوامر النشر

```bash
npm run render-build
git add .
git commit -m "v18.3.4 fix Jad redirects and session cookies"
git push origin main
```

---

## v18.3.2

# ALABOUD Business Suite v18.3.3

## الإصلاحات
- إصلاح انهيار الخادم `Maximum call stack size exceeded` في `backend/src/store.js`.
- منع تكرار Proxy الخاص ببيانات الشركات داخل سياق الشركة.
- ضمان التعامل مع المخزن الأصلي عند الحفظ والقراءة.
- الحفاظ على بيانات الشركات الموجودة في PostgreSQL.
- تحديث رقم الإصدار إلى v18.3.3.
- إعادة بناء واجهة الإنتاج بنجاح.

## النشر
```bash
npm run render-build
git add .
git commit -m "v18.3.3 fix company store recursion"
git push origin main
```

---

## v18.3.1

# الإصدار v18.3.3

- إصلاح خطأ Maximum call stack size exceeded في صفحة الشركات.
- تحديث رقم الإصدار في الواجهة والإعدادات والقائمة الجانبية.
- الإبقاء على رقم الحساب كحقل اختياري للشركات التي تحتاجه.
- شركة جاد لا تشترط رقم الحساب وتستخدم بيانات تسجيل الدخول.
- الحفاظ على البيانات والميزات السابقة.

---

## v18.3.0

# إصدار 18.3.0 — ربط شركة جاد وجلب الرصيد

- إضافة موصل فعلي لشركة جاد.
- تسجيل الدخول الآمن باستخدام الجلسة ورمز tok.
- جلب كشف الحساب من accountprint.php وقراءة جدول HTML.
- تحديث دين لنا ودين علينا والرصيد الخارجي ضمن مجموع الديون.
- إضافة زر «جلب الرصيد الآن» وحالة الاتصال وآخر مزامنة.
- تشفير كلمة مرور الشركة داخل التخزين.
- لا يتم حذف أي بيانات حالية.

---

## v18.2.0

# ALABOUD Business Suite v18.2.0

## نظام الشركات والربط الخارجي

- إضافة شركة مع رابط النظام ونوع الربط: Web أو API أو CSV أو Excel أو PDF.
- ظهور الشركة مباشرة في قسم الشركات بعد الحفظ.
- إظهار حالة إعداد الرابط وزر اختبار صيغة الرابط.
- الاحتفاظ بالحساب اليدوي للشركات: دين لنا، دين علينا، الدفعات، وكشف الحساب.
- إدخال أرصدة الشركات تلقائيًا ضمن صفحة الدين العام ومجاميع دين لنا ودين علينا لكل عملة.
- تمييز مصدر الدين داخل الجدول: يدوي، حوالة، أو شركة.
- لا يتم حذف أو تحويل البيانات القديمة، والحقول الجديدة اختيارية ومتوافقة مع الشركات الموجودة.

## ملاحظة الربط
اختبار الرابط الحالي يتحقق من صحة الرابط وإعداده. المزامنة الفعلية تحتاج موصلًا خاصًا حسب API أو تنسيق كل شركة، وذلك لمنع استخدام بيانات دخول غير آمنة أو ربط غير موثوق.

---

## v18.1.0

# ALABOUD Business Suite v18.1.0

- تحقق بخطوتين TOTP عبر Google Authenticator أو Microsoft Authenticator.
- صفحة تفعيل وتعطيل 2FA داخل الإعدادات.
- شاشة إدخال رمز التحقق بعد كلمة المرور.
- دخول بالبصمة أو الوجه داخل تطبيق Android.
- تخزين رمز الدخول الحيوي داخل EncryptedSharedPreferences.
- رمز حيوي منفصل صالح 30 يومًا ويُستبدل بجلسة عادية عند الدخول.
- تعطيل النسخ الاحتياطي غير المشفر لتطبيق Android.
- الحفاظ على قاعدة البيانات والبيانات الحالية.

---

## v18.0.0

# ALABOUD Business Suite v18.0.0 Fortress Security

إصدار أمني فعلي يضيف: تجزئة كلمات المرور بـ scrypt، ترقية تلقائية من bcrypt، قفل الحساب، تحديد معدل الطلبات، جلسات JWT لمدة 12 ساعة مع issuer/audience، رؤوس أمان CSP/HSTS، حد أصغر للطلبات، سجل تدقيق مترابط بالتجزئة، نسخ احتياطية مشفرة AES-256-GCM، ولوحة API لحالة الأمان.

## متغيرات الإنتاج المطلوبة
- NODE_ENV=production
- JWT_SECRET قيمة عشوائية قوية لا تقل عن 64 حرفاً
- DATABASE_URL اتصال PostgreSQL المشفر

## ملاحظة
حساب المدير الافتراضي يجب تغيير كلمته فور أول دخول. الحماية تقلل المخاطر ولا تجعل أي نظام غير قابل للاختراق بنسبة 100%.

---

## v17.2.0

# ALABOUD Business Suite v17.2.0 AI Ultimate

- إضافة مركز القيادة الذكي كخيار واضح في القائمة.
- إضافة زر AI عائم للوصول السريع من جميع الصفحات.
- إضافة مخطط أداء لآخر 6 أشهر.
- إضافة مركز القرارات مع إجراءات مباشرة.
- الإبقاء على لوحة التحكم والبيانات والميزات السابقة دون حذف.

---

## v17.1.0

# إصدار ALABOUD Business Suite Enterprise v17.1.0 AI

## الجديد
- المحافظة الكاملة على لوحة التحكم المعتمدة في الإصدار السابق دون تغيير تصميمها.
- إضافة مركز القيادة الذكي ALABOUD AI داخل القائمة وزر عائم في جميع الصفحات.
- تقييم صحة الشركة من 100 اعتمادًا على الأرباح والسيولة والديون والمصروفات.
- تحليل يومي وشهري للأرباح والمصروفات والديون ورأس المال.
- اكتشاف المصروفات المكررة والمصروفات غير الاعتيادية والديون المتأخرة.
- توصيات عملية تلقائية لتحصيل الديون وتقليل المصروفات وتحسين السيولة.
- توقع تقريبي لصافي الشهر القادم اعتمادًا على متوسط آخر ستة أشهر.
- مساعد عربي ذكي للأسئلة عن الأرباح والمصروفات والديون والعملاء والحوالات.
- بحث ذكي في العملاء وأحدث الحوالات.
- إدخال صوتي عربي في المتصفحات التي تدعم Speech Recognition.
- مراقبة حالة قاعدة البيانات وعدد المستخدمين والأجهزة النشطة.
- ربط مباشر بصفحة النسخ الاحتياطي والإعدادات.
- الحفاظ على جميع البيانات وقاعدة البيانات والميزات السابقة.

## ملاحظة
التحليل الحالي يعمل محليًا على بيانات الشركة دون إرسالها إلى خدمة خارجية. يمكن لاحقًا ربط مزود ذكاء اصطناعي خارجي بمفتاح API اختياري.

---

## v17.0.1

# ALABOUD Business Suite Enterprise v17.0.1

- إعادة لوحة التحكم إلى تصميم الإصدار السابق المطلوب.
- إضافة تسجيل المصروفات بجميع العملات مع أعلام العملات.
- حفظ المبلغ الأصلي وسعر التحويل والقيمة المعتمدة بالدولار الكندي.
- احتساب المصروفات في الأرباح والميزانية والتقارير باستخدام قيمة CAD.
- الحفاظ على جميع البيانات والميزات السابقة دون حذف.

---

## v17.0.0

# ALABOUD Business Suite Enterprise v17.0.0

- واجهة دخول فاخرة أسود وذهبي.
- إضافة الموافقة على سياسة الخصوصية وشروط الاستخدام.
- إدارة المستخدمين من الإعدادات: عرض، صلاحيات، تفعيل وتعطيل.
- إدارة الأجهزة والتراخيص: معرّف تثبيت، نوع الجهاز، الإصدار، أول وآخر اتصال، وتعطيل الجهاز.
- تسجيل آخر دخول وسجل تدقيق للعمليات الإدارية.
- الحفاظ على قاعدة البيانات والميزات السابقة بالكامل.

---

## v16.0.18_LOGIN

# ALABOUD Business Suite Enterprise v16.0.18

## التعديل التصحيحي
- إعادة لوحة التحكم إلى تصميم الإصدار v16.0.17.
- تصميم واجهة تسجيل دخول جديدة باللون الأسود والذهبي.
- تحسين واجهة إنشاء حساب شركة جديد.
- الحفاظ على ميزة تصفير حساب العميل وجميع الميزات السابقة.
- لم يتم حذف أو إعادة تهيئة بيانات العملاء أو الحوالات أو الديون.

---

## v16.0.18

# ALABOUD Business Suite Enterprise v16.0.18

- إعادة تصميم الواجهة الرئيسية بنمط أسود وذهبي فاخر.
- بطاقة شعار الشركة ورقم الإصدار في أعلى الصفحة.
- بطاقات ملخص للأرباح والحوالات والعملاء المتأخرين والديون.
- قائمة رئيسية ببطاقات كبيرة متجاوبة للهاتف والكمبيوتر.
- الحفاظ على جميع الصفحات والبيانات والميزات السابقة.

---

## v16.0.17

# ALABOUD Business Suite Enterprise v16.0.17

## ميزة تصفير حساب العميل
- إضافة زر «تصفير الحساب» لكل عميل.
- يبدأ الحساب الجديد من صفر ولا يعرض الحوالات أو الدفعات السابقة.
- حفظ ملخص الحساب السابق داخل أرشيف التصفير دون حذف أي بيانات.
- كشف الحساب والصورة والواتساب يعرضون الحساب الحالي فقط بعد التصفير.
- إظهار تاريخ بداية الحساب الجديد بجانب العميل.
- رفع رقم إصدار الويب وتطبيق Android إلى 16.0.17.

## حماية البيانات
- لا يتم حذف العملاء أو الحوالات أو الدفعات القديمة.
- التصفير يضع نقطة بداية جديدة فقط ويحفظ لقطة من الرصيد السابق للمراجعة.

---

## v16.0.16

# ALABOUD Business Suite Enterprise v16.0.16

## التحديثات
- إضافة زر **تعديل** بجانب كل عميل في صفحة العملاء.
- إضافة زر **حذف** بجانب كل عميل مع رسالة تأكيد قبل الحذف.
- الحذف آمن: يتم إخفاء العميل من القائمة مع الحفاظ على جميع الحوالات والدفعات والسجلات المالية المرتبطة به.
- تحسين عرض صف العميل على الكمبيوتر والهاتف.
- إصلاح نطاق متغير العملات المستخدم في صفحة الميزانية.
- رفع رقم الإصدار إلى v16.0.16.

## حماية البيانات
لا يتم حذف السجلات المالية أو قاعدة البيانات، ولا تتم إعادة تهيئة البيانات.

---

## v16.0.15

# ALABOUD Business Suite Enterprise v16.0.15

## التعديل الجديد
- إضافة قسم في صفحة **الدين العام** يعرض مجموع الديون لكل عملة بشكل منفصل.
- عرض **دين لنا** و**دين علينا** و**صافي الدين** لكل عملة.
- إضافة أعلام العملات: USD 🇺🇸، CAD 🇨🇦، EUR 🇪🇺، TRY 🇹🇷، SYP 🇸🇾، SAR 🇸🇦، JOD 🇯🇴.
- إضافة العلم بجانب العملة داخل جدول الديون.
- تحديث المجاميع تلقائيًا عند إضافة الدين أو تسجيل دفعة.
- الحفاظ على جميع البيانات الحالية دون حذف أو إعادة تهيئة.

---

## v16.0.14

# ALABOUD Business Suite Enterprise v16.0.14

- دمج حركة رأس المال داخل صفحة «الميزانية» وتحديث اسمها في القائمة ولوحة التحكم.
- لوحة التحكم تعرض العملات فقط: USD, CAD, EUR, TRY, SYP, SAR, JOD مع مؤشرات الاتجاه.
- الحوالات غير المدفوعة تظهر تلقائيًا ضمن «دين لنا»، ويُحدّث المتبقي عند السداد.
- نقل النسخ الاحتياطي إلى داخل الإعدادات مع التنزيل والاستعادة.
- فتح نافذة المشاركة لصورة كشف الحساب وإضافة زر حفظ الصورة.
- الحفاظ على بيانات الشركات الحالية وعدم إجراء أي تهيئة للبيانات أثناء التحديث.

## إصلاح مشاركة صورة كشف الحساب
- ربط زر مشاركة الصورة مباشرة بجسر أندرويد الأصلي `AlAboudNative`.
- فتح نافذة المشاركة في الهاتف مباشرة من داخل التطبيق.
- الإبقاء على مشاركة المتصفح كخيار احتياطي.
- لا توجد أي تغييرات على قاعدة البيانات أو بيانات العملاء والحوالات.

---

## v16.0.13

# إصدار v16.0.13 Enterprise

- إصلاح خطأ Kotlin: `Unsupported escape sequence` في `MainActivity.kt`.
- استبدال Regex المسبب للمشكلة بتنظيف آمن لاسم ملف صورة كشف الحساب دون Regex.
- تحديث إصدار تطبيق Android إلى `16.0.13` ورقم البناء إلى `160013`.
- تحديث اسم GitHub Actions واسم ملف APK الناتج إلى v16.0.13.
- إزالة النسخ المتداخلة والمكررة من مشروع Android داخل مجلدات backend وfrontend وscripts.
- الحفاظ على ملفات البيانات الحالية، بما فيها `data/store.json`.

## الرفع إلى GitHub

انسخ محتويات هذا المجلد إلى مستودع المشروع، ثم نفذ:

```bash
git add .
git commit -m "Release v16.0.13 Enterprise"
git push origin main
```

---


## v23.0.30
- Unified profits and monthly reports into one page: التقارير والأرباح.
- Removed top customers section from reports.
- Removed monthly transfer details section from reports.
- Preserved financial summaries, monthly movement, filtering, and printing.

## 24.1.2
- Dynamic versioned Android APK artifact names.
- Node.js 22 for project verification workflow.
- Unified application versions and Android build metadata.
- Removed unused SwipeRefreshLayout dependency.

## v25.4.5 — Professional Cleanup

- Removed obsolete duplicated release notes and backend setup documents from the runtime package.
- Added a comprehensive `.gitignore` to block secrets, backups, build outputs, archives, logs, and local runtime data.
- Losslessly optimized Android PNG assets.
- Verified that all declared production dependencies remain actively used.
- Preserved Playwright because the Jad integration depends on Chromium automation.
- Preserved security, persistence, migration, and UI tests.

## v25.12.3
- إصلاح إنذار قاعدة البيانات الكاذب الناتج عن الاعتماد على جاهزية النظام العامة بدل حالة PostgreSQL نفسها.
- تحسين إعادة الاتصال وفترات فحص الصحة على الهاتف.
- زيادة تحمل عمليات الكتابة لانقطاعات Render/PostgreSQL القصيرة.
- إضافة آخر وقت اتصال ناجح في شريط الحالة.
- توحيد إصدار الويب والخادم وAndroid.

## v25.12.3 — Mobile Customer Experience
- أعيد تصميم قائمة العملاء للهاتف بصفوف مدمجة وأزرار لمس واضحة.
- حُوّل سجل حوالات العميل وسجل الدفعات إلى بطاقات رأسية على الهاتف بدل الجداول العريضة.
- مُنع تجاوز المحتوى لعرض الشاشة وقص الأرقام من اليمين.
- أضيفت مساحة آمنة أسفل الصفحات حتى لا يغطي شريط التنقل الثابت المحتوى.
- صُغّرت بطاقات ملخص العميل وأدوات كشف الحساب مع الحفاظ على وضوح الأرقام.

## v25.12.3 — Customer Rate Accuracy
- جعل `finalRate` المصدر المعتمد لسعر تحويل العميل قبل الحقول القديمة `customerRate` و`clientRate`.
- استبدال بطاقة «متوسط سعر التحويل» المضللة ببطاقة «آخر سعر تحويل للعميل».
- منع ظهور قيم تاريخية غير صحيحة مثل 12.6654 عندما يكون سعر الحوالة الفعلي 1.4700.
- توحيد عرض السعر في قائمة العملاء وسجل العميل وكشف الحساب.
- إضافة اختبار رقمي فعلي لأولوية سعر العميل وآخر سعر حوالة.

## v25.12.4 — Login Reliability
- تمديد جلسة التحقق بخطوتين من 5 إلى 10 دقائق.
- التفريق بين الرمز الخاطئ وانتهاء جلسة التحقق برسائل وأكواد واضحة.
- السماح بانحراف زمني آمن حتى ±60 ثانية بين الهاتف والخادم.
- زيادة حد محاولات التحقق إلى 20 محاولة خلال 10 دقائق مع استمرار الحماية من الإساءة.
- إضافة عداد زمني لجلسة التحقق وزر لطلب جلسة جديدة دون إعادة كتابة بيانات الدخول.
- تفريغ الرمز الخاطئ تلقائياً حتى يتمكن المستخدم من إدخال الرمز الجديد بسهولة.
- الإبقاء على الدخول بالبصمة أو الوجه داخل تطبيق Android عند تفعيله من الإعدادات.

## v25.12.5 — Mobile Transfer Cards
- استبدال عرض جداول الحوالات على الهاتف ببطاقات مستقلة لا تتجاوز عرض الشاشة.
- إصلاح قص أرقام الحوالات والتواريخ والمبالغ وأسعار التحويل من الجهة اليسرى.
- إضافة بطاقات مخصصة لسجل حوالات العميل وقائمة الحوالات العامة.
- إخفاء الجداول العريضة على الشاشات حتى 760px مع الإبقاء عليها للكمبيوتر.
- إضافة اختبار ثابت لتخطيط بطاقات الهاتف.

## v25.12.7 — Mobile Payment Cards
- إعادة تصميم سجل الدفعات على الهاتف ليطابق بطاقات سجل الحوالات.
- منع قص التاريخ والمبلغ والبيان وطريقة الدفع والمرجع وتفاصيل التوزيع.
- إبقاء جدول سطح المكتب كما هو، واستخدام بطاقات مستقلة على الشاشات الصغيرة.
- إضافة مساحة سفلية تمنع شريط التنقل من تغطية آخر دفعة.
- إضافة اختبار تلقائي لتخطيط بطاقات الدفعات على الهاتف.

## v25.12.8 — Report Profit Integrity
- إصلاح ربح فرق السعر في صفحة التقارير والأرباح ليعتمد على سعر كل حوالة الفعلي.
- استبعاد الحوالات المحذوفة والملغاة.
- اعتماد تاريخ الحوالة في الفلاتر والتجميع الشهري.
- إضافة اختبارات رقمية حقيقية للأرباح.

- v25.14.5: جعل سجل المصروفات والأرباح الشهرية على الهاتف بنفس ترتيب بطاقات سجل الحوالات، ومنع القص والتداخل الأفقي.

## v25.14.36 — Budget & Inventory Recovery + Account Verification
- إصلاح تحميل صفحة الميزانية بحيث تظهر البيانات الأساسية حتى لو فشل طلب ثانوي، مع حالة تحميل واضحة وزر إعادة محاولة.
- إصلاح الجرد الشهري ليستخدم قراءة مباشرة حديثة مع زر تحديث وحالة استعادة واضحة.
- إضافة تأكيد الحساب من الإعدادات عبر البريد الإلكتروني أو SMS أو واتساب برمز 6 أرقام صالح 10 دقائق.
- حفظ حالة تأكيد البريد/الهاتف بشكل مستقل، وإبطال التأكيد تلقائيًا عند تغيير وسيلة الاتصال.
- دعم SMTP للبريد وTwilio Programmable Messaging لـ SMS/WhatsApp دون حفظ الرموز كنص صريح.
