export const APP_VERSION="v25.14.58 Startup Runtime Guard";
