# شركة العبود التجارية — Android v13.0.0-alpha.1

هذه نسخة Alpha للاختبار الداخلي.

## الإصلاحات المعتمدة
- أيقونة إشعار Android مستقلة وصحيحة.
- إزالة مرجع `R.drawable.ic_launcher` الذي منع Kotlin من البناء.
- موارد XML غير مكررة.
- GitHub Actions يبني Debug APK مع Stacktrace.
- التطبيق يعرض نظام الويب المنشور على Render.

## GitHub Actions
Workflow:
`Build Android v13 Enterprise Alpha 1 APK`

Artifact:
`AlAboud-Mobile-v13-Enterprise-Alpha1-APK`
