# التعديلات المُنفذة

تم تنفيذ 3 نقاط من قائمة "الأشياء الناقصة": نسيت كلمة المرور، ملف `.env.example`، وترقيم الصفحات.

## 1) نسيت كلمة المرور / إعادة التعيين

مسارات جديدة في `backend/src/server.js`:

- `POST /api/auth/forgot-password` — body: `{ "email": "user@example.com" }`
  - يولّد رمزًا عشوائيًا (32 بايت)، يخزّن **هاش** الرمز فقط (SHA-256) في المستخدم مع صلاحية 30 دقيقة.
  - يرسل بريدًا إلكترونيًا يحتوي رابط إعادة التعيين إن كانت `SMTP_HOST` مضبوطة.
  - **يرد بنفس الرسالة دائمًا** سواء كان البريد مسجلاً أم لا (لمنع اكتشاف الحسابات).
  - في وضع التطوير (بدون SMTP)، يعيد الرد `devResetToken` و`devResetLink` مباشرة لتسهيل الاختبار المحلي فقط.

- `POST /api/auth/reset-password` — body: `{ "email", "token", "newPassword" }`
  - يتحقق من الرمز (بمقارنة الهاش) وصلاحيته، ثم يطبّق سياسة كلمة المرور المعتمدة في المشروع (12 حرفًا، حرف كبير وصغير ورقم ورمز).
  - يعيد ضبط محاولات الدخول الفاشلة وأي قفل حساب مؤقت.
  - كل عملية مسجّلة في `auditLogs` (نفس نظام السجل المتسلسل الموجود في المشروع).

### البريد الإلكتروني
أُضيفت حزمة `nodemailer` كتبعية في `backend/package.json`. إن لم تُضبط `SMTP_HOST` في البيئة،
تُطبع الرسالة في الـ console بدلاً من الإرسال الفعلي (حتى لا تنكسر الميزة في التطوير المحلي).

### اختبار سريع (محليًا)
```bash
curl -X POST http://localhost:5000/api/auth/forgot-password \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@alaboud.local"}'
# سيعيد devResetToken لأن SMTP غير مضبوطة محليًا

curl -X POST http://localhost:5000/api/auth/reset-password \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@alaboud.local","token":"<devResetToken>","newPassword":"NewPass123!"}'
```

## 2) ملف `.env.example`

أُضيف في مكانين: `backend/.env.example` و`.env.example` (جذر المشروع، لأن النشر على Render
يبدأ من الجذر). يوثّق كل المتغيرات المستخدمة فعليًا في الكود:
`PORT`, `NODE_ENV`, `APP_URL`, `JWT_SECRET`, `DATABASE_URL`, `DATA_DIR`,
ومتغيرات SMTP الجديدة (`SMTP_HOST/PORT/SECURE/USER/PASS/FROM`).

انسخه إلى `.env` واملأ القيم الحقيقية — لا ترفع `.env` نفسه إلى Git (موجود أصلاً في `.gitignore`).

## 3) ترقيم الصفحات (Pagination)

أُضيفت دالة مساعدة `paginate(req, rows)` في `server.js`، وطُبّقت على:
- `GET /api/customers`
- `GET /api/transactions`
- `GET /api/expenses`

**متوافقة مع الواجهة الحالية 100%**: إن لم يُرسل الطلب `?page` أو `?pageSize`، تُعاد المصفوفة
كما هي بدون أي تغيير — فلن ينكسر أي شيء في الواجهة الأمامية الحالية.

عند إرسال `?page=1&pageSize=25` يصبح الرد:
```json
{
  "items": [...],
  "total": 340,
  "page": 1,
  "pageSize": 25,
  "totalPages": 14
}
```

### لماذا لم تُطبّق على `/api/partners` و`/api/general-debts`؟
هذان المساران يعيدان كائنًا مُجمّعًا (`{rows, totals}` أو حسابات مبنية على كامل البيانات)
وليس مصفوفة بسيطة — تطبيق الترقيم عليهما مباشرة سيُفسد حساب الإجماليات (totals) التي يجب أن
تُحسب على كامل البيانات دائمًا. يحتاجان تصميمًا منفصلاً (حساب الإجماليات أولاً ثم تقطيع rows
فقط للعرض) — يمكن تنفيذه في خطوة لاحقة إذا رغبتم.

## ملاحظة مهمة
لتفعيل هذه التعديلات فعليًا، استبدل `backend/server.js` و`backend/package.json` بالنسختين
المرفقتين، ثم:
```bash
npm install --prefix backend
```
